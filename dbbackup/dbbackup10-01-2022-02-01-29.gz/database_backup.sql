SET foreign_key_checks = 0;
#
# TABLE STRUCTURE FOR: ci_sessions
#

DROP TABLE IF EXISTS `ci_sessions`;

CREATE TABLE `ci_sessions` (
  `id` varchar(128) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT 0,
  `data` blob NOT NULL,
  KEY `ci_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bfb2ba51ab4b854c642805ace161d976a800f7b4', '37.34.206.9', 1641813091, '__ci_last_regenerate|i:1641813091;currency|s:2:\"KD\";currency_placement|s:4:\"Left\";currency_code|s:3:\"KWD\";view_date|s:10:\"dd-mm-yyyy\";view_time|s:2:\"12\";inv_username|s:5:\"admin\";inv_userid|s:1:\"1\";logged_in|b:1;role_id|s:1:\"1\";role_name|s:5:\"Admin\";language|s:7:\"English\";language_id|s:1:\"1\";success|s:38:\"Success!! New Item Added Successfully!\";__ci_vars|a:1:{s:7:\"success\";s:3:\"new\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('aed57366059d11142a828f33a09943be7ae77946', '37.34.206.9', 1641813595, '__ci_last_regenerate|i:1641813595;currency|s:2:\"KD\";currency_placement|s:4:\"Left\";currency_code|s:3:\"KWD\";view_date|s:10:\"dd-mm-yyyy\";view_time|s:2:\"12\";inv_username|s:5:\"admin\";inv_userid|s:1:\"1\";logged_in|b:1;role_id|s:1:\"1\";role_name|s:5:\"Admin\";language|s:7:\"English\";language_id|s:1:\"1\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f81ff1aaec04814eaf2c58bfb7c914c5684b6889', '37.34.206.9', 1641813985, '__ci_last_regenerate|i:1641813985;currency|s:2:\"KD\";currency_placement|s:4:\"Left\";currency_code|s:3:\"KWD\";view_date|s:10:\"dd-mm-yyyy\";view_time|s:2:\"12\";inv_username|s:5:\"admin\";inv_userid|s:1:\"1\";logged_in|b:1;role_id|s:1:\"1\";role_name|s:5:\"Admin\";language|s:7:\"English\";language_id|s:1:\"1\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('625d8f4fdfdd9ef899d993d5031f7bfaf93a760c', '37.34.206.9', 1641814503, '__ci_last_regenerate|i:1641814503;currency|s:2:\"KD\";currency_placement|s:4:\"Left\";currency_code|s:3:\"KWD\";view_date|s:10:\"dd-mm-yyyy\";view_time|s:2:\"12\";inv_username|s:5:\"admin\";inv_userid|s:1:\"1\";logged_in|b:1;role_id|s:1:\"1\";role_name|s:5:\"Admin\";language|s:7:\"English\";language_id|s:1:\"1\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8865c9e3c3a99dfbd906e3fdc7fb1b77d2b035f3', '37.34.206.9', 1641814839, '__ci_last_regenerate|i:1641814839;currency|s:2:\"KD\";currency_placement|s:4:\"Left\";currency_code|s:3:\"KWD\";view_date|s:10:\"dd-mm-yyyy\";view_time|s:2:\"12\";inv_username|s:5:\"admin\";inv_userid|s:1:\"1\";logged_in|b:1;role_id|s:1:\"1\";role_name|s:5:\"Admin\";language|s:7:\"English\";language_id|s:1:\"1\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('751146005a211294bbf0050a19108e1edf4e865d', '37.34.206.9', 1641814987, '__ci_last_regenerate|i:1641814839;currency|s:2:\"KD\";currency_placement|s:4:\"Left\";currency_code|s:3:\"KWD\";view_date|s:10:\"dd-mm-yyyy\";view_time|s:2:\"12\";inv_username|s:5:\"admin\";inv_userid|s:1:\"1\";logged_in|b:1;role_id|s:1:\"1\";role_name|s:5:\"Admin\";language|s:7:\"English\";language_id|s:1:\"1\";');


#
# TABLE STRUCTURE FOR: db_brands
#

DROP TABLE IF EXISTS `db_brands`;

CREATE TABLE `db_brands` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `brand_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `brand_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_id` int(5) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (1, 'CT0001', 'HIK Vision', 'HIK Vision', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (3, 'CT0003', 'Dell', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (4, 'CT0004', 'HP', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (5, 'CT0005', 'Lenovo', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (6, 'CT0006', 'TP-Link', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (7, 'CT0007', 'D-Link', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (8, 'CT0008', 'Cisco', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (9, 'CT0009', 'Linksys', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (10, 'CT0010', 'Logitech', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (11, 'CT0011', 'Kuwes', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (12, 'CT0012', 'China', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (13, 'CT0013', 'Toten', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (14, 'CT0014', 'Kuwait', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (15, 'CT0015', 'Gulf', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (16, 'CT0016', 'Hikvision', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (18, 'CT0018', 'Service', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (19, 'CT0019', 'Softwares', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (20, 'CT0020', 'England', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (21, 'CT0021', 'Lexar', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (22, 'CT0022', 'WD Blue', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (23, 'CT0023', 'DTECH', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (24, 'CT0024', 'Honey Well', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (25, 'CT0025', 'Kingston', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (26, 'CT0026', 'Team Group', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (27, 'CT0027', 'TASS', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (28, 'CT0028', 'APC', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (29, 'CT0029', 'OSCAR', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (30, 'CT0030', 'Sea Gate', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (31, 'CT0031', 'SANDISK', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (32, 'CT0032', 'Microsoft', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (33, 'CT0033', 'S-Tek', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (34, 'CT0034', 'Net Gear', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (35, 'CT0035', 'TP    Link', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (36, 'CT0036', 'Sharp', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (37, 'CT0037', 'Mac-Pro', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (38, 'CT0038', 'HP LED', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (39, 'CT0039', 'ZKTeco', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (40, 'CT0040', 'UHD', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (41, 'CT0041', 'Net  Work', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (42, 'CT0042', 'OSCOO', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (43, 'CT0043', 'Crucial', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (44, 'CT0044', 'Kaspersky', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (45, 'CT0045', 'Vention', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (46, 'CT0046', 'Toshiba', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (47, 'CT0047', 'Western Digital', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (48, 'CT0048', 'Klevv', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (49, 'CT0049', 'samsung', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (50, 'CT0050', 'Twinmos', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (51, 'CT0051', 'Tesmart', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (52, 'CT0052', 'Premium', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (53, 'CT0053', 'Coring', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (54, 'CT0054', 'Western Digital        Blue', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (55, 'CT0055', 'W.D  Purple', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (56, 'CT0056', 'Seagate  -    Barracuda .', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (57, 'CT0057', 'Toshiba - Surveillance  .', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (58, 'CT0058', 'Axview', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (59, 'CT0059', 'Patta', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (60, 'CT0060', 'Dahua', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (61, 'CT0061', 'UNV', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (62, 'CT0062', 'Realand', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (63, 'CT0063', 'Engenius', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (64, 'CT0064', 'WD Black', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (65, 'CT0065', 'Lecxo', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (66, 'CT0066', 'UBIQUITI', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (67, 'CT0067', 'HAING', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (68, 'CT0068', 'ASUS', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (69, 'CT0069', 'Hybrid', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (70, 'CT0070', 'Sebury', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (71, 'CT0071', 'Frontech', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (72, 'CT0072', 'Funlux', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (73, 'CT0073', 'Turkey', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (74, 'CT0074', 'Genius', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (75, 'CT0075', 'RAMAXEL', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (76, 'CT0076', 'Softline', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (77, 'CT0077', 'Microsoft   Corp.', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (78, 'CT0078', 'Buro', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (79, 'CT0079', 'BORL', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (80, 'CT0080', 'Suprema', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (81, 'CT0081', 'Miscellaneous', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (82, 'CT0082', 'HAYSENSER', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (83, 'CT0083', 'Jasoz', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (84, 'CT0084', 'Maintenance', '', NULL, 1);
INSERT INTO `db_brands` (`id`, `brand_code`, `brand_name`, `description`, `company_id`, `status`) VALUES (85, 'CT0085', 'Corning .', '', NULL, 1);


#
# TABLE STRUCTURE FOR: db_category
#

DROP TABLE IF EXISTS `db_category`;

CREATE TABLE `db_category` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `category_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_id` int(5) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (1, 'CT0001', 'Camera', 'Camera', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (2, 'CT0002', 'Monitors', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (3, 'CT0003', 'Desktops', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (4, 'CT0004', 'Laptops', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (5, 'CT0005', 'Time Attendance', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (6, 'CT0006', 'Finger Print', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (7, 'CT0007', 'Access Control', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (8, 'CT0008', 'Network', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (9, 'CT0009', 'PVC   Pipe  with Fittings', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (10, 'CT0010', 'GI Pipe With Fittings', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (11, 'CT0011', 'Hardware', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (12, 'CT0012', 'Electrical', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (13, 'CT0013', 'OIl and Lubricant', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (14, 'CT0014', 'Vehicles', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (15, 'CT0015', 'Transport', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (16, 'CT0016', 'Water   and  Food  Items', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (17, 'CT0017', 'Cosmetics', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (18, 'CT0018', 'Furniture', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (19, 'CT0019', 'Rental', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (20, 'CT0020', 'Telephone / Mobile', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (21, 'CT0021', 'Stationary', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (22, 'CT0022', 'Tools', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (23, 'CT0023', 'Miscellaneous', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (24, 'CT0024', 'ZK Teco', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (25, 'CT0025', 'Service', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (26, 'CT0026', 'Softwares', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (27, 'CT0027', 'Scanner', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (28, 'CT0028', 'TONERS', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (29, 'CT0029', 'Memory', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (30, 'CT0030', 'DELL  LED', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (31, 'CT0031', 'Anti-Virus', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (32, 'CT0032', 'Laptop   Spares', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (33, 'CT0033', 'Cables', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (34, 'CT0034', 'DVR', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (35, 'CT0035', 'NVR', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (36, 'CT0036', 'Access Point', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (37, 'CT0037', 'Bag', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (38, 'CT0038', 'Head Set', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (39, 'CT0039', 'Intercom', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (40, 'CT0040', 'Mouse', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (41, 'CT0041', 'VGA Card', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (42, 'CT0042', 'Adaptor', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (43, 'CT0043', 'Door Sensor', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (44, 'CT0044', 'Battery', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (45, 'CT0045', 'Used', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (46, 'CT0046', 'Operating     System', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (47, 'CT0047', 'Domain- Renewal', '', NULL, 1);
INSERT INTO `db_category` (`id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES (48, 'CT0048', 'Maintenance', '', NULL, 1);


#
# TABLE STRUCTURE FOR: db_cobpayments
#

DROP TABLE IF EXISTS `db_cobpayments`;

CREATE TABLE `db_cobpayments` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `customer_id` int(5) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `payment_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment` double(20,3) DEFAULT NULL,
  `payment_note` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_ip` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_time` time DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: db_company
#

DROP TABLE IF EXISTS `db_company`;

CREATE TABLE `db_company` (
  `id` int(5) DEFAULT NULL,
  `company_code` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_name` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_website` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_logo` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `upi_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `upi_code` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postcode` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gst_no` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vat_no` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pan_no` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bank_details` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cid` int(10) DEFAULT NULL,
  `category_init` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `item_init` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'INITAL CODE',
  `supplier_init` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'INITAL CODE',
  `purchase_init` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'INITAL CODE',
  `purchase_return_init` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_init` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'INITAL CODE',
  `sales_init` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'INITAL CODE',
  `service_init` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'INITAL CODE',
  `sales_return_init` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expense_init` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoice_view` int(5) DEFAULT NULL COMMENT '1=Standard,2=Indian GST',
  `status` int(1) DEFAULT NULL,
  `sms_status` int(1) DEFAULT NULL COMMENT '1=Enable 0=Disable',
  `sales_terms_and_conditions` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_company` (`id`, `company_code`, `company_name`, `company_website`, `mobile`, `phone`, `email`, `website`, `company_logo`, `logo`, `upi_id`, `upi_code`, `country`, `state`, `city`, `address`, `postcode`, `gst_no`, `vat_no`, `pan_no`, `bank_details`, `cid`, `category_init`, `item_init`, `supplier_init`, `purchase_init`, `purchase_return_init`, `customer_init`, `sales_init`, `service_init`, `sales_return_init`, `expense_init`, `invoice_view`, `status`, `sms_status`, `sales_terms_and_conditions`) VALUES (1, '', 'Softline Technology', NULL, '94157777', '', 'sales@softlinekw.com', '', 'softline_logo_21.png', 'logo-0.png', '', NULL, 'Kuwait', 'Kuwait city', 'Qibla', 'Qibla, AL Dawliya Commerial Complex, Kuwait City.', '', '', '', '', '', 1, 'CT', 'IT', 'SP', 'PU', 'PR', 'CU', 'SL', 'SV', 'PR', 'EX', 1, 1, 0, '');


#
# TABLE STRUCTURE FOR: db_country
#

DROP TABLE IF EXISTS `db_country`;

CREATE TABLE `db_country` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `country_code` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(4050) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `added_on` date DEFAULT NULL,
  `company_id` int(5) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_country` (`id`, `country_code`, `country`, `added_on`, `company_id`, `status`) VALUES (3, NULL, 'Kuwait', NULL, NULL, 1);


#
# TABLE STRUCTURE FOR: db_currency
#

DROP TABLE IF EXISTS `db_currency`;

CREATE TABLE `db_currency` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `currency_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency_code` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency` blob DEFAULT NULL,
  `symbol` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(5) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_currency` (`id`, `currency_name`, `currency_code`, `currency`, `symbol`, `status`) VALUES (56, 'Kuwaiti Dinar', 'KWD', 'KD', NULL, 1);


#
# TABLE STRUCTURE FOR: db_customer_payments
#

DROP TABLE IF EXISTS `db_customer_payments`;

CREATE TABLE `db_customer_payments` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `salespayment_id` int(5) DEFAULT NULL,
  `customer_id` int(5) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `payment_type` varchar(50) DEFAULT NULL,
  `payment` double(20,3) DEFAULT NULL,
  `payment_note` text DEFAULT NULL,
  `system_ip` varchar(50) DEFAULT NULL,
  `system_name` varchar(50) DEFAULT NULL,
  `created_time` varchar(50) DEFAULT NULL,
  `created_date` varchar(50) DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_id` (`customer_id`),
  KEY `salespayment_id` (`salespayment_id`),
  CONSTRAINT `db_customer_payments_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `db_customers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `db_customer_payments_ibfk_2` FOREIGN KEY (`salespayment_id`) REFERENCES `db_salespayments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1102 DEFAULT CHARSET=utf8mb4;

INSERT INTO `db_customer_payments` (`id`, `salespayment_id`, `customer_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (1092, 52, 27, '2021-09-21', 'Cash', '17.000', '', '37.34.206.9', '37.34.206.9', '04:09:38', '2021-09-21', 'admin', 1);
INSERT INTO `db_customer_payments` (`id`, `salespayment_id`, `customer_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (1094, 54, 28, '2021-12-16', 'Cash', '1.250', '', '37.34.206.9', '37.34.206.9', '06:26:26', '2021-12-16', 'admin', 1);
INSERT INTO `db_customer_payments` (`id`, `salespayment_id`, `customer_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (1101, 53, 12, '2021-12-16', 'Cash', '250.000', '', '37.34.206.9', '37.34.206.9', '06:26:09', '2021-12-16', 'admin', 1);


#
# TABLE STRUCTURE FOR: db_customers
#

DROP TABLE IF EXISTS `db_customers`;

CREATE TABLE `db_customers` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `customer_code` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gstin` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax_number` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vatin` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `opening_balance` double(20,3) DEFAULT NULL,
  `sales_due` double(20,3) DEFAULT NULL,
  `sales_return_due` double(20,3) DEFAULT NULL,
  `country_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postcode` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_ip` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_time` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_id` int(5) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_customers` (`id`, `customer_code`, `customer_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `sales_due`, `sales_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (1, 'CU0001', 'Walk-in customer', '', '', '', '', '', NULL, NULL, '0.000', '0.000', '', '', NULL, '', '', NULL, NULL, '2019-01-01', '10:55:54 pm', 'admin', NULL, 1);
INSERT INTO `db_customers` (`id`, `customer_code`, `customer_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `sales_due`, `sales_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (10, 'CU0010', 'Al Bahar Bardawill', '', '', '', '', '', NULL, '0.000', '0.000', NULL, '3', NULL, '', '', 'Ardiya , Kuwait', '37.34.206.9', '37.34.206.9', '2021-06-17', '07:18:24 pm', 'admin', NULL, 1);
INSERT INTO `db_customers` (`id`, `customer_code`, `customer_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `sales_due`, `sales_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (11, 'CU0011', 'Kuwait Marie  Time', '', '', '', '', '', NULL, '0.000', '0.000', NULL, '3', NULL, '', '', '', '37.34.206.9', '37.34.206.9', '2021-06-19', '08:08:47 pm', 'admin', NULL, 1);
INSERT INTO `db_customers` (`id`, `customer_code`, `customer_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `sales_due`, `sales_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (12, 'CU0012', 'CMA CGM KUWAIT W.L.L  .', '', '', '', '', '', NULL, '0.000', '764.000', NULL, '3', NULL, 'Kuwait', '', '', '37.34.206.9', '37.34.206.9', '2021-06-27', '04:41:51 pm', 'admin', NULL, 1);
INSERT INTO `db_customers` (`id`, `customer_code`, `customer_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `sales_due`, `sales_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (13, 'CU0013', 'Al -Shoura   Trading   Co.', '', '', '', '', '', NULL, '0.000', '0.000', '0.000', '3', NULL, '', '', '', '37.34.206.9', '37.34.206.9', '2021-07-03', '06:51:45 pm', 'admin', NULL, 1);
INSERT INTO `db_customers` (`id`, `customer_code`, `customer_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `sales_due`, `sales_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (14, 'CU0014', 'ZUE  Pet Park', '', '', '', '', '', NULL, '0.000', '0.000', NULL, '3', '54', '', '', '', '37.34.206.9', '37.34.206.9', '2021-07-25', '05:46:12 pm', 'admin', NULL, 1);
INSERT INTO `db_customers` (`id`, `customer_code`, `customer_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `sales_due`, `sales_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (15, 'CU0015', 'Oman Exchange .', '', '', '', '', '', NULL, '0.000', '0.000', NULL, '3', NULL, '', '', '', '37.34.206.9', '37.34.206.9', '2021-07-28', '03:41:21 pm', 'admin', NULL, 1);
INSERT INTO `db_customers` (`id`, `customer_code`, `customer_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `sales_due`, `sales_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (16, 'CU0016', 'International Trading  group .', '', '', '', '', '', NULL, '0.000', '0.000', NULL, '3', NULL, '', '', '', '37.34.206.9', '37.34.206.9', '2021-07-28', '04:30:57 pm', 'admin', NULL, 1);
INSERT INTO `db_customers` (`id`, `customer_code`, `customer_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `sales_due`, `sales_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (17, 'CU0017', 'SAFATECH', '', '', '', '', '', NULL, '0.000', '0.000', NULL, '3', NULL, '', '', '', '37.34.206.9', '37.34.206.9', '2021-07-28', '06:32:03 pm', 'admin', NULL, 1);
INSERT INTO `db_customers` (`id`, `customer_code`, `customer_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `sales_due`, `sales_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (18, 'CU0018', 'Benayath  Real Estate', '', '', '', '', '', NULL, '0.000', '0.000', NULL, '3', NULL, '', '', '', '37.34.206.9', '37.34.206.9', '2021-07-29', '11:24:51 am', 'admin', NULL, 1);
INSERT INTO `db_customers` (`id`, `customer_code`, `customer_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `sales_due`, `sales_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (19, 'CU0019', 'Holiday Inn', '', '', '', '', '', NULL, '0.000', '0.000', NULL, '3', NULL, '', '', '', '37.34.206.9', '37.34.206.9', '2021-07-29', '06:42:43 pm', 'admin', NULL, 1);
INSERT INTO `db_customers` (`id`, `customer_code`, `customer_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `sales_due`, `sales_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (20, 'CU0020', 'Nasco Trading   Head Office', '', '', '', '', '', NULL, '0.000', '28.500', NULL, '3', NULL, '', '', '', '37.34.206.9', '37.34.206.9', '2021-07-29', '06:53:08 pm', 'admin', NULL, 1);
INSERT INTO `db_customers` (`id`, `customer_code`, `customer_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `sales_due`, `sales_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (22, 'CU0021', 'Performance Machine', '', '', '', '', '', NULL, '0.000', '0.000', NULL, '3', NULL, '', '', '', '37.34.206.9', '37.34.206.9', '2021-08-07', '04:41:57 pm', 'admin', NULL, 1);
INSERT INTO `db_customers` (`id`, `customer_code`, `customer_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `sales_due`, `sales_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (23, 'CU0023', 'Eng .Mustafa  ( Farooqi   Eng  )', '', '', '', '', '', NULL, '0.000', '0.000', NULL, '3', NULL, '', '', '', '37.34.206.9', '37.34.206.9', '2021-08-07', '04:51:53 pm', 'admin', NULL, 1);
INSERT INTO `db_customers` (`id`, `customer_code`, `customer_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `sales_due`, `sales_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (24, 'CU0024', 'Hotel   Bravo', '', '', '', '', '', NULL, '0.000', '0.000', NULL, '3', NULL, '', '', '', '37.34.206.9', '37.34.206.9', '2021-08-07', '04:55:16 pm', 'admin', NULL, 1);
INSERT INTO `db_customers` (`id`, `customer_code`, `customer_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `sales_due`, `sales_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (25, 'CU0025', 'Kooper    Group', '', '', '', '', '', NULL, '0.000', NULL, NULL, '3', NULL, '', '', '', '37.34.206.9', '37.34.206.9', '2021-08-07', '05:04:42 pm', 'admin', NULL, 1);
INSERT INTO `db_customers` (`id`, `customer_code`, `customer_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `sales_due`, `sales_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (26, 'CU0026', 'New Pakistan International School', '', '', '', '', '', NULL, '0.000', '0.000', NULL, '3', '54', '', '', '', '37.34.206.9', '37.34.206.9', '2021-08-29', '05:49:00 pm', 'admin', NULL, 1);
INSERT INTO `db_customers` (`id`, `customer_code`, `customer_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `sales_due`, `sales_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (27, 'CU0027', 'Al -Ebdaa  Al - Khaliji    Estate', '', '', '', '', '', NULL, '0.000', '370.500', NULL, '3', NULL, '', '', '', '37.34.206.9', '37.34.206.9', '2021-09-18', '03:51:41 pm', 'admin', NULL, 1);
INSERT INTO `db_customers` (`id`, `customer_code`, `customer_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `sales_due`, `sales_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (28, 'CU0028', 'Chocolate Ness   Company .', '', '', '', '', '', NULL, '0.000', '0.000', NULL, '3', NULL, '', '', '', '37.34.206.9', '37.34.206.9', '2021-10-19', '03:13:24 pm', 'admin', NULL, 1);
INSERT INTO `db_customers` (`id`, `customer_code`, `customer_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `sales_due`, `sales_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (29, 'CU0029', 'T4    Plus  Marble  Co  .', '', '', '', '', '', NULL, '0.000', '153.000', NULL, '3', NULL, '', '', '', '37.34.206.9', '37.34.206.9', '2021-10-27', '01:01:37 pm', 'admin', NULL, 1);
INSERT INTO `db_customers` (`id`, `customer_code`, `customer_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `sales_due`, `sales_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (30, 'CU0030', 'Cash  Invoice', '', '', '', '', '', NULL, '0.000', '72.000', NULL, '3', NULL, '', '', '', '37.34.206.9', '37.34.206.9', '2021-11-11', '03:36:40 pm', 'admin', NULL, 1);
INSERT INTO `db_customers` (`id`, `customer_code`, `customer_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `sales_due`, `sales_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (31, 'CU0031', 'SQC', '', '', '', '', '', NULL, '0.000', NULL, NULL, '3', NULL, '', '', '', '37.34.206.9', '37.34.206.9', '2021-12-05', '07:01:00 pm', 'admin', NULL, 1);
INSERT INTO `db_customers` (`id`, `customer_code`, `customer_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `sales_due`, `sales_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (32, 'CU0032', 'Al-Rayan Holding Fahaheel Al-Watanieh School-Girls', '', '', '', '', '', NULL, '0.000', '264.150', NULL, '3', NULL, '', '', '', '37.34.206.9', '37.34.206.9', '2021-12-05', '08:40:26 pm', 'admin', NULL, 1);
INSERT INTO `db_customers` (`id`, `customer_code`, `customer_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `sales_due`, `sales_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (33, 'CU0033', 'Cozmo  Travels .', '', '', 'kwi.finance@cozmotravel.com', '', '', NULL, '0.000', NULL, NULL, '3', NULL, '', '', '', '37.34.206.9', '37.34.206.9', '2021-12-12', '02:13:09 pm', 'admin', NULL, 1);
INSERT INTO `db_customers` (`id`, `customer_code`, `customer_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `sales_due`, `sales_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (34, 'CU0034', 'AL SOOR . Certified Public A/C (Audit)', '', '', '', '', '', NULL, '0.000', '60.000', NULL, '3', NULL, '', '', '', '37.34.206.9', '37.34.206.9', '2021-12-20', '12:48:27 pm', 'admin', NULL, 1);


#
# TABLE STRUCTURE FOR: db_expense
#

DROP TABLE IF EXISTS `db_expense`;

CREATE TABLE `db_expense` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `expense_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category_id` int(5) DEFAULT NULL,
  `expense_date` date DEFAULT NULL,
  `reference_no` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expense_for` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expense_amt` double(20,3) DEFAULT NULL,
  `note` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_time` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_ip` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_expense` (`id`, `expense_code`, `category_id`, `expense_date`, `reference_no`, `expense_for`, `expense_amt`, `note`, `created_by`, `created_date`, `created_time`, `system_ip`, `system_name`, `status`) VALUES (1, 'EX0001', 4, '2021-06-09', '1110', 'for petrol', '3.000', '', 'admin', '2021-06-20', '08:38:39 am', '37.34.206.9', '37.34.206.9', 1);
INSERT INTO `db_expense` (`id`, `expense_code`, `category_id`, `expense_date`, `reference_no`, `expense_for`, `expense_amt`, `note`, `created_by`, `created_date`, `created_time`, `system_ip`, `system_name`, `status`) VALUES (2, 'EX0002', 5, '2021-06-12', '2400', 'Petrol', '3.000', '', 'admin', '2021-06-20', '08:39:12 am', '37.34.206.9', '37.34.206.9', 1);
INSERT INTO `db_expense` (`id`, `expense_code`, `category_id`, `expense_date`, `reference_no`, `expense_for`, `expense_amt`, `note`, `created_by`, `created_date`, `created_time`, `system_ip`, `system_name`, `status`) VALUES (3, 'EX0003', 6, '2021-06-09', '1510', 'Petrol', '3.000', '', 'admin', '2021-06-20', '08:39:51 am', '37.34.206.9', '37.34.206.9', 1);
INSERT INTO `db_expense` (`id`, `expense_code`, `category_id`, `expense_date`, `reference_no`, `expense_for`, `expense_amt`, `note`, `created_by`, `created_date`, `created_time`, `system_ip`, `system_name`, `status`) VALUES (4, 'EX0004', 4, '2021-08-12', '8164749354', 'V-Belt', '7.750', '', 'admin', '2021-08-12', '06:21:31 pm', '37.34.206.9', '37.34.206.9', 1);
INSERT INTO `db_expense` (`id`, `expense_code`, `category_id`, `expense_date`, `reference_no`, `expense_for`, `expense_amt`, `note`, `created_by`, `created_date`, `created_time`, `system_ip`, `system_name`, `status`) VALUES (5, 'EX0005', 4, '2021-08-12', '2398', 'Battery -12  month    Warranty', '15.000', 'Easton      with Card ', 'admin', '2021-08-12', '06:22:53 pm', '37.34.206.9', '37.34.206.9', 1);
INSERT INTO `db_expense` (`id`, `expense_code`, `category_id`, `expense_date`, `reference_no`, `expense_for`, `expense_amt`, `note`, `created_by`, `created_date`, `created_time`, `system_ip`, `system_name`, `status`) VALUES (6, 'EX0006', 4, '2021-08-12', '93885', 'Front   Shock Absorber   -2 nos   ans  Sleeve-2 nos', '30.000', '', 'admin', '2021-08-12', '06:24:21 pm', '37.34.206.9', '37.34.206.9', 1);
INSERT INTO `db_expense` (`id`, `expense_code`, `category_id`, `expense_date`, `reference_no`, `expense_for`, `expense_amt`, `note`, `created_by`, `created_date`, `created_time`, `system_ip`, `system_name`, `status`) VALUES (7, 'EX0007', 4, '2021-08-12', '528', 'Shock Absorber  Front   with  V- belt   Fixing  Charges .', '10.000', 'Vijay   workshop', 'admin', '2021-08-12', '06:26:08 pm', '37.34.206.9', '37.34.206.9', 1);


#
# TABLE STRUCTURE FOR: db_expense_category
#

DROP TABLE IF EXISTS `db_expense_category`;

CREATE TABLE `db_expense_category` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `category_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_expense_category` (`id`, `category_code`, `category_name`, `description`, `created_by`, `status`) VALUES (1, 'EC0001', 'Rent', 'Office Rent', 'admin', 1);
INSERT INTO `db_expense_category` (`id`, `category_code`, `category_name`, `description`, `created_by`, `status`) VALUES (2, 'EC0002', 'Salary', 'employee salary', 'admin', 1);
INSERT INTO `db_expense_category` (`id`, `category_code`, `category_name`, `description`, `created_by`, `status`) VALUES (3, 'EC0003', 'Purchase', 'Purchase', 'admin', 1);
INSERT INTO `db_expense_category` (`id`, `category_code`, `category_name`, `description`, `created_by`, `status`) VALUES (4, 'EC0004', 'Car -2212', '', 'admin', 1);
INSERT INTO `db_expense_category` (`id`, `category_code`, `category_name`, `description`, `created_by`, `status`) VALUES (5, 'EC0005', 'Car -72857', '', 'admin', 1);
INSERT INTO `db_expense_category` (`id`, `category_code`, `category_name`, `description`, `created_by`, `status`) VALUES (6, 'EC0006', 'Car-17910', '', 'admin', 1);


#
# TABLE STRUCTURE FOR: db_hold
#

DROP TABLE IF EXISTS `db_hold`;

CREATE TABLE `db_hold` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `reference_id` varchar(50) DEFAULT NULL,
  `reference_no` varchar(50) DEFAULT NULL,
  `sales_date` date DEFAULT NULL,
  `sales_status` varchar(50) DEFAULT NULL,
  `customer_id` int(5) DEFAULT NULL,
  `other_charges_input` double(20,3) DEFAULT NULL,
  `other_charges_tax_id` int(5) DEFAULT NULL,
  `other_charges_amt` double(20,3) DEFAULT NULL,
  `discount_to_all_input` double(20,3) DEFAULT NULL,
  `discount_to_all_type` varchar(50) DEFAULT NULL,
  `tot_discount_to_all_amt` double(20,3) DEFAULT NULL,
  `subtotal` double(20,3) DEFAULT NULL,
  `round_off` double(20,3) DEFAULT NULL,
  `grand_total` double(20,3) DEFAULT NULL,
  `sales_note` text DEFAULT NULL,
  `pos` int(1) DEFAULT NULL COMMENT '1=yes 0=no',
  PRIMARY KEY (`id`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `db_hold_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `db_customers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: db_holditems
#

DROP TABLE IF EXISTS `db_holditems`;

CREATE TABLE `db_holditems` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `hold_id` int(5) DEFAULT NULL,
  `item_id` int(5) DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sales_qty` double(20,3) DEFAULT NULL,
  `price_per_unit` double(20,3) DEFAULT NULL,
  `tax_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax_id` int(5) DEFAULT NULL,
  `tax_amt` double(20,3) DEFAULT NULL,
  `discount_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `discount_input` double(20,3) DEFAULT NULL,
  `discount_amt` double(20,3) DEFAULT NULL,
  `unit_total_cost` double(20,3) DEFAULT NULL,
  `total_cost` double(20,3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sales_id` (`hold_id`),
  KEY `item_id` (`item_id`),
  CONSTRAINT `db_holditems_ibfk_2` FOREIGN KEY (`hold_id`) REFERENCES `db_hold` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `db_holditems_ibfk_3` FOREIGN KEY (`item_id`) REFERENCES `db_items` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: db_items
#

DROP TABLE IF EXISTS `db_items`;

CREATE TABLE `db_items` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `item_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_barcode` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `item_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category_id` int(10) DEFAULT NULL,
  `sku` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hsn` varbinary(50) DEFAULT NULL,
  `unit_id` int(10) DEFAULT NULL,
  `alert_qty` int(10) DEFAULT NULL,
  `brand_id` int(5) DEFAULT NULL,
  `lot_number` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expire_date` date DEFAULT NULL,
  `price` double(20,3) DEFAULT NULL,
  `tax_id` int(5) DEFAULT NULL,
  `purchase_price` double(20,3) DEFAULT NULL,
  `tax_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profit_margin` double(20,3) DEFAULT NULL,
  `sales_price` double(20,3) DEFAULT NULL,
  `final_price` double(20,3) DEFAULT NULL,
  `stock` double(20,3) DEFAULT NULL,
  `item_image` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_ip` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_time` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_id` int(5) DEFAULT NULL,
  `status` int(5) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=310 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (1, 'IT0001', '', 'Hikvision  2  MP   Turbo  HD   Camera Indoor  2.8MM    Model   DS-2CE56DOT-IRP', '', 1, '', '', 15, 0, 1, '', NULL, '6.000', 1, '6.000', 'Exclusive', '33.000', '8.000', '8.000', '7.000', NULL, '37.34.206.9', '37.34.206.9', '2021-09-13', '02:44:06 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (2, 'IT0002', '', 'Hikvision  2  MP   Turbo  HD WDR   Camera Outdoor   2.8MM    Model   DS-2CE16DOT-ITPF', '', 1, '', '', 15, 0, 1, '', NULL, '7.000', 1, '7.000', 'Exclusive', '43.000', '10.000', '10.000', '2.000', NULL, '37.34.206.9', '37.34.206.9', '2021-09-13', '06:04:56 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (10, 'IT0010', '', 'Hikvision  3 MP  HD   WDR   EXIR Turret   Camera Indoor  3.6mm   Model   DS-2CE56F7T-ITM', '', 1, '', '', 15, 0, 1, '', NULL, '11.000', 1, '11.000', 'Exclusive', '27.000', '14.000', '14.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-09-20', '06:22:04 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (11, 'IT0011', '', 'Hikvision  5  MP  HD   WDR    Turbo HD  Camera    Indoor  2.8 mm   Model   DS-2CE76HOT-ITPF', '', 1, '', '', 15, 0, 1, '', NULL, '7.500', 1, '7.500', 'Exclusive', '60.000', '12.000', '12.000', '0.000', NULL, '37.34.206.9', '37.34.206.9', '2021-09-20', '06:47:29 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (12, 'IT0012', '', 'Hikvision  5  MP HD   WDR  Turbo HD   Camera   Outdoor  2.8 mm   Model   DS-2CE16HOT-ITPF', '', 1, '', '', 15, 0, 1, '', NULL, '7.000', 1, '7.000', 'Exclusive', '71.000', '12.000', '12.000', '0.000', NULL, '37.34.206.9', '37.34.206.9', '2021-09-20', '06:52:51 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (13, 'IT0013', '', 'Hikvision  4 K   HD   WDR        Turbo HD    Camera   In door  2.8 mm   Model   DS-2CE76U1T-ITPF', '', 1, '', '', 15, 0, 1, '', NULL, '12.000', 1, '12.000', 'Exclusive', '25.000', '15.000', '15.000', '0.000', NULL, '37.34.206.9', '37.34.206.9', '2021-09-20', '06:53:54 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (14, 'IT0014', '', 'Hikvision  4 K   HD   WDR        Turbo HD    Camera   Outdoor   2.8 mm   Model   DS-2CE76U1T-ITPF', '', 1, '', '', 15, 0, 1, '', NULL, '12.500', 1, '12.500', 'Exclusive', '20.000', '15.000', '15.000', '0.000', NULL, '37.34.206.9', '37.34.206.9', '2021-09-20', '06:55:21 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (15, 'IT0015', '', 'Hikvision 4 MP Bullet  Wireless Network Camera Outdoor Build in  Microphone DS-2CD2041G1-IDW1', '', 1, '', '', 15, 0, 1, '', NULL, '28.000', 1, '28.000', 'Exclusive', '25.000', '35.000', '35.000', '0.000', NULL, '37.34.206.9', '37.34.206.9', '2021-09-20', '06:56:31 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (16, 'IT0016', '', 'Hikvision  4  MP   Bullet  Wireless  Network   Camera Outdoor   2.8 mm   Model   DS-2CD2043G0-I', '', 1, '', '', 15, 0, 1, '', NULL, '18.000', 1, '18.000', 'Exclusive', '22.000', '22.000', '22.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-09-20', '06:57:29 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (17, 'IT0017', '', 'Hikvision  4  MP   Indoor Doom Camera  Model  DS-2CD2143GO/1', '', 1, '', '', 15, 0, 1, '', NULL, '21.000', 1, '21.000', 'Exclusive', '19.000', '25.000', '25.000', '0.000', NULL, '37.34.206.9', '37.34.206.9', '2021-09-20', '06:58:23 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (18, 'IT0018', '', 'Hikvision  4 MP   Network  Outdoor Camera   Acusense  Fixed 2.8 mm  Model DS-2CD2043G2-I', '', 1, '', '', 15, 0, 1, '', NULL, '18.000', 1, '18.000', 'Exclusive', '33.000', '24.000', '24.000', '5.000', NULL, '37.34.206.9', '37.34.206.9', '2021-09-20', '06:59:27 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (19, 'IT0019', '', 'Hikvision  4 MP   Network  Exir  Fixed  Dome  Camera   2.8 mm  Model DS-2CD2143g2-I', '', 1, '', '', 15, 0, 1, '', NULL, '21.000', 1, '21.000', 'Exclusive', '19.000', '25.000', '25.000', '11.000', NULL, '37.34.206.9', '37.34.206.9', '2021-09-20', '07:00:22 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (20, 'IT0020', '', 'Hikvision  ZOOM  Vari-Focal ,  Network /Water Proof , Vandal-Proof / Alarm/Audio DS-2CD2742FWD-IZ-C ', '', 1, '', '', 15, 0, 1, '', NULL, '38.000', 1, '38.000', 'Exclusive', '18.000', '45.000', '45.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-09-20', '07:01:31 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (21, 'IT0021', '', 'Hikvision 4 MP   EXIR    Vari-Focal ,  Network  , Vandal-Resistant  Dome DS-2CD2741GO-IZS/MD 2.7-13.', '', 1, '', '', 15, 0, 1, '', NULL, '29.000', 1, '29.000', 'Exclusive', '21.000', '35.000', '35.000', '3.000', NULL, '37.34.206.9', '37.34.206.9', '2021-09-20', '07:03:11 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (22, 'IT0022', '', 'Hikvision 8 MP Exir  Fixed  Dome  Network Camera , Weather Proof , Vandal 2.8 mm Model DS-2CD2083GO-', '', 1, '', '', 15, 0, 1, '', NULL, '32.000', 1, '32.000', 'Exclusive', '25.000', '40.000', '40.000', '2.000', NULL, '37.34.206.9', '37.34.206.9', '2021-09-20', '07:08:16 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (23, 'IT0023', '', 'Hikvision 4 MP Motorized Exir /WDR/ Weather Proof/ Vandal-Resistant/ 2.7-12mm  Model DS-2CD2645FWD-I', '', 1, '', '', 15, 0, 1, '', NULL, '40.000', 1, '40.000', 'Exclusive', '25.000', '50.000', '50.000', '0.000', NULL, '37.34.206.9', '37.34.206.9', '2021-09-20', '07:09:18 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (25, 'IT0025', '', 'Time Attendace  UA 300  / S30  Finger / Card / Pin /  ADMS', '', 5, '', '', 15, 0, 39, '', NULL, '30.000', 1, '30.000', 'Exclusive', '93.000', '58.000', '58.000', '0.000', NULL, '37.34.206.9', '37.34.206.9', '2021-09-21', '03:52:18 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (26, 'IT0026', '', 'Speed  Face  C5L-P-M  Face / Card / Palm /  Mask / Door Access / Wi-Fi/ Intercom', '', 5, '', '', 15, 0, 39, '', NULL, '45.000', 1, '45.000', 'Exclusive', '89.000', '85.000', '85.000', '3.000', NULL, '37.34.206.9', '37.34.206.9', '2021-09-21', '03:53:32 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (27, 'IT0027', '', 'Speed  Face    V5L-TI-P-M Finger/  Face / Card / Palm /    Mask / Door Access / Wi-Fi/  Temperature/', '', 5, '', '', 15, 0, 39, '', NULL, '165.000', 1, '165.000', 'Exclusive', '36.000', '225.000', '225.000', '6.000', NULL, '37.34.206.9', '37.34.206.9', '2021-09-21', '03:55:05 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (28, 'IT0028', '', 'UF 100- ID /Finger / Face / Card / pin / Door Access / WiFi', '', 5, '', '', 15, 0, 39, '', NULL, '32.000', 1, '32.000', 'Exclusive', '88.000', '60.000', '60.000', '4.000', NULL, '37.34.206.9', '37.34.206.9', '2021-09-21', '03:56:11 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (29, 'IT0029', '', 'Speed Face V5L-P-M  / Face / Finger / Card / Palm / ADMS / Time Att / Door Access/ WiFi', '', 5, '', '', 15, 0, 39, '', NULL, '69.000', 1, '69.000', 'Exclusive', '97.000', '128.000', '128.000', '18.000', NULL, '37.34.206.9', '37.34.206.9', '2021-09-21', '03:58:15 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (30, 'IT0030', '', 'IT Maintenance &amp; Support monthly charges (1st September 2021 - 30th September 2021)', '', 26, '', '', 15, 0, 19, '', NULL, '250.000', 1, '250.000', 'Exclusive', NULL, '250.000', '250.000', '0.000', NULL, '37.34.206.9', '37.34.206.9', '2021-09-29', '06:53:41 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (31, 'IT0031', '0', 'Hikvision  2  MP   Turbo  HD   Camera Indoor  2.8MM    Model   DS-2CE56DOT-IRP', NULL, 1, '121', '', 15, 5, 16, '', NULL, '6.000', 2, '6.000', 'Exclusive', NULL, '0.000', '0.000', '0.000', NULL, '37.34.206.9', '37.34.206.9', '2021-10-04', '02:57:07 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (35, 'IT0035', '0', 'Hikvision  2  MP   Turbo  HD   Camera Indoor  2.8MM    Model   DS-2CE56DOT-IRP', NULL, 1, '121', '', 15, 5, 16, '', NULL, '6.000', 2, '6.000', 'Exclusive', NULL, '0.000', '0.000', '0.000', NULL, '37.34.206.9', '37.34.206.9', '2021-10-04', '02:57:27 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (39, 'IT0039', '0', 'Hikvision  2  MP   Turbo  HD   Camera Indoor  2.8MM    Model   DS-2CE56DOT-IRP', NULL, 1, '121', '', 15, 5, 16, '10', '2022-12-12', '6.000', 2, '6.000', 'Exclusive', NULL, '0.000', '0.000', '0.000', NULL, '37.34.206.9', '37.34.206.9', '2021-10-04', '02:59:19 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (43, 'IT0043', '', '20 MM  (  3/4 &#039;&#039;  )   PVC   Pipe    White', '', 9, '', '', 15, 0, 12, '', NULL, '0.290', 1, '0.290', 'Exclusive', '21.000', '0.350', '0.350', '0.000', NULL, '37.34.206.9', '37.34.206.9', '2021-10-13', '06:52:51 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (44, 'IT0044', '', 'Kuwes  Angle  Type  Face plate     Double   Port   with   Modular', '', 8, '', '', 15, 0, 11, '', NULL, '1.200', 1, '1.200', 'Exclusive', '67.000', '2.000', '2.000', '15.000', NULL, '37.34.206.9', '37.34.206.9', '2021-10-18', '07:06:48 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (45, 'IT0045', '', 'Kuwes  Angle  Type  Face plate    Single  Port   with   Modular', '', 8, '', '', 15, 0, 11, '', NULL, '0.700', 1, '0.700', 'Exclusive', '79.000', '1.250', '1.250', '35.000', NULL, '37.34.206.9', '37.34.206.9', '2021-10-18', '07:08:34 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (46, 'IT0046', '', 'Kuwes  Angle  Type  Face plate     Double   Port   .', '', 8, '', '', 15, 0, 11, '', NULL, '0.600', 1, '0.600', 'Exclusive', '25.000', '0.750', '0.750', '0.000', NULL, '37.34.206.9', '37.34.206.9', '2021-10-18', '07:11:11 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (47, 'IT0047', '', 'Kuwes  Angle  Type  Face plate     Single   Port   .', '', 8, '', '', 15, 0, 11, '', NULL, '0.500', 1, '0.500', 'Exclusive', '50.000', '0.750', '0.750', '14.000', NULL, '37.34.206.9', '37.34.206.9', '2021-10-18', '07:12:37 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (48, 'IT0048', '', 'OSCOO 16GB RAM Memory  DDR4  For Desktop  Computer  .', '', 3, '', '', 15, 0, 42, '', NULL, '24.000', 1, '24.000', 'Exclusive', '21.000', '29.000', '29.000', '6.000', NULL, '37.34.206.9', '37.34.206.9', '2021-10-18', '07:24:33 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (49, 'IT0049', '', 'OSCOO 16GB RAM Memory   DDR4    For   Laptop   .', '', 3, '', '', 15, 0, 42, '', NULL, '24.000', 1, '24.000', 'Exclusive', '21.000', '29.000', '29.000', '8.000', NULL, '37.34.206.9', '37.34.206.9', '2021-10-18', '07:26:21 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (50, 'IT0050', '', 'NVMe   M.2   Solid  State   Drive    1000 GB', '', 3, '', '', 15, 0, 43, '', NULL, '34.000', 1, '34.000', 'Exclusive', '15.000', '39.000', '39.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-10-18', '07:33:57 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (51, 'IT0051', '', 'NVME   M.2   Solid  State   Drive   512 GB', '', 4, '', '', 15, 0, 42, '', NULL, '17.000', 1, '17.000', 'Exclusive', '29.000', '22.000', '22.000', '4.000', NULL, '37.34.206.9', '37.34.206.9', '2021-10-18', '07:37:48 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (52, 'IT0052', '', 'Kaspersky   Anti- Virus', '', 31, '', '', 15, 0, 44, '', NULL, '2.000', 1, '2.000', 'Exclusive', '300.000', '8.000', '8.000', '10.000', NULL, '37.34.206.9', '37.34.206.9', '2021-10-18', '07:54:40 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (53, 'IT0053', '', 'Vention  .  DP  to  HDMI   Converter', '', 3, '', '', 15, 0, 45, '', NULL, '3.500', 1, '3.500', 'Exclusive', '71.000', '6.000', '6.000', '5.000', NULL, '37.34.206.9', '37.34.206.9', '2021-10-18', '07:59:02 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (54, 'IT0054', '', 'Tass 30 A  (  CF 230A  )   Black Toner', '', 28, '', '', 15, 0, 27, '', NULL, '3.500', 1, '3.500', 'Exclusive', '43.000', '5.000', '5.000', '0.000', NULL, '37.34.206.9', '37.34.206.9', '2021-10-19', '03:37:47 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (55, 'IT0055', '', 'Tass  83 A  ( CF283A  )   Black Toner', '', 28, '', '', 15, 0, 27, '', NULL, '2.250', 1, '2.250', 'Exclusive', '122.000', '5.000', '5.000', '0.000', NULL, '37.34.206.9', '37.34.206.9', '2021-10-19', '03:40:20 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (56, 'IT0056', '', 'Toshiba  1 TB   Hard  Drive   For  Laptop .', '', 32, '', '', 15, 0, 46, '', NULL, '12.000', 1, '12.000', 'Exclusive', '25.000', '15.000', '15.000', '8.000', NULL, '37.34.206.9', '37.34.206.9', '2021-10-20', '07:23:56 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (57, 'IT0057', '', 'Western Digital   1 TB   Hard  Drive   For  Laptop .', '', 32, '', '', 15, 0, 47, '', NULL, '12.000', 1, '12.000', 'Exclusive', '25.000', '15.000', '15.000', '5.000', NULL, '37.34.206.9', '37.34.206.9', '2021-10-20', '07:25:41 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (58, 'IT0058', '', 'Seagate   1 TB   Hard  Drive   For  Laptop .', '', 32, '', '', 15, 0, 30, '', NULL, '12.000', 1, '12.000', 'Exclusive', '25.000', '15.000', '15.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-10-20', '07:27:11 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (59, 'IT0059', '', 'IT Maintenance &amp; Support monthly charges (1st  November- 2021 - 30th  October 2021)', '', 26, '', '', 15, 0, 19, '', NULL, '12.500', 1, '12.500', 'Exclusive', NULL, '12.500', '12.500', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-10-25', '11:36:38 am', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (60, 'IT0060', '', 'NVME   M.2  Solid  State Drive  256  GB', '', 11, '', '', 15, 0, 48, '', NULL, '11.250', 1, '11.250', 'Exclusive', '33.000', '15.000', '15.000', '3.000', NULL, '37.34.206.9', '37.34.206.9', '2021-10-25', '04:51:21 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (61, 'IT0061', '', 'NVME   M.2      Solid State Drive   500 GB  V-NAND  SSD    970 EVO   PLUS   S/N S58SNMFR106956', '', 11, '', '', 15, 0, 49, '', NULL, '26.000', 1, '26.000', 'Exclusive', '38.000', '36.000', '36.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-10-25', '04:54:48 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (62, 'IT0062', '', 'NVME    M.2    Solid State  Drive  250  GB    NM610', '', 11, '', '', 15, 0, 21, '', NULL, '11.250', 1, '11.250', 'Exclusive', '33.000', '15.000', '15.000', '0.000', NULL, '37.34.206.9', '37.34.206.9', '2021-10-25', '06:04:44 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (63, 'IT0063', '', '2.5&quot;  Sata  3   Solid State  Drive  1 TB   Twinmos  Made in    Taiwan', '', 11, '', '', 15, 0, 50, '', NULL, '27.500', 1, '27.500', 'Exclusive', '24.000', '34.000', '34.000', '0.000', NULL, '37.34.206.9', '37.34.206.9', '2021-10-25', '06:17:06 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (64, 'IT0064', '', '2.5&quot;  Sata  3.0   Solid State  Drive    Model  T253X2512G  .   512  GB', '', 11, '', '', 15, 0, 26, '', NULL, '16.250', 1, '16.250', 'Exclusive', '35.000', '22.000', '22.000', '0.000', NULL, '37.34.206.9', '37.34.206.9', '2021-10-25', '06:20:56 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (65, 'IT0065', '', 'HDMI KVM +  IR Extender    60.05.0040.009    HKE 12 MMA 10', '', 8, '', '', 15, 0, 51, '', NULL, '45.000', 1, '45.000', 'Exclusive', '44.000', '65.000', '65.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-10-25', '07:48:09 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (66, 'IT0066', '', 'HDMI     4K   High  Speed Cable  10 Mtr       Model  JWD-02-10', '', 33, '', '', 15, 0, 52, '', NULL, '3.500', 1, '3.500', 'Exclusive', '100.000', '7.000', '7.000', '2.000', NULL, '37.34.206.9', '37.34.206.9', '2021-10-25', '07:54:05 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (67, 'IT0067', '', 'Cabinet  15 U 600 x 600  TOTEN   DS', '', 8, '', '', 15, 0, 13, '', NULL, '55.000', 1, '55.000', 'Exclusive', '18.000', '65.000', '65.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-10-26', '02:10:10 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (68, 'IT0068', '', '3080   Dell   Optiplex   Desktop   Computer    Core i5  -10500 /  4 GB / 1 TB    SNO  :- C7RH8F3', '', 3, '', '', 15, 0, 3, '', NULL, '125.000', 1, '125.000', 'Exclusive', '8.000', '135.000', '135.000', '0.000', NULL, '37.34.206.9', '37.34.206.9', '2021-10-27', '12:59:32 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (69, 'IT0069', '', 'MTA 4GB  DDR4 RAM Memory  For  PC', '', 29, '', '', 15, 0, 12, '', NULL, '6.000', 1, '6.000', 'Exclusive', '33.000', '8.000', '8.000', '4.000', NULL, '37.34.206.9', '37.34.206.9', '2021-10-27', '01:17:11 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (70, 'IT0070', '', 'Windows 10   License', '', 26, '', '', 15, 0, 12, '', NULL, '2.500', 1, '2.500', 'Exclusive', '300.000', '10.000', '10.000', '31.000', NULL, '37.34.206.9', '37.34.206.9', '2021-10-27', '01:20:17 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (71, 'IT0071', '', 'Cat 6  Lan    Cable   (Network  Cable  )   Kuwes', '', 8, '', '', 13, 0, 11, '', NULL, '0.095', 1, '0.095', 'Exclusive', NULL, '0.095', '0.095', '595.000', NULL, '37.34.206.9', '37.34.206.9', '2021-10-27', '04:22:45 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (72, 'IT0072', '', 'Cat 6 A    Coring    LAN   Cable', '', 8, '', '', 13, 0, 53, '', NULL, '0.140', 1, '0.140', 'Exclusive', NULL, '0.140', '0.140', '1250.000', NULL, '37.34.206.9', '37.34.206.9', '2021-10-27', '04:26:19 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (73, 'IT0073', '', '3&quot; x 3&quot;   Surface Box   (  Wall  Box  )', '', 8, '', '', 15, 0, 12, '', NULL, '0.150', 1, '0.150', 'Exclusive', NULL, '0.150', '0.150', '43.000', NULL, '37.34.206.9', '37.34.206.9', '2021-10-27', '04:29:04 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (74, 'IT0074', '', '6 &quot; x 3 &quot;  Wall Box', '', 8, '', '', 15, 0, 12, '', NULL, '0.250', 1, '0.250', 'Exclusive', NULL, '0.250', '0.250', '11.000', NULL, '37.34.206.9', '37.34.206.9', '2021-10-27', '04:31:22 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (75, 'IT0075', '', '6 &quot; x 3&quot;  Camera Box', '', 8, '', '', 15, 0, 12, '', NULL, '0.750', 1, '0.750', 'Exclusive', NULL, '0.750', '0.750', '57.000', NULL, '37.34.206.9', '37.34.206.9', '2021-10-27', '04:35:09 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (76, 'IT0076', '', 'PVC   Saddle    White    25 MM       (  1&quot;  )', '', 8, '', '', 15, 0, 12, '', NULL, '0.125', 1, '0.125', 'Exclusive', NULL, '0.125', '0.125', '181.000', NULL, '37.34.206.9', '37.34.206.9', '2021-10-27', '04:45:53 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (77, 'IT0077', '', 'PVC   Saddle    White    20  MM    ( 3/4&quot; )', '', 8, '', '', 15, 0, 12, '', NULL, '0.110', 1, '0.110', 'Exclusive', NULL, '0.110', '0.110', '260.000', NULL, '37.34.206.9', '37.34.206.9', '2021-10-27', '04:48:31 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (78, 'IT0078', '', '38 MM   White    PVC   Saddle', '', 9, '', '', 15, 0, 12, '', NULL, '0.200', 1, '0.200', 'Exclusive', NULL, '0.200', '0.200', '100.000', NULL, '37.34.206.9', '37.34.206.9', '2021-10-27', '04:53:06 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (79, 'IT0079', '', '25 MM   1&quot;   White  Junction  Box  2   Way', '', 9, '', '', 15, 0, 12, '', NULL, '0.125', 1, '0.125', 'Exclusive', NULL, '0.125', '0.125', '32.000', NULL, '37.34.206.9', '37.34.206.9', '2021-10-27', '05:32:34 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (80, 'IT0080', '', '25 MM   1&quot;   White  Junction  Box  3  Way', '', 9, '', '', 15, 0, 12, '', NULL, '0.125', 1, '0.125', 'Exclusive', NULL, '0.125', '0.125', '16.000', NULL, '37.34.206.9', '37.34.206.9', '2021-10-27', '05:33:54 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (81, 'IT0081', '', '25 MM   1&quot;   White  Junction  Box  4   Way', '', 9, '', '', 15, 0, 12, '', NULL, '0.125', 1, '0.125', 'Exclusive', NULL, '0.125', '0.125', '9.000', NULL, '37.34.206.9', '37.34.206.9', '2021-10-27', '05:35:16 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (82, 'IT0082', '', 'Power Adaptor    19.50 Volt /2.31 Amp', '', 32, '', '', 15, 0, 4, '', NULL, '8.000', 1, '8.000', 'Exclusive', '75.000', '14.000', '14.000', '0.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-02', '06:41:55 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (83, 'IT0083', '', '2.5&quot; Sata 3.0 Solid State Drive    250 GB  WD  Blue', '', 11, '', '', 15, 0, 22, '', NULL, '12.000', 1, '12.000', 'Exclusive', '33.000', '16.000', '16.000', '0.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-09', '05:53:58 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (84, 'IT0084', '', 'NVME M.2 Solid State Drive 480  GB   WD  Green', '', 11, '', '', 15, 0, 22, '', NULL, '16.000', 1, '16.000', 'Exclusive', '38.000', '22.000', '22.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-09', '05:58:28 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (85, 'IT0085', '', 'NVME M.2 Solid State Drive  250 GB   WD  Blue', '', 11, '', '', 15, 0, 22, '', NULL, '14.000', 1, '14.000', 'Exclusive', '21.000', '17.000', '17.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-09', '06:00:39 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (86, 'IT0086', '', '1  TB   Hard Drive   for   PC     WD Blue', '', 11, '', '', 15, 0, 22, '', NULL, '12.000', 1, '12.000', 'Exclusive', '17.000', '14.000', '14.000', '3.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-09', '06:17:59 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (87, 'IT0087', '', '1  TB   Hard Drive   for   Camera      WD  Purple', '', 11, '', '', 15, 0, 55, '', NULL, '12.000', 1, '12.000', 'Exclusive', '25.000', '15.000', '15.000', '5.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-09', '06:19:48 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (88, 'IT0088', '', '1  TB   Hard Drive   for   PC     Seagate  Barracuda', '', 11, '', '', 15, 0, 56, '', NULL, '12.000', 1, '12.000', 'Exclusive', '17.000', '14.000', '14.000', '4.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-09', '06:21:23 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (89, 'IT0089', '', '4 TB   Hard Drive   for   Camera      WD  Purple', '', 11, '', '', 15, 0, 55, '', NULL, '30.000', 1, '30.000', 'Exclusive', '27.000', '38.000', '38.000', '2.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-09', '06:24:14 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (90, 'IT0090', '', '2 TB   Hard Drive   for   PC   Seagate  Barracuda', '', 11, '', '', 15, 0, 56, '', NULL, '15.250', 1, '15.250', 'Exclusive', '57.000', '24.000', '24.000', '8.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-09', '06:58:48 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (91, 'IT0091', '', '10 TB   Hard Drive   for    Camera    Surveillance     WD   Purple', '', 11, '', '', 15, 0, 55, '', NULL, '85.000', 1, '85.000', 'Exclusive', '24.000', '105.000', '105.000', '0.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-09', '07:02:02 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (92, 'IT0092', '', '8  TB   Hard Drive   for    Camera    Surveillance     Toshiba', '', 11, '', '', 15, 0, 46, '', NULL, '59.000', 1, '59.000', 'Exclusive', '29.000', '76.000', '76.000', '6.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-09', '07:06:11 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (93, 'IT0093', '', 'Axview CCD   Dome   Indoor   Camera  X6130ESA13510202', '', 1, '', '', 15, 0, 58, '', NULL, '3.000', 1, '3.000', 'Exclusive', '100.000', '6.000', '6.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-09', '08:48:43 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (94, 'IT0094', '', 'Axview CCD Dome Indoor Camera -X1720CF2S13510201', '', 1, '', '', 15, 0, 58, '', NULL, '3.000', 1, '3.000', 'Exclusive', '100.000', '6.000', '6.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-09', '08:50:36 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (95, 'IT0095', '', 'Axview CCD   Outdoor  Infrared  Camera   -X1720CF2513510201', '', 1, '', '', 15, 0, 58, '', NULL, '4.000', 1, '4.000', 'Exclusive', '100.000', '8.000', '8.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-09', '08:53:15 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (96, 'IT0096', '', 'Axview CCD   Outdoor  Infrared  Camera   -X7030SA13510203', '', 1, '', '', 15, 0, 58, '', NULL, '4.000', 1, '4.000', 'Exclusive', '100.000', '8.000', '8.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-09', '08:54:56 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (97, 'IT0097', '', 'Plasma   Wall  Mount    Bracket   Model  YDF-541     15-22&quot;    LED   TV', '', 1, '', '', 15, 0, 15, '', NULL, '5.000', 1, '5.000', 'Exclusive', '60.000', '8.000', '8.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-09', '08:57:57 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (98, 'IT0098', '', 'M 4.2 X  38 X # X 1.1/2 &quot;   Black    Screw', '', 11, '', '', 15, 0, 12, '', NULL, '0.050', 1, '0.050', 'Exclusive', NULL, '0.050', '0.050', '950.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-11', '04:10:16 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (99, 'IT0099', '', 'Self  Screw 6mm  White for    Metal   1&quot;', '', 11, '', '', 15, 0, 0, '', NULL, '0.025', 1, '0.025', 'Exclusive', NULL, '0.025', '0.025', '150.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-11', '04:17:28 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (100, 'IT0100', '', 'Self  Screw  3 mm   White for    Metal   1&quot;', '', 11, '', '', 15, 0, 12, '', NULL, '0.025', 1, '0.025', 'Exclusive', NULL, '0.025', '0.025', '150.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-11', '04:19:44 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (101, 'IT0101', '', 'Hikvision  4  MP  Motorized  NETWORK    Camera   Outdoor   2.7-12 mm   Model   DS-2CD2642FWD-IZS-C', '', 1, '', '', 15, 0, 1, '', NULL, '10.000', 1, '10.000', 'Exclusive', NULL, '10.000', '10.000', '30.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-11', '04:38:00 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (102, 'IT0102', '', 'WD -40    Spray', '', 11, '', '', 15, 0, 12, '', NULL, '1.500', 1, '1.500', 'Exclusive', NULL, '1.500', '1.500', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-11', '04:39:40 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (103, 'IT0103', '', 'Color Spray   Paint     White', '', 11, '', '', 15, 0, 12, '', NULL, '1.500', 1, '1.500', 'Exclusive', NULL, '1.500', '1.500', '0.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-11', '04:45:36 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (104, 'IT0104', '', 'G i   Screw for Faceplate   3.5mm  x  2&quot;   Long .', '', 11, '', '', 15, 0, 12, '', NULL, '0.050', 1, '0.050', 'Exclusive', NULL, '0.050', '0.050', '100.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-11', '04:49:53 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (105, 'IT0105', '', 'Dahua  DVR  4  Channel  . DHI-HCVR4104HS-S2', '', 1, '', '', 15, 0, 60, '', NULL, '15.000', 1, '15.000', 'Exclusive', NULL, '20.000', '20.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-11', '05:36:14 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (106, 'IT0106', '', '4 Channel    DVR   H.264    X3000W4113510204', '', 11, '', '', 15, 0, 12, '', NULL, '15.000', 1, '15.000', 'Exclusive', '33.000', '20.000', '20.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-11', '05:47:22 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (107, 'IT0107', '', 'UNV      NVR   301-08-P8      8 Port', '', 1, '', '', 15, 0, 61, '', NULL, '35.000', 1, '35.000', 'Exclusive', '14.000', '40.000', '40.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-11', '05:56:48 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (108, 'IT0108', '', 'G 3  Time Attendance  6160062171378  , 6160062171379  ,', '', 5, '', '', 15, 0, 39, '', NULL, '90.000', 1, '90.000', 'Exclusive', '106.000', '185.000', '185.000', '2.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-11', '06:12:48 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (109, 'IT0109', '', 'ZKTeco Fingerprint Time Attendance', '', 5, '', '', 15, 0, 62, '', NULL, '28.000', 1, '28.000', 'Exclusive', '25.000', '35.000', '35.000', '4.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-11', '06:18:09 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (110, 'IT0110', '', 'Door  Exit    Push   Button  Steel', '', 5, '', '', 15, 0, 12, '', NULL, '5.000', 1, '5.000', 'Exclusive', '60.000', '8.000', '8.000', '9.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-11', '08:14:42 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (111, 'IT0111', '', 'Door  Exit    NO Touch  Button  Steel', '', 5, '', '', 15, 0, 12, '', NULL, '6.000', 1, '6.000', 'Exclusive', '100.000', '12.000', '12.000', '43.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-11', '08:18:22 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (112, 'IT0112', '', 'NO Touch   Exit   Sensor', '', 5, '', '', 15, 0, 12, '', NULL, '6.000', 1, '6.000', 'Exclusive', '67.000', '10.000', '10.000', '27.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-11', '08:21:49 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (113, 'IT0113', '', 'No  Touch   Exit  with   Remote   Control', '', 5, '', '', 15, 0, 12, '', NULL, '10.000', 1, '10.000', 'Exclusive', '80.000', '18.000', '18.000', '6.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-11', '08:23:41 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (114, 'IT0114', '', 'Electro   Magnetic    Lock       XM-M280  280 KG EM   Lock  with   LED', '', 5, '', '', 15, 0, 12, '', NULL, '8.000', 1, '8.000', 'Exclusive', '25.000', '15.000', '15.000', '39.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-11', '08:28:37 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (115, 'IT0115', '', 'Z-  Bracket   for Electro Magnetic Lock', '', 7, '', '', 15, 0, 0, '', NULL, '2.000', 1, '2.000', 'Exclusive', '75.000', '3.500', '3.500', '32.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-11', '08:46:45 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (116, 'IT0116', '', 'Z &amp;  L    Bracket   for Electro Magnetic Lock', '', 7, '', '', 15, 0, 0, '', NULL, '3.000', 1, '3.000', 'Exclusive', '100.000', '6.000', '6.000', '7.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-11', '08:48:40 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (117, 'IT0117', '', '12 Volt  / 2 Amp Power Adapter    for   Camera', '', 1, '', '', 15, 0, 12, '', NULL, '0.750', 1, '0.750', 'Exclusive', '233.000', '2.500', '2.500', '13.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-11', '09:00:31 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (118, 'IT0118', '', '12 Volt / 2.5  Amp Power Adapter for Camer', '', 1, '', '', 15, 0, 12, '', NULL, '1.000', 1, '1.000', 'Exclusive', '200.000', '3.000', '3.000', '8.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-11', '09:04:33 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (119, 'IT0119', '', '12 Volt / 3  Amp Power Adapter for Camera', '', 1, '', '', 15, 0, 12, '', NULL, '1.250', 1, '1.250', 'Exclusive', '180.000', '3.500', '3.500', '9.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-11', '09:06:12 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (120, 'IT0120', '', '5 Volt  2 Amp  Power Adapter', '', 7, '', '', 15, 0, 12, '', NULL, '1.250', 1, '1.250', 'Exclusive', '140.000', '3.000', '3.000', '7.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-11', '09:09:25 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (121, 'IT0121', '', 'TL-R480T. TP-Link Load Balance .5port broadband Router,3 con wan,LAN,,1LAN,1Wan .', '', 8, '', '', 15, 0, 6, '', NULL, '49.000', 1, '49.000', 'Exclusive', '12.000', '55.000', '55.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-15', '10:24:52 am', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (122, 'IT0122', '', 'LGS 328 P   Linksys  24 port Switch   poe + Gigab', '', 8, '', '', 15, 0, 9, '', NULL, '130.000', 1, '130.000', 'Exclusive', '12.000', '145.000', '145.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-15', '10:27:59 am', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (123, 'IT0123', '', 'UNV 24 Port Switch', '', 8, '', '', 15, 0, 61, '', NULL, '48.000', 1, '48.000', 'Exclusive', '31.000', '63.000', '63.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-15', '10:35:35 am', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (124, 'IT0124', '', 'DVR 8 Channnel Hikvision 7208HUHI-M1/S', '', 34, '', '', 15, 0, 1, '', NULL, '35.000', 1, '35.000', 'Exclusive', '43.000', '50.000', '50.000', '4.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-15', '10:53:35 am', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (125, 'IT0125', '', 'Hikvision NVR - DS-7608N1 - K1 / 8P', '', 35, '', '', 15, 0, 1, '', NULL, '42.000', 1, '42.000', 'Exclusive', '36.000', '57.000', '57.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-15', '11:01:54 am', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (126, 'IT0126', '', 'Hikvision NVR - DS-7608N1 - K2 / 8P', '', 35, '', '', 15, 0, 1, '', NULL, '47.000', 1, '47.000', 'Exclusive', '32.000', '62.000', '62.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-15', '11:03:13 am', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (127, 'IT0127', '', 'EnHero 5 EnGenius AC 1300 Ultra Range Accesspoint  204236956 .', '', 36, '', '', 15, 0, 63, '', NULL, '29.000', 1, '29.000', 'Exclusive', '21.000', '35.000', '35.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-15', '11:10:43 am', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (128, 'IT0128', '', 'Dell Laptop Bag', '', 37, '', '', 15, 0, 3, '', NULL, '1.250', 1, '1.250', 'Exclusive', '140.000', '3.000', '3.000', '2.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-15', '11:34:20 am', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (129, 'IT0129', '', 'Laptop Bag', '', 37, '', '', 15, 0, 0, '', NULL, '1.000', 1, '1.000', 'Exclusive', '100.000', '2.000', '2.000', '2.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-15', '11:35:54 am', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (130, 'IT0130', '', 'Cisco  Linksys  Switch 24 Port.   10 / 100   Model  SF 100-24. SL NO  PSZ18251', '', 8, '', '', 15, 0, 8, '', NULL, '25.000', 1, '25.000', 'Exclusive', '28.000', '32.000', '32.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-15', '11:44:26 am', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (131, 'IT0131', '', 'TP Link Router TL - WR840N - 300mbps', '', 8, '', '', 15, 0, 6, '', NULL, '5.500', 1, '5.500', 'Exclusive', '118.000', '12.000', '12.000', '5.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-15', '11:58:22 am', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (132, 'IT0132', '', 'Linksys Wifi Router N300 Model E900 - ME', '', 8, '', '', 15, 0, 9, '', NULL, '8.000', 1, '8.000', 'Exclusive', '88.000', '15.000', '15.000', '2.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-15', '01:01:22 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (133, 'IT0133', '', 'TP Link Wireless Access Point Model TL-WA801ND', '', 36, '', '', 15, 0, 6, '', NULL, '13.000', 1, '13.000', 'Exclusive', '23.000', '16.000', '16.000', '0.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-15', '01:03:03 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (134, 'IT0134', '', 'Wireless IP camera  PTZ 2 MP   HD Camera Model - PB205-Y1', '', 1, '', '', 15, 0, 0, '', NULL, '10.000', 1, '10.000', 'Exclusive', '80.000', '18.000', '18.000', '10.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-15', '02:41:17 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (135, 'IT0135', '', 'TP-Link 300MbPs Mini Wireless USB Adapter', '', 8, '', '', 15, 0, 6, '', NULL, '2.250', 1, '2.250', 'Exclusive', '122.000', '5.000', '5.000', '10.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-15', '02:46:05 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (136, 'IT0136', '', 'TP-Link AC600 Nano Wireless USB Adapter', '', 8, '', '', 15, 0, 6, '', NULL, '4.000', 1, '4.000', 'Exclusive', '100.000', '8.000', '8.000', '3.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-15', '02:51:31 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (137, 'IT0137', '', 'D-Link 5 port Gigabit Easy Desktop Switch', '', 8, '', '', 15, 0, 7, '', NULL, '4.000', 1, '4.000', 'Exclusive', '100.000', '8.000', '8.000', '4.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-15', '02:58:45 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (138, 'IT0138', '', 'SSD 480GB Crucial BX500 2.5&quot; CT480BX500 SSD1', '', 11, '', '', 15, 0, 43, '', NULL, '14.500', 1, '14.500', 'Exclusive', '52.000', '22.000', '22.000', '4.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-16', '09:44:54 am', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (139, 'IT0139', '', 'Dell Latitude 5520 i5-1135g7/4GB/256GB SSD/ 15.6&quot; FHD', '', 4, '', '', 15, 0, 3, '', NULL, '219.000', 1, '219.000', 'Exclusive', NULL, '219.000', '219.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-16', '09:50:14 am', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (140, 'IT0140', '', 'SSD 500GB Nvme WD Black Gen-4 M.2 WDS500G1X0E', '', 4, '', '', 15, 0, 64, '', NULL, '40.000', 1, '40.000', 'Exclusive', NULL, '40.000', '40.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-16', '09:53:00 am', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (141, 'IT0141', '', 'Ram NoteBook 32GB D4 3200 Crucial CT32G4SFD832A', '', 4, '', '', 15, 0, 43, '', NULL, '51.000', 1, '51.000', 'Exclusive', NULL, '51.000', '51.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-16', '09:54:08 am', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (142, 'IT0142', '', 'ZKTeco SC700 Access Control', '', 7, '', '', 15, 0, 39, '', NULL, '28.000', 1, '28.000', 'Exclusive', '100.000', '56.000', '56.000', '0.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-16', '10:12:44 am', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (143, 'IT0143', '', 'HDMI Cable 5 Mtr Long 4K', '', 33, '', '', 15, 0, 65, '', NULL, '2.500', 1, '2.500', 'Exclusive', '80.000', '4.500', '4.500', '4.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-16', '10:15:34 am', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (144, 'IT0144', '', 'HDMI Cable 3 Mtr', '', 33, '', '', 15, 0, 12, '', NULL, '0.750', 1, '0.750', 'Exclusive', '100.000', '1.500', '1.500', '0.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-16', '10:17:15 am', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (145, 'IT0145', '', 'Linksys Access Point Model WAP300N', '', 36, '', '', 15, 0, 9, '', NULL, '19.000', 1, '19.000', 'Exclusive', '47.000', '28.000', '28.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-16', '10:18:23 am', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (146, 'IT0146', '', 'Hikvision DVR 8Ch Model- DS-7108HGHI-F1/L', '', 34, '', '', 15, 0, 1, '', NULL, '13.000', 1, '13.000', 'Exclusive', '54.000', '20.000', '20.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-16', '10:20:09 am', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (147, 'IT0147', '', 'D-Link 10 Port Gigabit Long Range POE + Surveillance Switch Model : DGS-F1010 P-E', '', 8, '', '', 15, 0, 7, '', NULL, '23.000', 1, '23.000', 'Exclusive', '39.000', '32.000', '32.000', '5.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-16', '10:22:53 am', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (148, 'IT0148', '', 'D-Link 5 Port 10/100 Mbps Desktop Switch DES-1005C', '', 8, '', '', 15, 0, 7, '', NULL, '1.650', 1, '1.650', 'Exclusive', '142.000', '4.000', '4.000', '2.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-16', '12:13:35 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (149, 'IT0149', '', 'TP-link N600 Wireless Dual Band Gigabit Ceiling Mount Access Point Model-EAP220', '', 36, '', '', 15, 0, 6, '', NULL, '28.000', 1, '28.000', 'Exclusive', '36.000', '38.000', '38.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-16', '12:16:53 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (150, 'IT0150', '', 'TP-Link Extender Wifi Range AC750', '', 8, '', '', 15, 0, 6, '', NULL, '8.000', 1, '8.000', 'Exclusive', '50.000', '12.000', '12.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-16', '12:20:05 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (151, 'IT0151', '', 'TP-Link 300Mbps wifi Range Extender', '', 8, '', '', 15, 0, 6, '', NULL, '11.000', 1, '11.000', 'Exclusive', '27.000', '14.000', '14.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-16', '12:21:27 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (152, 'IT0152', '', 'D-Link 8 Port 10/100 Desktop Switch', '', 8, '', '', 15, 0, 7, '', NULL, '2.250', 1, '2.250', 'Exclusive', '167.000', '6.000', '6.000', '2.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-16', '12:22:41 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (153, 'IT0153', '', 'TP-Link AC600 High Gain Wireless Dual Band USB Adapter', '', 8, '', '', 15, 0, 6, '', NULL, '7.000', 1, '7.000', 'Exclusive', '57.000', '11.000', '11.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-16', '12:23:54 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (154, 'IT0154', '', 'Dahua DH-HAC-HDW-1200mp Indoor 2.4MP Camera', '', 1, '', '', 15, 0, 60, '', NULL, '6.000', 1, '6.000', 'Exclusive', '33.000', '8.000', '8.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-16', '12:26:08 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (155, 'IT0155', '', 'Dahua 1MP Camera Indoor', '', 1, '', '', 15, 0, 60, '', NULL, '6.000', 1, '6.000', 'Exclusive', '33.000', '8.000', '8.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-16', '12:27:08 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (156, 'IT0156', '', 'ZKTeco F18 Access Control', '', 7, '', '', 15, 0, 39, '', NULL, '40.000', 1, '40.000', 'Exclusive', '113.000', '85.000', '85.000', '9.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-16', '12:30:31 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (157, 'IT0157', '', 'ZKTeco F22 Access Control and Time Attendance', '', 5, '', '', 15, 0, 39, '', NULL, '32.000', 1, '32.000', 'Exclusive', '113.000', '68.000', '68.000', '2.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-16', '12:48:37 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (158, 'IT0158', '', 'Kasper Antivirus', '', 26, '', '', 15, 0, 44, '', NULL, '2.500', 1, '2.500', 'Exclusive', '220.000', '8.000', '8.000', '10.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-16', '12:50:15 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (159, 'IT0159', '', 'DP to HDMI  Converter', '', 11, '', '', 15, 0, 45, '', NULL, '3.500', 1, '3.500', 'Exclusive', '86.000', '6.500', '6.500', '4.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-16', '12:53:02 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (160, 'IT0160', '', 'My Passport 1TB', '', 11, '', '', 15, 0, 47, '', NULL, '13.000', 1, '13.000', 'Exclusive', '100.000', '26.000', '26.000', '2.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-16', '12:55:32 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (161, 'IT0161', '', 'Web cam SP-11', '', 1, '', '', 15, 0, 12, '', NULL, '5.000', 1, '5.000', 'Exclusive', '60.000', '8.000', '8.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-16', '12:57:48 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (162, 'IT0162', '', 'Web Cam Logitech C310 HD', '', 1, '', '', 15, 0, 10, '', NULL, '11.000', 1, '11.000', 'Exclusive', '36.000', '15.000', '15.000', '2.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-16', '12:58:51 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (163, 'IT0163', '', 'UBIQUITI Access Point Unifi', '', 36, '', '', 15, 0, 66, '', NULL, '35.000', 1, '35.000', 'Exclusive', '29.000', '45.000', '45.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-17', '09:40:49 am', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (164, 'IT0164', '', 'Nano Station M5', '', 36, '', '', 15, 0, 66, '', NULL, '63.000', 1, '63.000', 'Exclusive', '37.000', '86.000', '86.000', '2.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-17', '09:43:45 am', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (165, 'IT0165', '', 'Cisco WAP 131', '', 8, '', '', 15, 0, 8, '', NULL, '36.000', 1, '36.000', 'Exclusive', '25.000', '45.000', '45.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-17', '09:46:56 am', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (166, 'IT0166', '', 'HAING USB Head Set', '', 38, '', '', 15, 0, 67, '', NULL, '4.000', 1, '4.000', 'Exclusive', '63.000', '6.500', '6.500', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-17', '10:23:49 am', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (167, 'IT0167', '', 'D-Link 8 Port Gigabit Switch - DGS-1008A', '', 8, '', '', 15, 0, 7, '', NULL, '5.500', 1, '5.500', 'Exclusive', '64.000', '9.000', '9.000', '5.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-17', '10:29:13 am', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (168, 'IT0168', '', 'Hikvision Intercom Main Unit DS-KD8003-IME1', '', 39, '', '', 15, 0, 1, '', NULL, '36.000', 1, '36.000', 'Exclusive', '28.000', '46.000', '46.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-17', '10:33:31 am', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (169, 'IT0169', '', 'Dell Wireless Mouse WM126-BK', '', 40, '', '', 15, 0, 3, '', NULL, '3.500', 1, '3.500', 'Exclusive', '29.000', '4.500', '4.500', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-17', '10:35:56 am', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (170, 'IT0170', '', 'Asus Geforce GTX-1650 4GB Graphics Card', '', 41, '', '', 15, 0, 68, '', NULL, '55.000', 1, '55.000', 'Exclusive', '18.000', '65.000', '65.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-17', '12:20:55 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (171, 'IT0171', '', 'Hybrid Network Digital Video Recorder', '', 35, '', '', 15, 0, 69, '', NULL, '20.000', 1, '20.000', 'Exclusive', '25.000', '25.000', '25.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-17', '12:24:27 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (172, 'IT0172', '', 'UNV 4MP Outdoor Camera - Mini Bullet Network Camera', '', 1, '', '', 15, 0, 61, '', NULL, '16.000', 1, '16.000', 'Exclusive', '31.000', '21.000', '21.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-17', '12:26:13 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (173, 'IT0173', '', 'ZKTeco XM28 FingerPrint Access Control', '', 7, '', '', 15, 0, 39, '', NULL, '25.000', 1, '25.000', 'Exclusive', NULL, '25.000', '25.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-17', '12:29:23 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (174, 'IT0174', '', 'Digital Video Camera 2.2MP Water Proof', '', 1, '', '', 15, 0, 12, '', NULL, '26.000', 1, '26.000', 'Exclusive', NULL, '26.000', '26.000', '3.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-17', '12:32:24 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (175, 'IT0175', '', 'Sebury Metal Access Control', '', 7, '', '', 15, 0, 70, '', NULL, '25.000', 1, '25.000', 'Exclusive', NULL, '25.000', '25.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-17', '12:33:44 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (176, 'IT0176', '', 'UNV Network Camera 4MP Indoor Vandal Proof IPC 3234SR3-DV228', '', 1, '', '', 15, 0, 61, '', NULL, '35.000', 1, '35.000', 'Exclusive', '14.000', '40.000', '40.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-17', '12:35:03 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (177, 'IT0177', '', 'OSCOO External Hard Drive Enclosure', '', 11, '', '', 15, 0, 42, '', NULL, '2.000', 1, '2.000', 'Exclusive', '150.000', '5.000', '5.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-18', '09:53:32 am', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (178, 'IT0178', '', 'Type - C to HDMI Adaptor', '', 42, '', '', 15, 0, 12, '', NULL, '5.000', 1, '5.000', 'Exclusive', '100.000', '10.000', '10.000', '0.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-18', '09:57:24 am', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (179, 'IT0179', '', 'Adaptor Bracket', '', 42, '', '', 15, 0, 12, '', NULL, '1.750', 1, '1.750', 'Exclusive', '43.000', '2.500', '2.500', '11.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-18', '09:58:30 am', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (180, 'IT0180', '', 'Frontech Optical Mouse USB MS-0011', '', 40, '', '', 15, 0, 71, '', NULL, '0.750', 1, '0.750', 'Exclusive', '100.000', '1.500', '1.500', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-18', '10:02:04 am', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (181, 'IT0181', '', 'Funlux Camera', '', 1, '', '', 15, 0, 72, '', NULL, '2.000', 1, '2.000', 'Exclusive', NULL, '2.000', '2.000', '0.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-18', '10:04:20 am', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (182, 'IT0182', '', 'Samsung SCD - 1020RN', '', 1, '', '', 15, 0, 49, '', NULL, '15.600', 1, '15.600', 'Exclusive', NULL, '15.600', '15.600', '3.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-18', '10:05:30 am', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (183, 'IT0183', '', 'Dahua 2.4MP', '', 1, '', '', 15, 0, 60, '', NULL, '6.000', 1, '6.000', 'Exclusive', NULL, '6.000', '6.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-18', '10:06:39 am', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (184, 'IT0184', '', 'Micro Door Sensor MV-100', '', 43, '', '', 15, 0, 12, '', NULL, '6.000', 1, '6.000', 'Exclusive', NULL, '6.000', '6.000', '25.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-18', '10:10:59 am', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (185, 'IT0185', '', 'C3-200 Two Door Access Control Board', '', 43, '', '', 15, 0, 12, '', NULL, '26.000', 1, '26.000', 'Exclusive', NULL, '26.000', '26.000', '3.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-18', '10:12:05 am', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (186, 'IT0186', '', 'C3-400 Teo Door Access Control Board', '', 43, '', '', 15, 0, 12, '', NULL, '30.000', 1, '30.000', 'Exclusive', NULL, '30.000', '30.000', '6.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-18', '10:13:02 am', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (187, 'IT0187', '', 'Electric  Cable  3 Core  x 0.50 mm2', ' ( 70 Yard-64  Mtr  )     per    Roll  5.250 KD', 33, '', '', 13, 0, 73, '', NULL, '0.085', 1, '0.085', 'Exclusive', NULL, '0.085', '0.085', '64.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-18', '05:51:46 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (188, 'IT0188', '', 'HP  Toner 130 A    Black', '', 28, '', '', 15, 0, 4, '', NULL, '16.250', 1, '16.250', 'Exclusive', '8.000', '17.500', '17.500', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-20', '05:14:06 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (189, 'IT0189', '', 'HP  Toner 130 A    Color', '', 28, '', '', 15, 0, 4, '', NULL, '17.250', 1, '17.250', 'Exclusive', '7.000', '18.500', '18.500', '4.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-20', '05:15:11 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (190, 'IT0190', '', 'Genius DX-125  Optical  Mouse USB', '', 40, '', '', 15, 0, 74, '', NULL, '1.500', 1, '1.500', 'Exclusive', '100.000', '3.000', '3.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-20', '05:22:14 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (191, 'IT0191', '', 'Lenovo Thinkpad Laptop   Core i7 , E15   AMD  RX640  2GB  Graphics  . Model   SLNO  PF2N5VR5', '', 4, '', '', 15, 0, 5, '', NULL, '325.000', 1, '325.000', 'Exclusive', '-89.000', '360.000', '360.000', '0.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-20', '05:37:00 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (192, 'IT0192', '', '8 GB   RAM  Memory   RAMAXEL   for  Laptop', '', 4, '', '', 15, 0, 75, '', NULL, '12.000', 1, '12.000', 'Exclusive', '25.000', '15.000', '15.000', '0.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-20', '05:46:42 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (193, 'IT0193', '', 'ZKTeco TF1700 Fingerprint and Outdoor Access Control', '', 7, '', '', 15, 0, 39, '', NULL, '35.000', 1, '35.000', 'Exclusive', '123.000', '78.000', '78.000', '3.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-21', '11:40:46 am', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (194, 'IT0194', '', 'CAT6 0.5Mtr Patch Cable Kuwes', '', 33, '', '', 15, 0, 11, '', NULL, '0.360', 1, '0.360', 'Exclusive', '67.000', '0.600', '0.600', '35.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-21', '12:05:26 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (195, 'IT0195', '', 'ZKTeco . G3  FA1-HD/4G  Facial   Time  Attendance  &amp; Access Control', '', 5, '', '', 15, 0, 39, '', NULL, '100.000', 1, '100.000', 'Exclusive', '110.000', '210.000', '210.000', '2.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-21', '12:35:05 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (196, 'IT0196', '', 'ST-1000- .  Finger print Time  Attendance   System  with Access  Control  .', '', 5, '', '', 15, 0, 76, '', NULL, '22.000', 1, '22.000', 'Exclusive', '140.000', '48.000', '48.000', '18.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-21', '02:01:57 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (197, 'IT0197', '', 'Bracket  for Time Attendance .', '', 5, '', '', 15, 0, 76, '', NULL, '3.000', 1, '3.000', 'Exclusive', '67.000', '5.000', '5.000', '6.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-21', '02:03:46 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (198, 'IT0198', '', 'APC  -Smart- UPS-C   1000 / 1500  VA   .SNO :-  3S1632X08041  .', '', 44, '', '', 15, 0, 28, '', NULL, '50.000', 1, '50.000', 'Exclusive', '220.000', '160.000', '160.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-21', '03:27:03 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (199, 'IT0199', '', 'Hikvision 4 MP   EXIR    Vari-Focal ,  Network  , Vandal-Resistant  Dome DS-2CD2741GO-IZS/MD 2.7-13.', '', 45, '', '', 15, 0, 16, '', NULL, '10.000', 1, '10.000', 'Exclusive', NULL, '10.000', '10.000', '3.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-21', '05:37:50 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (200, 'IT0200', '', 'Microsoft  Windows    Professional   64 Bit   OEM  with     DVD    Pack  .', '', 46, '', '', 15, 0, 32, '', NULL, '7.000', 1, '7.000', 'Exclusive', '471.000', '40.000', '40.000', '10.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-22', '02:40:22 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (201, 'IT0201', '', 'Microsoft Windows Server 2016  64  Bit   with    DVD   Pack .', '', 26, '', '', 15, 0, 32, '', NULL, '75.000', 1, '75.000', 'Exclusive', '147.000', '185.000', '185.000', '4.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-22', '02:46:17 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (202, 'IT0202', '', 'Microsoft Windows Server  STD   2019   64 Bit with DVD Pack', '', 46, '', '', 15, 0, 32, '', NULL, '75.000', 1, '75.000', 'Exclusive', '160.000', '195.000', '195.000', '5.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-22', '02:48:32 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (203, 'IT0203', '', 'S-Tek  Printer Cable  3 Mtr Long', '', 33, '', '', 15, 0, 33, '', NULL, '0.750', 1, '0.750', 'Exclusive', '100.000', '1.500', '1.500', '3.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-25', '04:28:42 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (204, 'IT0204', '', 'Buro 131A  /       ( CF211A   )   Cyan   Toner', 'For Mr. Anand    Home   HP  Printer  .', 28, '', '', 15, 0, 78, '', NULL, '6.000', 1, '6.000', 'Exclusive', NULL, '6.000', '6.000', '0.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-27', '08:23:51 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (205, 'IT0205', '', 'Buro 131A  /       ( CF213 A   )   Megenta    Toner', 'For  Mr.Anand  Home   HP  Printer', 28, '', '', 15, 0, 78, '', NULL, '6.000', 1, '6.000', 'Exclusive', NULL, '6.000', '6.000', '0.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-27', '08:25:40 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (206, 'IT0206', '', 'Hikvision 4 MP  PTZ   Outdoor  IP     Camera  Model DS2DE4425IWDE .', '', 1, '', '', 15, 0, 1, '', NULL, '115.000', 1, '115.000', 'Exclusive', '17.000', '135.000', '135.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-27', '08:39:11 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (207, 'IT0207', '', 'EMI Lock with LED for Glass Door', '', 7, '', '', 15, 0, 12, '', NULL, '8.000', 1, '8.000', 'Exclusive', '50.000', '12.000', '12.000', '72.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-28', '03:03:20 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (208, 'IT0208', '', 'CAT6 3Mtr Kuwes   Patch    Cord', '', 33, '', '', 15, 0, 11, '', NULL, '0.700', 1, '0.700', 'Exclusive', '186.000', '2.000', '2.000', '17.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-28', '03:05:57 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (209, 'IT0209', '', 'CAt6 2Mtr KUWES Patch Cable', '', 33, '', '', 15, 0, 0, '', NULL, '0.600', 1, '0.600', 'Exclusive', '150.000', '1.500', '1.500', '14.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-28', '03:07:06 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (210, 'IT0210', '', 'CAT6 1Mtr KUWES Patch Cable', '', 33, '', '', 15, 0, 11, '', NULL, '0.400', 1, '0.400', 'Exclusive', '150.000', '1.000', '1.000', '14.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-28', '03:08:25 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (211, 'IT0211', '', 'IT Maintenance &amp; Support monthly charges (1st November2021 - 30th November 2021)', '', 26, '', '', 15, 0, 19, '', NULL, '250.000', 1, '250.000', 'Exclusive', NULL, '250.000', '250.000', '0.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-29', '05:20:36 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (212, 'IT0212', '', 'HDMI 4K 120M KVM Extender', '', 8, '', '', 15, 0, 12, '', NULL, '18.000', 1, '18.000', 'Exclusive', '94.000', '35.000', '35.000', '6.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-30', '09:42:59 am', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (213, 'IT0213', '', 'CCTV Video Balun 5MP', '', 1, '', '', 15, 0, 12, '', NULL, '0.750', 1, '0.750', 'Exclusive', '33.000', '1.000', '1.000', '0.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-30', '09:46:24 am', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (214, 'IT0214', '', 'CCTV Video Balun 8MP', '', 1, '', '', 15, 0, 12, '', NULL, '1.000', 1, '1.000', 'Exclusive', '50.000', '1.500', '1.500', '20.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-30', '09:48:16 am', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (215, 'IT0215', '', 'Power Extension 5 Port', '', 23, '', '', 15, 0, 79, '', NULL, '2.250', 1, '2.250', 'Exclusive', '44.000', '3.250', '3.250', '2.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-30', '09:52:04 am', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (216, 'IT0216', '', 'Power Extension 4 Port', '', 23, '', '', 15, 0, 79, '', NULL, '2.000', 1, '2.000', 'Exclusive', '50.000', '3.000', '3.000', '4.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-30', '09:52:54 am', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (217, 'IT0217', '', 'Seagate   500  GB    Hard  Drive   For   Desktop  Computer', ' Received From  Used  System', 11, '', '', 15, 0, 30, '', NULL, '6.000', 1, '6.000', 'Exclusive', '33.000', '8.000', '8.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-11-30', '12:21:41 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (218, 'IT0218', '', 'Gulf  Cable 1.0 mm2  x 3 Core  Cable', '1.0 mm2  x 3 Core   Gulf   Roll    ( 73 mtr / 80 Yard )  11.500 kd   from   KND ', 33, '', '', 13, 0, 15, '', NULL, '0.160', 1, '0.160', 'Exclusive', NULL, '0.160', '0.160', '40.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-04', '01:01:56 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (219, 'IT0219', '', '13 Amp  On-OF  Socket  Single  Port', '', 12, '', '', 15, 0, 12, '', NULL, '0.450', 1, '0.450', 'Exclusive', NULL, '0.450', '0.450', '0.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-04', '01:06:28 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (220, 'IT0220', '', 'Glass Door Lock  with U  Bracket', '', 7, '', '', 15, 0, 12, '', NULL, '12.000', 1, '12.000', 'Exclusive', '67.000', '20.000', '20.000', '4.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-05', '07:06:41 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (221, 'IT0221', '', 'Trenki    PVC   NO   2', '', 23, '', '', 15, 0, 12, '', NULL, '0.250', 1, '0.250', 'Exclusive', NULL, '0.250', '0.250', '63.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-07', '12:14:50 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (222, 'IT0222', '', 'Trenki    PVC   NO   3', '', 23, '', '', 15, 0, 12, '', NULL, '0.350', 1, '0.350', 'Exclusive', NULL, '0.350', '0.350', '71.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-07', '12:25:06 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (223, 'IT0223', '', 'Trenki    PVC   NO   6', '', 23, '', '', 15, 0, 12, '', NULL, '1.500', 1, '1.500', 'Exclusive', NULL, '1.500', '1.500', '4.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-07', '12:30:15 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (224, 'IT0224', '', 'D-Link Optical Fiber  Patch Cord / Pig Tail LC/LC  SM  Duplex  2 Mtr  Long', '', 8, '', '', 15, 0, 7, '', NULL, '4.000', 1, '4.000', 'Exclusive', NULL, '4.000', '4.000', '4.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-07', '12:33:00 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (225, 'IT0225', '', 'Fiber  Patch Cord    SC-UPC  Duplex 2.0mm   3 Mtr  Long', '', 8, '', '', 15, 0, 12, '', NULL, '3.250', 1, '3.250', 'Exclusive', NULL, '3.250', '3.250', '2.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-07', '12:42:03 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (226, 'IT0226', '', 'Kuwes    Fiber  Patch Cord     LC-LC   2  Mtr  Long', '', 8, '', '', 15, 0, 11, '', NULL, '3.000', 1, '3.000', 'Exclusive', NULL, '3.000', '3.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-07', '12:45:42 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (227, 'IT0227', '', 'Fiber  Patch Cord    Pig tail  SC/ PC     Simplex', '', 8, '', '', 15, 0, 12, '', NULL, '650.000', 1, '650.000', 'Exclusive', '-100.000', '0.650', '0.650', '4.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-07', '12:48:05 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (228, 'IT0228', '', 'Graphics  Cable  3   Mtr  Long  .', '', 33, '', '', 15, 0, 12, '', NULL, '2.000', 1, '2.000', 'Exclusive', NULL, '2.000', '2.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-07', '12:51:34 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (229, 'IT0229', '', 'Graphics  Cable  5   Mtr  Long  .', '', 33, '', '', 15, 0, 12, '', NULL, '3.000', 1, '3.000', 'Exclusive', NULL, '3.000', '3.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-07', '12:52:45 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (230, 'IT0230', '', 'Crimping  Tools   Kuwes', '', 22, '', '', 15, 0, 11, '', NULL, '4.000', 1, '4.000', 'Exclusive', NULL, '4.000', '4.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-07', '12:53:57 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (232, 'IT0232', '', 'Mouse Pad', '', 23, '', '', 15, 0, 12, '', NULL, '0.500', 1, '0.500', 'Exclusive', '100.000', '1.000', '1.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-07', '01:10:54 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (233, 'IT0233', '', 'Tab Enclosure', '', 23, '', '', 15, 0, 12, '', NULL, '0.500', 1, '0.500', 'Exclusive', NULL, '0.500', '0.500', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-07', '01:15:05 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (234, 'IT0234', '', 'Head Phone HS-612', '', 23, '', '', 15, 0, 12, '', NULL, '1.000', 1, '1.000', 'Exclusive', '50.000', '1.500', '1.500', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-07', '01:17:04 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (235, 'IT0235', '', 'POE Splitter  48 Volt', '', 8, '', '', 15, 0, 12, '', NULL, '1.500', 1, '1.500', 'Exclusive', '367.000', '7.000', '7.000', '23.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-07', '01:21:38 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (236, 'IT0236', '', 'X-Cell   Wireless Mouse', '', 11, '', '', 15, 0, 12, '', NULL, '1.000', 1, '1.000', 'Exclusive', '50.000', '1.500', '1.500', '3.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-07', '02:38:34 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (237, 'IT0237', '', 'M 90  Logitech   Wire Mouse', '', 11, '', '', 15, 0, 10, '', NULL, '1.750', 1, '1.750', 'Exclusive', '43.000', '2.500', '2.500', '2.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-07', '02:41:10 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (238, 'IT0238', '', 'MS 116   Dell   Wire  Mouse', '', 11, '', '', 15, 0, 3, '', NULL, '1.750', 1, '1.750', 'Exclusive', '71.000', '3.000', '3.000', '4.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-07', '02:47:20 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (239, 'IT0239', '', 'M  185   Logitech   Wireless Mouse', '', 11, '', '', 15, 0, 10, '', NULL, '3.500', 1, '3.500', 'Exclusive', '29.000', '4.500', '4.500', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-07', '02:54:14 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (240, 'IT0240', '', 'PVC White Box 3X6', '', 8, '', '', 15, 0, 12, '', NULL, '0.250', 1, '0.250', 'Exclusive', NULL, '0.250', '0.250', '19.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-07', '02:58:08 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (241, 'IT0241', '', 'PVC White Box 3X3', '', 8, '', '', 15, 0, 12, '', NULL, '0.150', 1, '0.150', 'Exclusive', NULL, '0.150', '0.150', '13.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-07', '02:59:17 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (242, 'IT0242', '', 'GI 3X3 Box', '', 12, '', '', 15, 0, 12, '', NULL, '0.150', 1, '0.150', 'Exclusive', NULL, '0.150', '0.150', '3.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-07', '03:00:39 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (243, 'IT0243', '', 'Camera Box 4X6', '', 1, '', '', 15, 0, 12, '', NULL, '0.600', 1, '0.600', 'Exclusive', NULL, '0.600', '0.600', '3.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-07', '03:01:42 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (244, 'IT0244', '', 'HP  Wireless  Mouse  S 500', '', 11, '', '', 15, 0, 4, '', NULL, '2.750', 1, '2.750', 'Exclusive', '27.000', '3.500', '3.500', '2.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-07', '03:02:28 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (245, 'IT0245', '', 'TV Wall Mount Bracket', '', 23, '', '', 15, 0, 12, '', NULL, '3.000', 1, '3.000', 'Exclusive', '100.000', '6.000', '6.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-07', '03:04:28 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (246, 'IT0246', '', 'HP  Wireless  Mouse  S 1000', '', 11, '', '', 15, 0, 4, '', NULL, '2.750', 1, '2.750', 'Exclusive', '27.000', '3.500', '3.500', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-07', '03:12:46 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (247, 'IT0247', '', 'Dell Mouse Wireless   WM-126 BK', '', 11, '', '', 15, 0, 3, '', NULL, '3.500', 1, '3.500', 'Exclusive', '14.000', '4.000', '4.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-07', '03:15:11 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (248, 'IT0248', '', 'USB  Camera for Desktop Computer', '', 11, '', '', 15, 0, 12, '', NULL, '2.500', 1, '2.500', 'Exclusive', NULL, '2.500', '2.500', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-07', '03:17:47 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (249, 'IT0249', '', 'Dust Cover for Key Board', '', 23, '', '', 15, 0, 12, '', NULL, '0.500', 1, '0.500', 'Exclusive', NULL, '0.500', '0.500', '2.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-07', '03:19:21 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (250, 'IT0250', '', 'Printer Cable  1.80 Mtr  Long', '', 23, '', '', 15, 0, 12, '', NULL, '0.450', 1, '0.450', 'Exclusive', '122.000', '1.000', '1.000', '13.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-07', '03:20:51 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (251, 'IT0251', '', 'Printer Cable  5  Mtr  Long', '', 33, '', '', 15, 0, 12, '', NULL, '1.000', 1, '1.000', 'Exclusive', '200.000', '3.000', '3.000', '2.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-07', '03:22:17 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (252, 'IT0252', '', 'Printer Cable  3  Mtr  Long', '', 33, '', '', 15, 0, 12, '', NULL, '0.750', 1, '0.750', 'Exclusive', '100.000', '1.500', '1.500', '4.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-07', '03:24:31 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (253, 'IT0253', '', 'Power Cable for UPS', '', 33, '', '', 15, 0, 12, '', NULL, '2.500', 1, '2.500', 'Exclusive', '60.000', '4.000', '4.000', '6.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-07', '03:29:37 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (254, 'IT0254', '', 'Cat 6   Patch Cord   ,   3   Mtr  Long', '', 33, '', '', 15, 0, 12, '', NULL, '0.750', 1, '0.750', 'Exclusive', '100.000', '1.500', '1.500', '2.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-07', '03:32:50 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (255, 'IT0255', '', 'Graphics  Cable  1.8    Mtr  Long  .', '', 23, '', '', 15, 0, 12, '', NULL, '0.500', 1, '0.500', 'Exclusive', '200.000', '1.500', '1.500', '3.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-07', '03:46:49 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (256, 'IT0256', '', 'USB X USB    Cable', '', 33, '', '', 15, 0, 12, '', NULL, '0.500', 1, '0.500', 'Exclusive', '100.000', '1.000', '1.000', '5.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-07', '03:53:09 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (257, 'IT0257', '', 'USB Extension  Cable  1.500   Mtr   Long .', '', 33, '', '', 15, 0, 12, '', NULL, '0.500', 1, '0.500', 'Exclusive', '100.000', '1.000', '1.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-07', '03:55:09 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (258, 'IT0258', '', 'Printer Cable  10  Mtr  Long', '', 33, '', '', 15, 0, 12, '', NULL, '1.250', 1, '1.250', 'Exclusive', '140.000', '3.000', '3.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-07', '03:56:45 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (259, 'IT0259', '', 'C-Type  Cable for External     Hard Drive', '', 33, '', '', 15, 0, 12, '', NULL, '1.000', 1, '1.000', 'Exclusive', '100.000', '2.000', '2.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-07', '04:02:24 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (260, 'IT0260', '', 'DTECH  HDMI CABLE   4 K         3  Mtr  Long', '', 33, '', '', 15, 0, 23, '', NULL, '1.250', 1, '1.250', 'Exclusive', '140.000', '3.000', '3.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-07', '04:17:21 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (261, 'IT0261', '', 'DTECH  HDMI CABLE   4 K- 1.80   Mtr  Long', '', 33, '', '', 15, 0, 23, '', NULL, '1.500', 1, '1.500', 'Exclusive', '67.000', '2.500', '2.500', '2.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-07', '04:28:05 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (262, 'IT0262', '', 'HDMI  Cable  1.50 Mtr', '', 33, '', '', 15, 0, 12, '', NULL, '0.750', 1, '0.750', 'Exclusive', '100.000', '1.500', '1.500', '4.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-07', '04:31:26 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (263, 'IT0263', '', 'Memory   8  GB   DDR3  L   Twinmos   for  Desktop  Computer', '', 11, '', '', 15, 0, 50, '', NULL, '10.500', 1, '10.500', 'Exclusive', '38.000', '14.500', '14.500', '0.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-08', '05:41:35 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (264, 'IT0264', '', 'Dell Optiplex 7080 MT-i7- 1 TB  Hard Drive ,   4  GB  Memory   with Key Board   +   Mouse   Desktop ', '', 3, '', '', 15, 0, 3, '', NULL, '191.000', 1, '191.000', 'Exclusive', '13.000', '215.000', '215.000', '0.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-08', '06:24:23 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (265, 'IT0265', '', 'Memory   4 GB   DDR4   for  Desktop  Computer', '', 11, '', '', 15, 0, 25, '', NULL, '6.000', 1, '6.000', 'Exclusive', '33.000', '8.000', '8.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-08', '06:28:15 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (266, 'IT0266', '', 'Hikvision 32  Channel  / 16  Sata     Model    DS-9632NI-116', '', 1, '', '', 15, 0, 1, '', NULL, '330.000', 1, '330.000', 'Exclusive', '12.000', '370.000', '370.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-08', '07:23:48 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (267, 'IT0267', '', 'Hikvision 32  Channel  / 8  Sata     Model    DS-9632NI', '', 1, '', '', 15, 0, 1, '', NULL, '240.000', 1, '240.000', 'Exclusive', '13.000', '270.000', '270.000', '0.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-08', '07:26:12 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (268, 'IT0268', '', 'Cisco  Switch   28 Port  .  Gigabit Managed  Switch   Model -SG300-28  DN-153500KB', '', 8, '', '', 15, 0, 8, '', NULL, '10.000', 1, '10.000', 'Exclusive', '250.000', '35.000', '35.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-09', '03:44:51 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (269, 'IT0269', '', 'Gulf  Brand  Power Cable 3 Core x 2.5 mm2', 'Per  Roll  73 Mtr  x 23.500 kd   Gulf Brand     From   KND', 33, '', '', 13, 0, 15, '', NULL, '0.321', 1, '0.321', 'Exclusive', NULL, '0.321', '0.321', '40.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-11', '10:53:12 am', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (270, 'IT0270', '', 'Gulf  Cable 1.5 mm2  x 3 Core  Cable       ( 80 Yard    - 73   Mtr  )', 'Gulf  Cable 1.5 mm2  x 3 Core  Cable       ( 80 Yard    - 73   Mtr  )    per   Roll    14.500 kd     from  KND', 33, '', '', 13, 0, 15, '', NULL, '0.198', 1, '0.198', 'Exclusive', NULL, '0.198', '0.198', '0.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-11', '02:34:47 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (271, 'IT0271', '', 'Gulf  Cable 1.0 mm2  x 2  Core   Speaker    Cable       ( 80 Yard    - 73   Mtr  )', 'Gulf  Cable 1.0 mm2  x 2  Core   Speaker    Cable       ( 80 Yard    - 73   Mtr  )  per Roll  12 KD    From    KND', 33, '', '', 13, 0, 15, '', NULL, '0.164', 1, '0.164', 'Exclusive', NULL, '0.164', '0.164', '0.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-11', '02:37:29 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (272, 'IT0272', '', 'X Face 100   with  Face / Fingerprint / ID / Wi-Fi /  ADMS   .', '25 nos  issued to Food Hub   Dip N Dip', 5, '', '', 15, 0, 39, '', NULL, '48.000', 1, '48.000', 'Exclusive', '63.000', '78.000', '78.000', '14.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-12', '02:57:00 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (273, 'IT0273', '', 'Battery  for  G#  Time Attendance', '20 nos Issued to   Pawaz  Engineering', 5, '', '', 15, 0, 39, '', NULL, '3.850', 1, '3.850', 'Exclusive', '134.000', '9.000', '9.000', '0.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-12', '02:57:55 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (274, 'IT0274', '', 'Power Extension 6 Port', '', 23, '', '', 15, 0, 79, '', NULL, '3.000', 1, '3.000', 'Exclusive', '50.000', '4.500', '4.500', '2.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-14', '09:20:30 am', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (275, 'IT0275', '', 'BioStation    BS2-OMPW     546833570 /  4885156', '', 5, '', '', 15, 0, 80, '', NULL, '215.000', 1, '215.000', 'Exclusive', '9.000', '235.000', '235.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-14', '11:25:32 am', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (276, 'IT0276', '', 'SSD 240GB Kingston 2.5&quot; SA400S37', '', 11, '', '', 15, 0, 25, '', NULL, '8.500', 1, '8.500', 'Exclusive', '41.000', '12.000', '12.000', '5.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-14', '12:30:09 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (277, 'IT0277', '', 'Calendar  of  Softline Technology', '', 21, '', '', 15, 0, 81, '', NULL, '0.140', 1, '0.140', 'Exclusive', NULL, '0.140', '0.140', '500.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-16', '05:21:49 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (278, 'IT0278', '', 'Cat 6 A     Kuwes Angle Type Face plate Double Port with Modular', 'From  Al Bareeq  ', 8, '', '', 15, 0, 11, '', NULL, '2.500', 1, '2.500', 'Exclusive', NULL, '2.500', '2.500', '0.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-16', '05:52:12 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (279, 'IT0279', '', 'Dell Optiplex 7090 MT-i7- 1 TB  Hard Drive ,   4  GB  Memory   with Key Board   +   Mouse   Desktop ', 'Burhan Tech to   Kuwait  Riyad Ceter tower', 3, '', '', 15, 0, 3, '', NULL, '198.000', 1, '198.000', 'Exclusive', '15.000', '228.000', '228.000', '0.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-16', '06:03:32 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (280, 'IT0280', '', 'LED  Dell  20&quot;  Monitor  E2020H   VGA  , DP   6FNBHC3', 'From Smartek  to   Riyad  Center Tower  ', 2, '', '', 15, 0, 3, '', NULL, '43.000', 1, '43.000', 'Exclusive', '12.000', '48.000', '48.000', '0.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-16', '06:07:43 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (281, 'IT0281', '', 'Access Control  SC-105', '', 5, '', '', 15, 0, 39, '', NULL, '33.000', 1, '33.000', 'Exclusive', '106.000', '68.000', '68.000', '2.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-18', '02:49:59 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (282, 'IT0282', '', 'ID  Card  Reader', '', 5, '', '', 15, 0, 39, '', NULL, '12.300', 1, '12.300', 'Exclusive', '144.000', '30.000', '30.000', '5.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-18', '02:50:58 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (283, 'IT0283', '', 'HP 15-DW3024NIA-15.6&quot;  HD / I3  / 4 GB / 256 GB  NVME   SLNO :- CND1083M3B', '', 4, '', '', 15, 0, 4, '', NULL, '150.000', 1, '150.000', 'Exclusive', '17.000', '175.000', '175.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-18', '03:02:57 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (284, 'IT0284', '', 'al soor cpa.com', '', 47, '', '', 15, 0, 81, '', NULL, '55.000', 1, '55.000', 'Exclusive', '9.000', '60.000', '60.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-20', '01:15:26 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (285, 'IT0285', '', 'khaled-consultancy.com', '', 47, '', '', 15, 0, 81, '', NULL, '55.000', 1, '55.000', 'Exclusive', '9.000', '60.000', '60.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-20', '01:17:16 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (286, 'IT0286', '', 'XP2-MDPB  Mullion  type RF    Card Reader  MIFARE', '', 5, '', '', 15, 0, 80, '', NULL, '80.000', 1, '80.000', 'Exclusive', '19.000', '95.000', '95.000', '0.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-21', '09:25:23 am', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (287, 'IT0287', '', 'Display  port to VGA  converter', '', 3, '', '', 15, 0, 83, '', NULL, '3.000', 1, '3.000', 'Exclusive', '67.000', '5.000', '5.000', '4.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-21', '06:39:09 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (288, 'IT0288', '', 'DP X DP Cable  1.800  Mtr', '', 33, '', '', 15, 0, 82, '', NULL, '1.250', 1, '1.250', 'Exclusive', '140.000', '3.000', '3.000', '6.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-21', '06:40:55 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (289, 'IT0289', '', 'KR 602 E  RF ID AND  Keypad Card Reader', '', 5, '', '', 15, 0, 39, '', NULL, '4.350', 1, '4.350', 'Exclusive', '130.000', '10.000', '10.000', '0.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-22', '01:46:56 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (290, 'IT0290', '', 'KR 602 M  MIfare  and Keypad Card Reader', '', 5, '', '', 15, 0, 39, '', NULL, '5.250', 1, '5.250', 'Exclusive', '90.000', '10.000', '10.000', '0.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-22', '01:48:30 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (291, 'IT0291', '', 'HP   30A  Black  Toner', '', 28, '', '', 15, 0, 4, '', NULL, '17.750', 1, '17.750', 'Exclusive', '8.000', '19.250', '19.250', '0.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-22', '02:30:35 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (292, 'IT0292', '', 'SATA Data Cable', '', 33, '', '', 15, 0, 12, '', NULL, '0.250', 1, '0.250', 'Exclusive', '40.000', '0.350', '0.350', '12.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-27', '12:39:50 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (293, 'IT0293', '', 'IT Maintenance &amp; Support monthly charges (1st  December2021 - 31st December 2021)', '', 48, '', '', 15, 0, 84, '', NULL, '12.500', 1, '12.500', 'Exclusive', NULL, '12.500', '12.500', '0.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-27', '06:00:56 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (294, 'IT0294', '', 'Cat 6   Patch Panel  24 Port  .', '', 8, '', '', 15, 0, 11, '', NULL, '5.000', 1, '5.000', 'Exclusive', '60.000', '8.000', '8.000', '2.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-30', '02:34:58 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (295, 'IT0295', '', '3 M    Cat6A    Patch  Panel   24  Port   -Used', '', 8, '', '', 15, 0, 85, '', NULL, '12.000', 1, '12.000', 'Exclusive', '25.000', '15.000', '15.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-30', '02:43:18 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (296, 'IT0296', '', 'Power Cable  for  power Adaptor .  (  From  Adaptor  to power Exttension Port', '', 33, '', '', 15, 0, 12, '', NULL, '0.350', 1, '0.350', 'Exclusive', '186.000', '1.000', '1.000', '6.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-30', '02:47:36 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (297, 'IT0297', '', 'I   Face 402  Time Attendance', '', 5, '', '', 15, 0, 39, '', NULL, '60.000', 1, '60.000', 'Exclusive', NULL, '60.000', '60.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-30', '03:24:25 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (298, 'IT0298', '', 'Time Attendance   PF    1000', '', 5, '', '', 15, 0, 39, '', NULL, '35.000', 1, '35.000', 'Exclusive', '29.000', '45.000', '45.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-30', '03:26:08 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (299, 'IT0299', '', 'DVR  Funlux    4  Chanel', '', 5, '', '', 15, 0, 72, '', NULL, '5.000', 1, '5.000', 'Exclusive', NULL, '5.000', '5.000', '1.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-30', '03:29:54 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (300, 'IT0300', '', 'Cable  Tie  150 mm   Nylon', '', 23, '', '', 15, 0, 12, '', NULL, '0.750', 1, '0.750', 'Exclusive', NULL, '0.750', '0.750', '7.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-30', '03:32:27 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (301, 'IT0301', '', 'Cable  Tie  200   mm   Nylon', '', 23, '', '', 11, 0, 12, '', NULL, '0.750', 1, '0.750', 'Exclusive', NULL, '0.750', '0.750', '2.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-30', '05:46:59 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (302, 'IT0302', '', 'Cable  Tie  250   mm   Nylon', '', 23, '', '', 11, 0, 12, '', NULL, '1.000', 1, '1.000', 'Exclusive', NULL, '1.000', '1.000', '4.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-30', '05:48:57 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (303, 'IT0303', '', 'Cable  Tie  300  mm   Nylon', '', 23, '', '', 11, 0, 12, '', NULL, '1.000', 1, '1.000', 'Exclusive', NULL, '1.000', '1.000', '3.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-30', '05:50:04 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (304, 'IT0304', '', 'Cat6A  Modulor    ( Key Stone )', '', 8, '', '', 15, 0, 0, '', NULL, '1.650', 1, '1.650', 'Exclusive', NULL, '1.650', '1.650', '22.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-30', '05:54:48 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (305, 'IT0305', '', 'Kuwes Floor BOX   Modular    Cover', '', 8, '', '', 15, 0, 11, '', NULL, '0.750', 1, '0.750', 'Exclusive', NULL, '0.750', '0.750', '34.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-30', '05:56:37 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (306, 'IT0306', '', 'Fiber Cable Cut PCS', '', 33, '', '', 13, 0, 12, '', NULL, '0.700', 1, '0.700', 'Exclusive', NULL, '0.700', '0.700', '94.000', NULL, '37.34.206.9', '37.34.206.9', '2021-12-30', '06:16:19 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (307, 'IT0307', '', 'Hikvision  4 MP  Motorized   Outdoor  Camera -DS-2CD3641G0-IZS', '', 1, '', '', 15, 0, 1, '', NULL, '37.000', 1, '37.000', 'Exclusive', '22.000', '45.000', '45.000', '5.000', NULL, '37.34.206.9', '37.34.206.9', '2022-01-05', '10:18:17 am', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (308, 'IT0308', '', 'Power Cable for Desktop', '', 33, '', '', 15, 0, 12, '', NULL, '0.300', 1, '0.300', 'Exclusive', '233.000', '1.000', '1.000', '9.000', NULL, '37.34.206.9', '37.34.206.9', '2022-01-10', '02:11:30 pm', 'admin', NULL, 1);
INSERT INTO `db_items` (`id`, `item_code`, `custom_barcode`, `item_name`, `description`, `category_id`, `sku`, `hsn`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `final_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (309, 'IT0309', '', 'Power Cable for Laptop', '', 33, '', '', 15, 0, 12, '', NULL, '0.300', 1, '0.300', 'Exclusive', '233.000', '1.000', '1.000', '11.000', NULL, '37.34.206.9', '37.34.206.9', '2022-01-10', '02:15:23 pm', 'admin', NULL, 1);


#
# TABLE STRUCTURE FOR: db_languages
#

DROP TABLE IF EXISTS `db_languages`;

CREATE TABLE `db_languages` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `language` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_languages` (`id`, `language`, `status`) VALUES (1, 'English', 1);
INSERT INTO `db_languages` (`id`, `language`, `status`) VALUES (2, 'Hindi', 1);
INSERT INTO `db_languages` (`id`, `language`, `status`) VALUES (3, 'Kannada', 1);
INSERT INTO `db_languages` (`id`, `language`, `status`) VALUES (4, 'Indonesian', 1);
INSERT INTO `db_languages` (`id`, `language`, `status`) VALUES (5, 'Chinese', 1);
INSERT INTO `db_languages` (`id`, `language`, `status`) VALUES (6, 'Russian', 1);
INSERT INTO `db_languages` (`id`, `language`, `status`) VALUES (7, 'Spanish', 1);
INSERT INTO `db_languages` (`id`, `language`, `status`) VALUES (8, 'Arabic', 1);
INSERT INTO `db_languages` (`id`, `language`, `status`) VALUES (9, 'Albanian', 1);
INSERT INTO `db_languages` (`id`, `language`, `status`) VALUES (10, 'Dutch', 1);
INSERT INTO `db_languages` (`id`, `language`, `status`) VALUES (11, 'Bangla', 1);
INSERT INTO `db_languages` (`id`, `language`, `status`) VALUES (12, 'Urdu', 1);
INSERT INTO `db_languages` (`id`, `language`, `status`) VALUES (13, 'Italian', 1);
INSERT INTO `db_languages` (`id`, `language`, `status`) VALUES (14, 'Marathi', 1);
INSERT INTO `db_languages` (`id`, `language`, `status`) VALUES (15, 'Khmer', 1);


#
# TABLE STRUCTURE FOR: db_paymenttypes
#

DROP TABLE IF EXISTS `db_paymenttypes`;

CREATE TABLE `db_paymenttypes` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `payment_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_paymenttypes` (`id`, `payment_type`, `status`) VALUES (1, 'Cash', 1);
INSERT INTO `db_paymenttypes` (`id`, `payment_type`, `status`) VALUES (2, 'Cheque', 1);
INSERT INTO `db_paymenttypes` (`id`, `payment_type`, `status`) VALUES (4, 'Online', 1);
INSERT INTO `db_paymenttypes` (`id`, `payment_type`, `status`) VALUES (5, 'KNET', 1);
INSERT INTO `db_paymenttypes` (`id`, `payment_type`, `status`) VALUES (6, 'Credit', 1);


#
# TABLE STRUCTURE FOR: db_permissions
#

DROP TABLE IF EXISTS `db_permissions`;

CREATE TABLE `db_permissions` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `role_id` int(5) DEFAULT NULL,
  `permissions` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=321 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (192, 2, 'currency_add');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (193, 2, 'currency_edit');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (194, 2, 'currency_delete');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (195, 2, 'currency_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (196, 2, 'units_add');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (197, 2, 'units_edit');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (198, 2, 'units_delete');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (199, 2, 'units_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (200, 2, 'places_add');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (201, 2, 'places_edit');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (202, 2, 'places_delete');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (203, 2, 'places_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (204, 2, 'expense_add');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (205, 2, 'expense_edit');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (206, 2, 'expense_delete');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (207, 2, 'expense_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (208, 2, 'items_add');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (209, 2, 'items_edit');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (210, 2, 'items_delete');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (211, 2, 'items_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (212, 2, 'brand_add');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (213, 2, 'brand_edit');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (214, 2, 'brand_delete');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (215, 2, 'brand_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (216, 2, 'suppliers_add');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (217, 2, 'suppliers_edit');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (218, 2, 'suppliers_delete');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (219, 2, 'suppliers_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (220, 2, 'customers_add');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (221, 2, 'customers_edit');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (222, 2, 'customers_delete');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (223, 2, 'customers_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (224, 2, 'purchase_add');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (225, 2, 'purchase_edit');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (226, 2, 'purchase_delete');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (227, 2, 'purchase_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (228, 2, 'sales_add');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (229, 2, 'sales_edit');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (230, 2, 'sales_delete');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (231, 2, 'sales_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (232, 2, 'sales_payment_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (233, 2, 'sales_payment_add');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (234, 2, 'sales_payment_delete');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (235, 2, 'sales_report');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (236, 2, 'purchase_report');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (237, 2, 'expense_report');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (238, 2, 'profit_report');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (239, 2, 'stock_report');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (240, 2, 'item_sales_report');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (241, 2, 'purchase_payments_report');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (242, 2, 'sales_payments_report');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (243, 2, 'expired_items_report');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (244, 2, 'items_category_add');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (245, 2, 'items_category_edit');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (246, 2, 'items_category_delete');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (247, 2, 'items_category_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (248, 2, 'print_labels');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (249, 2, 'import_items');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (250, 2, 'expense_category_add');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (251, 2, 'expense_category_edit');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (252, 2, 'expense_category_delete');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (253, 2, 'expense_category_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (254, 2, 'dashboard_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (255, 2, 'send_sms');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (256, 2, 'sms_template_edit');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (257, 2, 'sms_template_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (258, 2, 'sms_api_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (259, 2, 'sms_api_edit');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (260, 2, 'purchase_return_add');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (261, 2, 'purchase_return_edit');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (262, 2, 'purchase_return_delete');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (263, 2, 'purchase_return_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (264, 2, 'purchase_return_report');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (265, 2, 'sales_return_add');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (266, 2, 'sales_return_edit');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (267, 2, 'sales_return_delete');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (268, 2, 'sales_return_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (269, 2, 'sales_return_report');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (270, 2, 'sales_return_payment_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (271, 2, 'sales_return_payment_add');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (272, 2, 'sales_return_payment_delete');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (273, 2, 'purchase_return_payment_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (274, 2, 'purchase_return_payment_add');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (275, 2, 'purchase_return_payment_delete');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (276, 2, 'purchase_payment_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (277, 2, 'purchase_payment_add');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (278, 2, 'purchase_payment_delete');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (279, 2, 'payment_types_add');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (280, 2, 'payment_types_edit');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (281, 2, 'payment_types_delete');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (282, 2, 'payment_types_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (283, 2, 'import_customers');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (284, 2, 'import_suppliers');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (285, 2, 'item_purchase_report');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (286, 2, 'services_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (287, 2, 'services_edit');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (310, 3, 'services_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (311, 3, 'services_edit');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (312, 3, 'rap_payment_add');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (313, 3, 'rap_payment_delete');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (314, 3, 'rap_payment_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (315, 3, 'rap_reciept_add');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (316, 3, 'rap_reciept_edit');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (317, 3, 'rap_reciept_view');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (318, 3, 'petty_cash_add');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (319, 3, 'petty_cash_edit');
INSERT INTO `db_permissions` (`id`, `role_id`, `permissions`) VALUES (320, 3, 'petty_cash_view');


#
# TABLE STRUCTURE FOR: db_petty_cash
#

DROP TABLE IF EXISTS `db_petty_cash`;

CREATE TABLE `db_petty_cash` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `petty_cash_date` date NOT NULL,
  `petty_cash_ref_no` varchar(50) NOT NULL,
  `petty_cash_description` text NOT NULL,
  `petty_cash_cash_in` double(20,3) NOT NULL,
  `petty_cash_cash_out` double(20,3) NOT NULL,
  `petty_cash_total` double(20,3) NOT NULL,
  `petty_cash_remarks` text NOT NULL,
  `system_ip` varchar(50) NOT NULL,
  `system_name` varchar(50) NOT NULL,
  `created_date` date NOT NULL,
  `created_time` varchar(30) NOT NULL,
  `created_by` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;

INSERT INTO `db_petty_cash` (`id`, `petty_cash_date`, `petty_cash_ref_no`, `petty_cash_description`, `petty_cash_cash_in`, `petty_cash_cash_out`, `petty_cash_total`, `petty_cash_remarks`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`) VALUES (4, '2021-06-26', 'Reference ', 'Description', '100.000', '200.000', '300.000', 'Remarks', '::1', 'DESKTOP-CMMNJOB', '2021-06-12', '08:45:04 pm', 'admin');
INSERT INTO `db_petty_cash` (`id`, `petty_cash_date`, `petty_cash_ref_no`, `petty_cash_description`, `petty_cash_cash_in`, `petty_cash_cash_out`, `petty_cash_total`, `petty_cash_remarks`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`) VALUES (5, '2021-06-12', 'Reference  2', 'Description 2', '200.000', '300.000', '500.000', 'Remarks 2', '::1', 'DESKTOP-CMMNJOB', '2021-06-12', '08:49:01 pm', 'admin');
INSERT INTO `db_petty_cash` (`id`, `petty_cash_date`, `petty_cash_ref_no`, `petty_cash_description`, `petty_cash_cash_in`, `petty_cash_cash_out`, `petty_cash_total`, `petty_cash_remarks`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`) VALUES (6, '2021-06-20', '1540', 'paid to Murugan  for  above invoce', '0.000', '10.000', '0.000', '', '37.34.206.9', '37.34.206.9', '2021-06-20', '08:35:01 am', 'admin');
INSERT INTO `db_petty_cash` (`id`, `petty_cash_date`, `petty_cash_ref_no`, `petty_cash_description`, `petty_cash_cash_in`, `petty_cash_cash_out`, `petty_cash_total`, `petty_cash_remarks`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`) VALUES (7, '2021-06-20', '', '', '0.000', '0.000', '200.000', '', '37.34.206.9', '37.34.206.9', '2021-06-20', '08:43:58 am', 'admin');


#
# TABLE STRUCTURE FOR: db_purchase
#

DROP TABLE IF EXISTS `db_purchase`;

CREATE TABLE `db_purchase` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `purchase_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_no` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `purchase_date` date DEFAULT NULL,
  `purchase_status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `supplier_id` int(5) DEFAULT NULL,
  `warehouse_id` int(5) DEFAULT NULL,
  `other_charges_input` double(20,3) DEFAULT NULL,
  `other_charges_tax_id` int(5) DEFAULT NULL,
  `other_charges_amt` double(20,3) DEFAULT NULL,
  `discount_to_all_input` double(20,3) DEFAULT NULL,
  `discount_to_all_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tot_discount_to_all_amt` double(20,3) DEFAULT NULL,
  `subtotal` double(20,3) DEFAULT NULL COMMENT 'Purchased qty',
  `round_off` double(20,3) DEFAULT NULL COMMENT 'Pending Qty',
  `grand_total` double(20,3) DEFAULT NULL,
  `purchase_note` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paid_amount` double(20,3) DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_time` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_ip` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_id` int(5) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  `return_bit` int(1) DEFAULT NULL COMMENT 'Purchase return raised',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_purchase` (`id`, `purchase_code`, `reference_no`, `purchase_date`, `purchase_status`, `supplier_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `purchase_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `status`, `return_bit`) VALUES (1, 'PU0001', '368085', '2021-10-26', 'Received', 3, NULL, NULL, NULL, NULL, NULL, 'in_percentage', NULL, '125.000', NULL, '125.000', '', 'Unpaid', '0.000', '2021-10-27', '01:00:31 pm', 'admin', '37.34.206.9', '37.34.206.9', NULL, 1, NULL);
INSERT INTO `db_purchase` (`id`, `purchase_code`, `reference_no`, `purchase_date`, `purchase_status`, `supplier_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `purchase_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `status`, `return_bit`) VALUES (2, 'PU0002', '115357', '2021-11-15', 'Received', 13, NULL, NULL, NULL, NULL, NULL, 'in_percentage', NULL, '58.000', NULL, '58.000', '', 'Unpaid', '0.000', '2021-11-16', '09:46:18 am', 'admin', '37.34.206.9', '37.34.206.9', NULL, 1, NULL);
INSERT INTO `db_purchase` (`id`, `purchase_code`, `reference_no`, `purchase_date`, `purchase_status`, `supplier_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `purchase_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `status`, `return_bit`) VALUES (3, 'PU0003', '115356', '2021-11-15', 'Received', 13, NULL, NULL, NULL, NULL, NULL, 'in_percentage', NULL, '310.000', NULL, '310.000', '', 'Unpaid', '0.000', '2021-11-16', '09:55:35 am', 'admin', '37.34.206.9', '37.34.206.9', NULL, 1, NULL);
INSERT INTO `db_purchase` (`id`, `purchase_code`, `reference_no`, `purchase_date`, `purchase_status`, `supplier_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `purchase_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `status`, `return_bit`) VALUES (4, 'PU0004', '13553', '2021-11-20', 'Received', 4, NULL, NULL, NULL, NULL, NULL, 'in_percentage', NULL, '85.250', NULL, '85.250', '', 'Unpaid', '0.000', '2021-11-20', '05:18:12 pm', 'admin', '37.34.206.9', '37.34.206.9', NULL, 1, NULL);
INSERT INTO `db_purchase` (`id`, `purchase_code`, `reference_no`, `purchase_date`, `purchase_status`, `supplier_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `purchase_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `status`, `return_bit`) VALUES (5, 'PU0005', '369391', '2021-11-20', 'Received', 3, NULL, NULL, NULL, NULL, NULL, 'in_percentage', NULL, '7.500', NULL, '7.500', '', 'Unpaid', '0.000', '2021-11-20', '05:23:18 pm', 'admin', '37.34.206.9', '37.34.206.9', NULL, 1, NULL);
INSERT INTO `db_purchase` (`id`, `purchase_code`, `reference_no`, `purchase_date`, `purchase_status`, `supplier_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `purchase_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `status`, `return_bit`) VALUES (6, 'PU0006', '14968', '2021-11-20', 'Received', 30, NULL, NULL, NULL, NULL, NULL, 'in_percentage', NULL, '0.000', NULL, '0.000', '', 'Paid', '0.000', '2021-11-20', '06:00:45 pm', 'admin', '37.34.206.9', '37.34.206.9', NULL, 1, NULL);
INSERT INTO `db_purchase` (`id`, `purchase_code`, `reference_no`, `purchase_date`, `purchase_status`, `supplier_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `purchase_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `status`, `return_bit`) VALUES (7, 'PU0007', 'P1211332', '2021-11-21', 'Received', 31, NULL, NULL, NULL, NULL, NULL, 'in_percentage', NULL, '915.000', NULL, '915.000', '', 'Paid', '915.000', '2021-11-21', '12:51:15 pm', 'admin', '37.34.206.9', '37.34.206.9', NULL, 1, NULL);
INSERT INTO `db_purchase` (`id`, `purchase_code`, `reference_no`, `purchase_date`, `purchase_status`, `supplier_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `purchase_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `status`, `return_bit`) VALUES (8, 'PU0008', 'p1211371', '2021-11-21', 'Received', 31, NULL, NULL, NULL, NULL, NULL, 'in_percentage', NULL, '38.000', NULL, '38.000', '', 'Paid', '38.000', '2021-11-21', '02:06:09 pm', 'admin', '37.34.206.9', '37.34.206.9', NULL, 1, NULL);
INSERT INTO `db_purchase` (`id`, `purchase_code`, `reference_no`, `purchase_date`, `purchase_status`, `supplier_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `purchase_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `status`, `return_bit`) VALUES (9, 'PU0009', '7234', '2021-11-27', 'Received', 14, NULL, NULL, NULL, NULL, NULL, 'in_percentage', NULL, '12.000', NULL, '12.000', '', 'Paid', '12.000', '2021-11-27', '08:27:27 pm', 'admin', '37.34.206.9', '37.34.206.9', NULL, 1, NULL);
INSERT INTO `db_purchase` (`id`, `purchase_code`, `reference_no`, `purchase_date`, `purchase_status`, `supplier_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `purchase_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `status`, `return_bit`) VALUES (10, 'PU0010', '917', '2021-11-27', 'Received', 33, NULL, NULL, NULL, NULL, NULL, 'in_percentage', NULL, '115.000', NULL, '115.000', '', 'Unpaid', '0.000', '2021-11-27', '08:45:29 pm', 'admin', '37.34.206.9', '37.34.206.9', NULL, 1, NULL);
INSERT INTO `db_purchase` (`id`, `purchase_code`, `reference_no`, `purchase_date`, `purchase_status`, `supplier_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `purchase_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `status`, `return_bit`) VALUES (11, 'PU0011', '1768', '2021-12-04', 'Received', 34, NULL, NULL, NULL, NULL, NULL, 'in_percentage', NULL, '13.334', NULL, '13.334', '', 'Unpaid', '0.000', '2021-12-04', '01:18:53 pm', 'admin', '37.34.206.9', '37.34.206.9', NULL, 1, NULL);
INSERT INTO `db_purchase` (`id`, `purchase_code`, `reference_no`, `purchase_date`, `purchase_status`, `supplier_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `purchase_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `status`, `return_bit`) VALUES (12, 'PU0012', '5608122021', '2021-12-09', 'Received', 9, NULL, NULL, NULL, NULL, NULL, 'in_percentage', NULL, '330.000', NULL, '330.000', '', 'Paid', '330.000', '2021-12-09', '01:05:32 pm', 'admin', '37.34.206.9', '37.34.206.9', NULL, 1, NULL);
INSERT INTO `db_purchase` (`id`, `purchase_code`, `reference_no`, `purchase_date`, `purchase_status`, `supplier_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `purchase_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `status`, `return_bit`) VALUES (13, 'PU0013', '30008', '2021-12-12', 'Received', 36, NULL, NULL, NULL, NULL, NULL, 'in_percentage', NULL, '557.000', NULL, '557.000', '', 'Paid', '557.000', '2021-12-12', '03:01:17 pm', 'admin', '37.34.206.9', '37.34.206.9', NULL, 1, NULL);
INSERT INTO `db_purchase` (`id`, `purchase_code`, `reference_no`, `purchase_date`, `purchase_status`, `supplier_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `purchase_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `status`, `return_bit`) VALUES (14, 'PU0014', 'XMP1211123004', '2021-12-18', 'Received', 36, NULL, NULL, NULL, NULL, NULL, 'in_percentage', NULL, '847.500', NULL, '847.500', '', 'Paid', '847.500', '2021-12-18', '02:48:35 pm', 'admin', '37.34.206.9', '37.34.206.9', NULL, 1, NULL);
INSERT INTO `db_purchase` (`id`, `purchase_code`, `reference_no`, `purchase_date`, `purchase_status`, `supplier_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `purchase_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `status`, `return_bit`) VALUES (15, 'PU0015', '161543', '2021-12-18', 'Received', 2, NULL, NULL, NULL, NULL, NULL, 'in_percentage', NULL, '150.000', NULL, '150.000', '', 'Unpaid', '0.000', '2021-12-18', '03:13:53 pm', 'admin', '37.34.206.9', '37.34.206.9', NULL, 1, NULL);
INSERT INTO `db_purchase` (`id`, `purchase_code`, `reference_no`, `purchase_date`, `purchase_status`, `supplier_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `purchase_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `status`, `return_bit`) VALUES (16, 'PU0016', 'XMP1211129004', '2021-12-19', 'Received', 36, NULL, NULL, NULL, NULL, NULL, 'in_percentage', NULL, '672.000', NULL, '672.000', '', 'Unpaid', '0.000', '2021-12-19', '05:14:07 pm', 'admin', '37.34.206.9', '37.34.206.9', NULL, 1, NULL);
INSERT INTO `db_purchase` (`id`, `purchase_code`, `reference_no`, `purchase_date`, `purchase_status`, `supplier_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `purchase_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `status`, `return_bit`) VALUES (17, 'PU0017', 'XMP1211108001', '2021-12-21', 'Received', 36, NULL, NULL, NULL, NULL, NULL, 'in_percentage', NULL, '341.400', NULL, '341.400', '', 'Paid', '341.400', '2021-12-21', '03:13:54 pm', 'admin', '37.34.206.9', '37.34.206.9', NULL, 1, NULL);
INSERT INTO `db_purchase` (`id`, `purchase_code`, `reference_no`, `purchase_date`, `purchase_status`, `supplier_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `purchase_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `status`, `return_bit`) VALUES (18, 'PU0018', 'p1211546', '2021-12-22', 'Received', 31, NULL, NULL, NULL, NULL, NULL, 'in_percentage', NULL, '1035.000', NULL, '1035.000', '', 'Paid', '1035.000', '2021-12-22', '12:58:09 pm', 'admin', '37.34.206.9', '37.34.206.9', NULL, 1, NULL);
INSERT INTO `db_purchase` (`id`, `purchase_code`, `reference_no`, `purchase_date`, `purchase_status`, `supplier_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `purchase_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `status`, `return_bit`) VALUES (19, 'PU0019', 'P1211502', '2021-12-27', 'Received', 31, NULL, NULL, NULL, NULL, NULL, 'in_percentage', NULL, '446.000', NULL, '446.000', '', 'Paid', '446.000', '2021-12-27', '09:17:13 pm', 'admin', '37.34.206.9', '37.34.206.9', NULL, 1, NULL);
INSERT INTO `db_purchase` (`id`, `purchase_code`, `reference_no`, `purchase_date`, `purchase_status`, `supplier_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `purchase_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `status`, `return_bit`) VALUES (20, 'PU0020', '17926122021', '2021-12-26', 'Received', 9, NULL, NULL, NULL, NULL, NULL, 'in_percentage', NULL, '185.000', NULL, '185.000', '', 'Paid', '185.000', '2022-01-05', '10:21:58 am', 'admin', '37.34.206.9', '37.34.206.9', NULL, 1, NULL);


#
# TABLE STRUCTURE FOR: db_purchaseitems
#

DROP TABLE IF EXISTS `db_purchaseitems`;

CREATE TABLE `db_purchaseitems` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `purchase_id` int(5) DEFAULT NULL,
  `purchase_status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `item_id` int(5) DEFAULT NULL,
  `purchase_qty` double(20,3) DEFAULT NULL,
  `price_per_unit` double(20,3) DEFAULT NULL,
  `tax_id` int(5) DEFAULT NULL,
  `tax_amt` double(20,3) DEFAULT NULL,
  `tax_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unit_discount_per` double(20,3) DEFAULT NULL,
  `discount_amt` double(20,3) DEFAULT NULL,
  `unit_total_cost` double(20,3) DEFAULT NULL,
  `total_cost` double(20,3) DEFAULT NULL,
  `profit_margin_per` double(20,3) DEFAULT NULL,
  `unit_sales_price` double(20,3) DEFAULT NULL,
  `status` int(5) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=115 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_purchaseitems` (`id`, `purchase_id`, `purchase_status`, `item_id`, `purchase_qty`, `price_per_unit`, `tax_id`, `tax_amt`, `tax_type`, `unit_discount_per`, `discount_amt`, `unit_total_cost`, `total_cost`, `profit_margin_per`, `unit_sales_price`, `status`) VALUES (62, 1, 'Received', 68, '1.000', '125.000', 1, NULL, 'Exclusive', NULL, '0.000', '125.000', '125.000', NULL, NULL, 1);
INSERT INTO `db_purchaseitems` (`id`, `purchase_id`, `purchase_status`, `item_id`, `purchase_qty`, `price_per_unit`, `tax_id`, `tax_amt`, `tax_type`, `unit_discount_per`, `discount_amt`, `unit_total_cost`, `total_cost`, `profit_margin_per`, `unit_sales_price`, `status`) VALUES (63, 2, 'Received', 138, '4.000', '14.500', 1, NULL, 'Exclusive', NULL, '0.000', '14.500', '58.000', NULL, NULL, 1);
INSERT INTO `db_purchaseitems` (`id`, `purchase_id`, `purchase_status`, `item_id`, `purchase_qty`, `price_per_unit`, `tax_id`, `tax_amt`, `tax_type`, `unit_discount_per`, `discount_amt`, `unit_total_cost`, `total_cost`, `profit_margin_per`, `unit_sales_price`, `status`) VALUES (64, 3, 'Received', 139, '1.000', '219.000', 1, NULL, 'Exclusive', NULL, '0.000', '219.000', '219.000', NULL, NULL, 1);
INSERT INTO `db_purchaseitems` (`id`, `purchase_id`, `purchase_status`, `item_id`, `purchase_qty`, `price_per_unit`, `tax_id`, `tax_amt`, `tax_type`, `unit_discount_per`, `discount_amt`, `unit_total_cost`, `total_cost`, `profit_margin_per`, `unit_sales_price`, `status`) VALUES (65, 3, 'Received', 140, '1.000', '40.000', 1, NULL, 'Exclusive', NULL, '0.000', '40.000', '40.000', NULL, NULL, 1);
INSERT INTO `db_purchaseitems` (`id`, `purchase_id`, `purchase_status`, `item_id`, `purchase_qty`, `price_per_unit`, `tax_id`, `tax_amt`, `tax_type`, `unit_discount_per`, `discount_amt`, `unit_total_cost`, `total_cost`, `profit_margin_per`, `unit_sales_price`, `status`) VALUES (66, 3, 'Received', 141, '1.000', '51.000', 1, NULL, 'Exclusive', NULL, '0.000', '51.000', '51.000', NULL, NULL, 1);
INSERT INTO `db_purchaseitems` (`id`, `purchase_id`, `purchase_status`, `item_id`, `purchase_qty`, `price_per_unit`, `tax_id`, `tax_amt`, `tax_type`, `unit_discount_per`, `discount_amt`, `unit_total_cost`, `total_cost`, `profit_margin_per`, `unit_sales_price`, `status`) VALUES (67, 4, 'Received', 188, '1.000', '16.250', 1, NULL, 'Exclusive', NULL, '0.000', '16.250', '16.250', NULL, NULL, 1);
INSERT INTO `db_purchaseitems` (`id`, `purchase_id`, `purchase_status`, `item_id`, `purchase_qty`, `price_per_unit`, `tax_id`, `tax_amt`, `tax_type`, `unit_discount_per`, `discount_amt`, `unit_total_cost`, `total_cost`, `profit_margin_per`, `unit_sales_price`, `status`) VALUES (68, 4, 'Received', 189, '4.000', '17.250', 1, NULL, 'Exclusive', NULL, '0.000', '17.250', '69.000', NULL, NULL, 1);
INSERT INTO `db_purchaseitems` (`id`, `purchase_id`, `purchase_status`, `item_id`, `purchase_qty`, `price_per_unit`, `tax_id`, `tax_amt`, `tax_type`, `unit_discount_per`, `discount_amt`, `unit_total_cost`, `total_cost`, `profit_margin_per`, `unit_sales_price`, `status`) VALUES (69, 5, 'Received', 190, '5.000', '1.500', 1, NULL, 'Exclusive', NULL, '0.000', '1.500', '7.500', NULL, NULL, 1);
INSERT INTO `db_purchaseitems` (`id`, `purchase_id`, `purchase_status`, `item_id`, `purchase_qty`, `price_per_unit`, `tax_id`, `tax_amt`, `tax_type`, `unit_discount_per`, `discount_amt`, `unit_total_cost`, `total_cost`, `profit_margin_per`, `unit_sales_price`, `status`) VALUES (74, 6, 'Received', 191, '1.000', '325.000', 1, NULL, 'Exclusive', NULL, '0.000', '325.000', '325.000', NULL, NULL, 1);
INSERT INTO `db_purchaseitems` (`id`, `purchase_id`, `purchase_status`, `item_id`, `purchase_qty`, `price_per_unit`, `tax_id`, `tax_amt`, `tax_type`, `unit_discount_per`, `discount_amt`, `unit_total_cost`, `total_cost`, `profit_margin_per`, `unit_sales_price`, `status`) VALUES (75, 6, 'Received', 129, '1.000', '0.000', 1, NULL, 'Exclusive', NULL, '0.000', NULL, NULL, NULL, NULL, 1);
INSERT INTO `db_purchaseitems` (`id`, `purchase_id`, `purchase_status`, `item_id`, `purchase_qty`, `price_per_unit`, `tax_id`, `tax_amt`, `tax_type`, `unit_discount_per`, `discount_amt`, `unit_total_cost`, `total_cost`, `profit_margin_per`, `unit_sales_price`, `status`) VALUES (76, 6, 'Received', 57, '1.000', '0.000', 1, NULL, 'Exclusive', NULL, '0.000', NULL, NULL, NULL, NULL, 1);
INSERT INTO `db_purchaseitems` (`id`, `purchase_id`, `purchase_status`, `item_id`, `purchase_qty`, `price_per_unit`, `tax_id`, `tax_amt`, `tax_type`, `unit_discount_per`, `discount_amt`, `unit_total_cost`, `total_cost`, `profit_margin_per`, `unit_sales_price`, `status`) VALUES (77, 6, 'Received', 192, '1.000', '0.000', 1, NULL, 'Exclusive', NULL, '0.000', NULL, NULL, NULL, NULL, 1);
INSERT INTO `db_purchaseitems` (`id`, `purchase_id`, `purchase_status`, `item_id`, `purchase_qty`, `price_per_unit`, `tax_id`, `tax_amt`, `tax_type`, `unit_discount_per`, `discount_amt`, `unit_total_cost`, `total_cost`, `profit_margin_per`, `unit_sales_price`, `status`) VALUES (86, 9, 'Received', 204, '1.000', '6.000', 1, NULL, 'Exclusive', NULL, '0.000', '6.000', '6.000', NULL, NULL, 1);
INSERT INTO `db_purchaseitems` (`id`, `purchase_id`, `purchase_status`, `item_id`, `purchase_qty`, `price_per_unit`, `tax_id`, `tax_amt`, `tax_type`, `unit_discount_per`, `discount_amt`, `unit_total_cost`, `total_cost`, `profit_margin_per`, `unit_sales_price`, `status`) VALUES (87, 9, 'Received', 205, '1.000', '6.000', 1, NULL, 'Exclusive', NULL, '0.000', '6.000', '6.000', NULL, NULL, 1);
INSERT INTO `db_purchaseitems` (`id`, `purchase_id`, `purchase_status`, `item_id`, `purchase_qty`, `price_per_unit`, `tax_id`, `tax_amt`, `tax_type`, `unit_discount_per`, `discount_amt`, `unit_total_cost`, `total_cost`, `profit_margin_per`, `unit_sales_price`, `status`) VALUES (90, 8, 'Received', 196, '1.000', '20.000', 1, NULL, 'Exclusive', NULL, '0.000', '20.000', '20.000', NULL, NULL, 1);
INSERT INTO `db_purchaseitems` (`id`, `purchase_id`, `purchase_status`, `item_id`, `purchase_qty`, `price_per_unit`, `tax_id`, `tax_amt`, `tax_type`, `unit_discount_per`, `discount_amt`, `unit_total_cost`, `total_cost`, `profit_margin_per`, `unit_sales_price`, `status`) VALUES (91, 8, 'Received', 197, '6.000', '3.000', 1, NULL, 'Exclusive', NULL, '0.000', '3.000', '18.000', NULL, NULL, 1);
INSERT INTO `db_purchaseitems` (`id`, `purchase_id`, `purchase_status`, `item_id`, `purchase_qty`, `price_per_unit`, `tax_id`, `tax_amt`, `tax_type`, `unit_discount_per`, `discount_amt`, `unit_total_cost`, `total_cost`, `profit_margin_per`, `unit_sales_price`, `status`) VALUES (92, 7, 'Received', 29, '11.000', '65.000', 1, NULL, 'Exclusive', NULL, '0.000', '65.000', '715.000', NULL, NULL, 1);
INSERT INTO `db_purchaseitems` (`id`, `purchase_id`, `purchase_status`, `item_id`, `purchase_qty`, `price_per_unit`, `tax_id`, `tax_amt`, `tax_type`, `unit_discount_per`, `discount_amt`, `unit_total_cost`, `total_cost`, `profit_margin_per`, `unit_sales_price`, `status`) VALUES (93, 7, 'Received', 195, '2.000', '100.000', 1, NULL, 'Exclusive', NULL, '0.000', '100.000', '200.000', NULL, NULL, 1);
INSERT INTO `db_purchaseitems` (`id`, `purchase_id`, `purchase_status`, `item_id`, `purchase_qty`, `price_per_unit`, `tax_id`, `tax_amt`, `tax_type`, `unit_discount_per`, `discount_amt`, `unit_total_cost`, `total_cost`, `profit_margin_per`, `unit_sales_price`, `status`) VALUES (94, 10, 'Received', 206, '1.000', '115.000', 1, NULL, 'Exclusive', NULL, '0.000', '115.000', '115.000', NULL, NULL, 1);
INSERT INTO `db_purchaseitems` (`id`, `purchase_id`, `purchase_status`, `item_id`, `purchase_qty`, `price_per_unit`, `tax_id`, `tax_amt`, `tax_type`, `unit_discount_per`, `discount_amt`, `unit_total_cost`, `total_cost`, `profit_margin_per`, `unit_sales_price`, `status`) VALUES (95, 11, 'Received', 218, '73.000', '0.158', 1, NULL, 'Exclusive', NULL, '0.000', '0.158', '11.534', NULL, NULL, 1);
INSERT INTO `db_purchaseitems` (`id`, `purchase_id`, `purchase_status`, `item_id`, `purchase_qty`, `price_per_unit`, `tax_id`, `tax_amt`, `tax_type`, `unit_discount_per`, `discount_amt`, `unit_total_cost`, `total_cost`, `profit_margin_per`, `unit_sales_price`, `status`) VALUES (96, 11, 'Received', 219, '4.000', '0.450', 1, NULL, 'Exclusive', NULL, '0.000', '0.450', '1.800', NULL, NULL, 1);
INSERT INTO `db_purchaseitems` (`id`, `purchase_id`, `purchase_status`, `item_id`, `purchase_qty`, `price_per_unit`, `tax_id`, `tax_amt`, `tax_type`, `unit_discount_per`, `discount_amt`, `unit_total_cost`, `total_cost`, `profit_margin_per`, `unit_sales_price`, `status`) VALUES (97, 12, 'Received', 266, '1.000', '330.000', 1, NULL, 'Exclusive', NULL, '0.000', '330.000', '330.000', NULL, NULL, 1);
INSERT INTO `db_purchaseitems` (`id`, `purchase_id`, `purchase_status`, `item_id`, `purchase_qty`, `price_per_unit`, `tax_id`, `tax_amt`, `tax_type`, `unit_discount_per`, `discount_amt`, `unit_total_cost`, `total_cost`, `profit_margin_per`, `unit_sales_price`, `status`) VALUES (98, 13, 'Received', 272, '10.000', '48.000', 1, NULL, 'Exclusive', NULL, '0.000', '48.000', '480.000', NULL, NULL, 1);
INSERT INTO `db_purchaseitems` (`id`, `purchase_id`, `purchase_status`, `item_id`, `purchase_qty`, `price_per_unit`, `tax_id`, `tax_amt`, `tax_type`, `unit_discount_per`, `discount_amt`, `unit_total_cost`, `total_cost`, `profit_margin_per`, `unit_sales_price`, `status`) VALUES (99, 13, 'Received', 273, '20.000', '3.850', 1, NULL, 'Exclusive', NULL, '0.000', '3.850', '77.000', NULL, NULL, 1);
INSERT INTO `db_purchaseitems` (`id`, `purchase_id`, `purchase_status`, `item_id`, `purchase_qty`, `price_per_unit`, `tax_id`, `tax_amt`, `tax_type`, `unit_discount_per`, `discount_amt`, `unit_total_cost`, `total_cost`, `profit_margin_per`, `unit_sales_price`, `status`) VALUES (104, 15, 'Received', 283, '1.000', '150.000', 1, NULL, 'Exclusive', NULL, '0.000', '150.000', '150.000', NULL, NULL, 1);
INSERT INTO `db_purchaseitems` (`id`, `purchase_id`, `purchase_status`, `item_id`, `purchase_qty`, `price_per_unit`, `tax_id`, `tax_amt`, `tax_type`, `unit_discount_per`, `discount_amt`, `unit_total_cost`, `total_cost`, `profit_margin_per`, `unit_sales_price`, `status`) VALUES (105, 14, 'Received', 272, '15.000', '48.000', 1, NULL, 'Exclusive', NULL, '0.000', '48.000', '720.000', NULL, NULL, 1);
INSERT INTO `db_purchaseitems` (`id`, `purchase_id`, `purchase_status`, `item_id`, `purchase_qty`, `price_per_unit`, `tax_id`, `tax_amt`, `tax_type`, `unit_discount_per`, `discount_amt`, `unit_total_cost`, `total_cost`, `profit_margin_per`, `unit_sales_price`, `status`) VALUES (106, 14, 'Received', 281, '2.000', '33.000', 1, NULL, 'Exclusive', NULL, '0.000', '33.000', '66.000', NULL, NULL, 1);
INSERT INTO `db_purchaseitems` (`id`, `purchase_id`, `purchase_status`, `item_id`, `purchase_qty`, `price_per_unit`, `tax_id`, `tax_amt`, `tax_type`, `unit_discount_per`, `discount_amt`, `unit_total_cost`, `total_cost`, `profit_margin_per`, `unit_sales_price`, `status`) VALUES (107, 14, 'Received', 282, '5.000', '12.300', 1, NULL, 'Exclusive', NULL, '0.000', '12.300', '61.500', NULL, NULL, 1);
INSERT INTO `db_purchaseitems` (`id`, `purchase_id`, `purchase_status`, `item_id`, `purchase_qty`, `price_per_unit`, `tax_id`, `tax_amt`, `tax_type`, `unit_discount_per`, `discount_amt`, `unit_total_cost`, `total_cost`, `profit_margin_per`, `unit_sales_price`, `status`) VALUES (108, 16, 'Received', 272, '14.000', '48.000', 1, NULL, 'Exclusive', NULL, '0.000', '48.000', '672.000', NULL, NULL, 1);
INSERT INTO `db_purchaseitems` (`id`, `purchase_id`, `purchase_status`, `item_id`, `purchase_qty`, `price_per_unit`, `tax_id`, `tax_amt`, `tax_type`, `unit_discount_per`, `discount_amt`, `unit_total_cost`, `total_cost`, `profit_margin_per`, `unit_sales_price`, `status`) VALUES (109, 17, 'Received', 114, '25.000', '8.000', 1, NULL, 'Exclusive', NULL, '0.000', '8.000', '200.000', NULL, NULL, 1);
INSERT INTO `db_purchaseitems` (`id`, `purchase_id`, `purchase_status`, `item_id`, `purchase_qty`, `price_per_unit`, `tax_id`, `tax_amt`, `tax_type`, `unit_discount_per`, `discount_amt`, `unit_total_cost`, `total_cost`, `profit_margin_per`, `unit_sales_price`, `status`) VALUES (110, 17, 'Received', 112, '25.000', '3.000', 1, NULL, 'Exclusive', NULL, '0.000', '3.000', '75.000', NULL, NULL, 1);
INSERT INTO `db_purchaseitems` (`id`, `purchase_id`, `purchase_status`, `item_id`, `purchase_qty`, `price_per_unit`, `tax_id`, `tax_amt`, `tax_type`, `unit_discount_per`, `discount_amt`, `unit_total_cost`, `total_cost`, `profit_margin_per`, `unit_sales_price`, `status`) VALUES (111, 17, 'Received', 111, '20.000', '3.320', 1, NULL, 'Exclusive', NULL, '0.000', '3.320', '66.400', NULL, NULL, 1);
INSERT INTO `db_purchaseitems` (`id`, `purchase_id`, `purchase_status`, `item_id`, `purchase_qty`, `price_per_unit`, `tax_id`, `tax_amt`, `tax_type`, `unit_discount_per`, `discount_amt`, `unit_total_cost`, `total_cost`, `profit_margin_per`, `unit_sales_price`, `status`) VALUES (112, 18, 'Received', 29, '15.000', '69.000', 1, NULL, 'Exclusive', NULL, '0.000', '69.000', '1035.000', NULL, NULL, 1);
INSERT INTO `db_purchaseitems` (`id`, `purchase_id`, `purchase_status`, `item_id`, `purchase_qty`, `price_per_unit`, `tax_id`, `tax_amt`, `tax_type`, `unit_discount_per`, `discount_amt`, `unit_total_cost`, `total_cost`, `profit_margin_per`, `unit_sales_price`, `status`) VALUES (113, 19, 'Received', 196, '20.000', '22.300', 1, NULL, 'Exclusive', NULL, '0.000', '22.300', '446.000', NULL, NULL, 1);
INSERT INTO `db_purchaseitems` (`id`, `purchase_id`, `purchase_status`, `item_id`, `purchase_qty`, `price_per_unit`, `tax_id`, `tax_amt`, `tax_type`, `unit_discount_per`, `discount_amt`, `unit_total_cost`, `total_cost`, `profit_margin_per`, `unit_sales_price`, `status`) VALUES (114, 20, 'Received', 307, '5.000', '37.000', 1, NULL, 'Exclusive', NULL, '0.000', '37.000', '185.000', NULL, NULL, 1);


#
# TABLE STRUCTURE FOR: db_purchaseitemsreturn
#

DROP TABLE IF EXISTS `db_purchaseitemsreturn`;

CREATE TABLE `db_purchaseitemsreturn` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `purchase_id` int(5) DEFAULT NULL,
  `return_id` int(5) DEFAULT NULL,
  `return_status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `item_id` int(5) DEFAULT NULL,
  `return_qty` double(20,3) DEFAULT NULL,
  `price_per_unit` double(20,3) DEFAULT NULL,
  `tax_id` int(5) DEFAULT NULL,
  `tax_amt` double(20,3) DEFAULT NULL,
  `tax_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unit_discount_per` double(20,3) DEFAULT NULL,
  `discount_amt` double(20,3) DEFAULT NULL,
  `unit_total_cost` double(20,3) DEFAULT NULL,
  `total_cost` double(20,3) DEFAULT NULL,
  `profit_margin_per` double(20,3) DEFAULT NULL,
  `unit_sales_price` double(20,3) DEFAULT NULL,
  `status` int(5) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_purchaseitemsreturn` (`id`, `purchase_id`, `return_id`, `return_status`, `item_id`, `return_qty`, `price_per_unit`, `tax_id`, `tax_amt`, `tax_type`, `unit_discount_per`, `discount_amt`, `unit_total_cost`, `total_cost`, `profit_margin_per`, `unit_sales_price`, `status`) VALUES (1, NULL, 1, 'Cancel', 1, '1.000', '200.000', 1, NULL, 'Exclusive', NULL, NULL, '200.000', '200.000', NULL, NULL, 1);
INSERT INTO `db_purchaseitemsreturn` (`id`, `purchase_id`, `return_id`, `return_status`, `item_id`, `return_qty`, `price_per_unit`, `tax_id`, `tax_amt`, `tax_type`, `unit_discount_per`, `discount_amt`, `unit_total_cost`, `total_cost`, `profit_margin_per`, `unit_sales_price`, `status`) VALUES (2, NULL, 2, 'Cancel', 1, '1.000', '200.000', 1, NULL, 'Exclusive', NULL, NULL, '200.000', '200.000', NULL, NULL, 1);


#
# TABLE STRUCTURE FOR: db_purchasepayments
#

DROP TABLE IF EXISTS `db_purchasepayments`;

CREATE TABLE `db_purchasepayments` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `purchase_id` int(5) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `payment_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment` double(20,2) DEFAULT NULL,
  `payment_note` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_ip` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_time` time DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_purchasepayments` (`id`, `purchase_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (15, 9, '2021-11-27', 'Cash', '12.00', '', '37.34.206.9', '37.34.206.9', '08:29:40', '2021-11-27', 'admin', 1);
INSERT INTO `db_purchasepayments` (`id`, `purchase_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (16, 8, '2021-11-21', 'Online', '23.00', '', '37.34.206.9', '37.34.206.9', '08:34:36', '2021-11-27', 'admin', 1);
INSERT INTO `db_purchasepayments` (`id`, `purchase_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (17, 8, '2021-11-21', 'Online', '15.00', '', '37.34.206.9', '37.34.206.9', '08:35:51', '2021-11-27', 'admin', 1);
INSERT INTO `db_purchasepayments` (`id`, `purchase_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (18, 7, '2021-11-21', 'Online', '915.00', '', '37.34.206.9', '37.34.206.9', '08:36:33', '2021-11-27', 'admin', 1);
INSERT INTO `db_purchasepayments` (`id`, `purchase_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (19, 12, '2021-12-09', 'Cheque', '330.00', '', '37.34.206.9', '37.34.206.9', '01:05:32', '2021-12-09', 'admin', 1);
INSERT INTO `db_purchasepayments` (`id`, `purchase_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (20, 13, '2021-12-12', 'Online', '557.00', '', '37.34.206.9', '37.34.206.9', '03:01:17', '2021-12-12', 'admin', 1);
INSERT INTO `db_purchasepayments` (`id`, `purchase_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (21, 14, '2021-12-18', 'Online', '847.50', '', '37.34.206.9', '37.34.206.9', '02:57:14', '2021-12-18', 'admin', 1);
INSERT INTO `db_purchasepayments` (`id`, `purchase_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (22, 17, '2021-12-21', 'Online', '341.40', '', '37.34.206.9', '37.34.206.9', '03:13:54', '2021-12-21', 'admin', 1);
INSERT INTO `db_purchasepayments` (`id`, `purchase_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (23, 18, '2021-12-22', 'Online', '1035.00', '', '37.34.206.9', '37.34.206.9', '12:58:09', '2021-12-22', 'admin', 1);
INSERT INTO `db_purchasepayments` (`id`, `purchase_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (24, 19, '2021-12-27', 'Online', '446.00', '', '37.34.206.9', '37.34.206.9', '09:17:13', '2021-12-27', 'admin', 1);
INSERT INTO `db_purchasepayments` (`id`, `purchase_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (25, 20, '2021-12-26', 'Cheque', '185.00', '', '37.34.206.9', '37.34.206.9', '10:21:58', '2022-01-05', 'admin', 1);


#
# TABLE STRUCTURE FOR: db_purchasepaymentsreturn
#

DROP TABLE IF EXISTS `db_purchasepaymentsreturn`;

CREATE TABLE `db_purchasepaymentsreturn` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `purchase_id` int(11) DEFAULT NULL,
  `return_id` int(5) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `payment_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment` double(20,3) DEFAULT NULL,
  `payment_note` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_ip` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_time` time DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_purchasepaymentsreturn` (`id`, `purchase_id`, `return_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (1, NULL, 1, '2021-07-03', 'Card', '198.000', '', '::1', 'DESKTOP-CMMNJOB', '09:16:00', '2021-06-12', 'admin', 1);
INSERT INTO `db_purchasepaymentsreturn` (`id`, `purchase_id`, `return_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (2, NULL, 2, '2021-06-23', 'Cash', '100.000', '', '::1', 'DESKTOP-CMMNJOB', '09:28:05', '2021-06-12', 'admin', 1);
INSERT INTO `db_purchasepaymentsreturn` (`id`, `purchase_id`, `return_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (3, NULL, 2, '2021-06-13', 'Finance', '98.000', '', '::1', 'DESKTOP-CMMNJOB', '08:17:38', '2021-06-13', 'admin', 1);


#
# TABLE STRUCTURE FOR: db_purchasereturn
#

DROP TABLE IF EXISTS `db_purchasereturn`;

CREATE TABLE `db_purchasereturn` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `purchase_id` int(11) DEFAULT NULL,
  `return_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_no` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `return_date` date DEFAULT NULL,
  `return_status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `supplier_id` int(5) DEFAULT NULL,
  `warehouse_id` int(5) DEFAULT NULL,
  `other_charges_input` double(20,3) DEFAULT NULL,
  `other_charges_tax_id` int(5) DEFAULT NULL,
  `other_charges_amt` double(20,3) DEFAULT NULL,
  `discount_to_all_input` double(20,3) DEFAULT NULL,
  `discount_to_all_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tot_discount_to_all_amt` double(20,3) DEFAULT NULL,
  `subtotal` double(20,3) DEFAULT NULL COMMENT 'Purchased qty',
  `round_off` double(20,3) DEFAULT NULL COMMENT 'Pending Qty',
  `grand_total` double(20,3) DEFAULT NULL,
  `return_note` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paid_amount` double(20,3) DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_time` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_ip` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_id` int(5) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_purchasereturn` (`id`, `purchase_id`, `return_code`, `reference_no`, `return_date`, `return_status`, `supplier_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `return_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `status`) VALUES (1, NULL, 'PR0001', 'Reference No', '2021-07-03', 'Cancel', 4, NULL, '20.000', NULL, '20.000', '10.000', 'in_percentage', '22.000', '200.000', NULL, '198.000', 'Note', 'Paid', '198.000', '2021-06-12', '09:16:00 pm', 'admin', '::1', 'DESKTOP-CMMNJOB', NULL, 1);
INSERT INTO `db_purchasereturn` (`id`, `purchase_id`, `return_code`, `reference_no`, `return_date`, `return_status`, `supplier_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `return_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `status`) VALUES (2, NULL, 'PR0002', 'Reference No', '2021-06-23', 'Cancel', 1, NULL, '20.000', NULL, '20.000', '10.000', 'in_percentage', '22.000', '200.000', NULL, '198.000', '', 'Paid', '198.000', '2021-06-12', '09:28:05 pm', 'admin', '::1', 'DESKTOP-CMMNJOB', NULL, 1);


#
# TABLE STRUCTURE FOR: db_rap_payment
#

DROP TABLE IF EXISTS `db_rap_payment`;

CREATE TABLE `db_rap_payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rap_payment_date` date NOT NULL,
  `rap_payment_kd` varchar(255) NOT NULL,
  `rap_payment_fils` varchar(255) NOT NULL,
  `rap_payment_no` varchar(50) NOT NULL,
  `rap_payment_customer_name` varchar(255) NOT NULL,
  `rap_payment_sum_of` varchar(255) NOT NULL,
  `rap_payment_on_bank` varchar(255) NOT NULL,
  `rap_payment_cash_or_check_no` varchar(255) NOT NULL,
  `rap_payment_beign_of` varchar(255) NOT NULL,
  `system_ip` varchar(50) NOT NULL,
  `system_name` varchar(50) NOT NULL,
  `created_date` date NOT NULL,
  `created_time` varchar(30) NOT NULL,
  `created_by` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

INSERT INTO `db_rap_payment` (`id`, `rap_payment_date`, `rap_payment_kd`, `rap_payment_fils`, `rap_payment_no`, `rap_payment_customer_name`, `rap_payment_sum_of`, `rap_payment_on_bank`, `rap_payment_cash_or_check_no`, `rap_payment_beign_of`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`) VALUES (1, '2021-06-20', '150', '', 'SV0001', '8', '150', '', 'cash', 'part payment    of invoice  14015', '37.34.206.9', '37.34.206.9', '2021-06-20', '12:06:21 pm', 'admin');


#
# TABLE STRUCTURE FOR: db_rap_reciept
#

DROP TABLE IF EXISTS `db_rap_reciept`;

CREATE TABLE `db_rap_reciept` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rap_reciept_date` date NOT NULL,
  `rap_reciept_kd` varchar(255) NOT NULL,
  `rap_reciept_fils` varchar(255) NOT NULL,
  `rap_reciept_no` varchar(50) NOT NULL,
  `rap_reciept_customer_name` varchar(255) NOT NULL,
  `rap_reciept_sum_of` varchar(255) NOT NULL,
  `rap_reciept_on_bank` varchar(255) NOT NULL,
  `rap_reciept_cash_or_check_no` varchar(255) NOT NULL,
  `rap_reciept_beign_of` varchar(255) NOT NULL,
  `system_ip` varchar(50) NOT NULL,
  `system_name` varchar(50) NOT NULL,
  `created_date` date NOT NULL,
  `created_time` varchar(30) NOT NULL,
  `created_by` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

INSERT INTO `db_rap_reciept` (`id`, `rap_reciept_date`, `rap_reciept_kd`, `rap_reciept_fils`, `rap_reciept_no`, `rap_reciept_customer_name`, `rap_reciept_sum_of`, `rap_reciept_on_bank`, `rap_reciept_cash_or_check_no`, `rap_reciept_beign_of`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`) VALUES (1, '2021-06-20', '160', '', '14576', '10', '160', '', 'cash', '', '37.34.206.9', '37.34.206.9', '2021-06-20', '08:47:43 am', 'admin');
INSERT INTO `db_rap_reciept` (`id`, `rap_reciept_date`, `rap_reciept_kd`, `rap_reciept_fils`, `rap_reciept_no`, `rap_reciept_customer_name`, `rap_reciept_sum_of`, `rap_reciept_on_bank`, `rap_reciept_cash_or_check_no`, `rap_reciept_beign_of`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`) VALUES (2, '2021-06-11', '45', '', '14530', '11', '45', 'NBK', '1450', 'INVOICE', '37.34.206.9', '37.34.206.9', '2021-06-20', '08:52:24 am', 'admin');
INSERT INTO `db_rap_reciept` (`id`, `rap_reciept_date`, `rap_reciept_kd`, `rap_reciept_fils`, `rap_reciept_no`, `rap_reciept_customer_name`, `rap_reciept_sum_of`, `rap_reciept_on_bank`, `rap_reciept_cash_or_check_no`, `rap_reciept_beign_of`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`) VALUES (3, '2021-06-20', '230', '', 'SV0003', '9', '230', 'k.net', '', 'invoice   1123', '37.34.206.9', '37.34.206.9', '2021-06-20', '12:04:31 pm', 'admin');
INSERT INTO `db_rap_reciept` (`id`, `rap_reciept_date`, `rap_reciept_kd`, `rap_reciept_fils`, `rap_reciept_no`, `rap_reciept_customer_name`, `rap_reciept_sum_of`, `rap_reciept_on_bank`, `rap_reciept_cash_or_check_no`, `rap_reciept_beign_of`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`) VALUES (4, '2021-07-19', '200', '', '', '13', 'Two Hundred   only', 'Kuwait   Finance  House', '1253', 'invoice  1465', '37.34.206.9', '37.34.206.9', '2021-07-19', '06:54:00 pm', 'admin');


#
# TABLE STRUCTURE FOR: db_roles
#

DROP TABLE IF EXISTS `db_roles`;

CREATE TABLE `db_roles` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_roles` (`id`, `role_name`, `description`, `status`) VALUES (1, 'Admin', 'All Rights Permitted.', 1);
INSERT INTO `db_roles` (`id`, `role_name`, `description`, `status`) VALUES (2, 'manager', 'manager', 1);
INSERT INTO `db_roles` (`id`, `role_name`, `description`, `status`) VALUES (3, 'technician', '', 1);


#
# TABLE STRUCTURE FOR: db_sales
#

DROP TABLE IF EXISTS `db_sales`;

CREATE TABLE `db_sales` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `sales_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_no` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sales_date` date DEFAULT NULL,
  `sales_status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_id` int(5) DEFAULT NULL,
  `warehouse_id` int(5) DEFAULT NULL,
  `other_charges_input` double(20,3) DEFAULT NULL,
  `other_charges_tax_id` int(5) DEFAULT NULL,
  `other_charges_amt` double(20,3) DEFAULT NULL,
  `discount_to_all_input` double(20,3) DEFAULT NULL,
  `discount_to_all_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tot_discount_to_all_amt` double(20,3) DEFAULT NULL,
  `subtotal` double(20,3) DEFAULT NULL,
  `round_off` double(20,3) DEFAULT NULL,
  `grand_total` double(20,3) DEFAULT NULL,
  `sales_note` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paid_amount` double(20,3) DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_time` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_ip` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_id` int(5) DEFAULT NULL,
  `pos` int(1) DEFAULT NULL COMMENT '1=yes 0=no',
  `status` int(1) DEFAULT NULL,
  `return_bit` int(1) DEFAULT NULL COMMENT 'sales return raised',
  `remarks` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_sales` (`id`, `sales_code`, `reference_no`, `sales_date`, `sales_status`, `customer_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `sales_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `pos`, `status`, `return_bit`, `remarks`) VALUES (1, 'SL0001', '14811', '2021-09-18', 'Final', 27, NULL, NULL, NULL, NULL, '5.000', 'in_fixed', '5.000', '392.500', NULL, '387.500', '', 'Partial', '17.000', '2021-09-18', '04:07:51 pm', 'admin', '37.34.206.9', '37.34.206.9', NULL, NULL, 1, NULL, 'Through   Mr. Murugan   72857  Car   Delivered  on  11.11.2021');
INSERT INTO `db_sales` (`id`, `sales_code`, `reference_no`, `sales_date`, `sales_status`, `customer_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `sales_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `pos`, `status`, `return_bit`, `remarks`) VALUES (2, 'SL0002', '14846', '2021-09-29', 'Final', 12, NULL, NULL, NULL, NULL, NULL, 'in_percentage', NULL, '250.000', NULL, '250.000', '', 'Unpaid', '0.000', '2021-09-29', '06:56:16 pm', 'admin', '37.34.206.9', '37.34.206.9', NULL, NULL, 1, NULL, '');
INSERT INTO `db_sales` (`id`, `sales_code`, `reference_no`, `sales_date`, `sales_status`, `customer_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `sales_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `pos`, `status`, `return_bit`, `remarks`) VALUES (3, 'SL0003', '19.10.21', '2021-10-19', 'Final', 28, NULL, NULL, NULL, NULL, NULL, 'in_percentage', NULL, '1.250', NULL, '1.250', '', 'Paid', '1.250', '2021-10-19', '03:15:24 pm', 'admin', '37.34.206.9', '37.34.206.9', NULL, NULL, 1, NULL, 'hard drive-1');
INSERT INTO `db_sales` (`id`, `sales_code`, `reference_no`, `sales_date`, `sales_status`, `customer_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `sales_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `pos`, `status`, `return_bit`, `remarks`) VALUES (4, 'SL0004', '14913', '2021-10-25', 'Final', 12, NULL, NULL, NULL, NULL, NULL, 'in_percentage', NULL, '250.000', NULL, '250.000', '', 'Paid', '250.000', '2021-10-25', '11:37:38 am', 'admin', '37.34.206.9', '37.34.206.9', NULL, NULL, 1, NULL, '');
INSERT INTO `db_sales` (`id`, `sales_code`, `reference_no`, `sales_date`, `sales_status`, `customer_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `sales_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `pos`, `status`, `return_bit`, `remarks`) VALUES (5, 'SL0005', '14915', '2021-10-27', 'Final', 29, NULL, NULL, NULL, NULL, NULL, 'in_percentage', NULL, '153.000', NULL, '153.000', '', 'Unpaid', '0.000', '2021-10-27', '01:08:46 pm', 'admin', '37.34.206.9', '37.34.206.9', NULL, NULL, 1, NULL, '');
INSERT INTO `db_sales` (`id`, `sales_code`, `reference_no`, `sales_date`, `sales_status`, `customer_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `sales_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `pos`, `status`, `return_bit`, `remarks`) VALUES (6, 'SL0006', '14938', '2021-11-02', 'Final', 12, NULL, NULL, NULL, NULL, NULL, 'in_percentage', NULL, '14.000', NULL, '14.000', '', 'Unpaid', '0.000', '2021-11-02', '06:42:30 pm', 'admin', '37.34.206.9', '37.34.206.9', NULL, NULL, 1, NULL, 'I face 100');
INSERT INTO `db_sales` (`id`, `sales_code`, `reference_no`, `sales_date`, `sales_status`, `customer_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `sales_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `pos`, `status`, `return_bit`, `remarks`) VALUES (7, 'SL0007', '14956', '2021-11-11', 'Final', 30, NULL, NULL, NULL, NULL, NULL, 'in_percentage', NULL, '72.000', NULL, '72.000', '', 'Unpaid', '0.000', '2021-11-11', '03:38:49 pm', 'admin', '37.34.206.9', '37.34.206.9', NULL, NULL, 1, NULL, '');
INSERT INTO `db_sales` (`id`, `sales_code`, `reference_no`, `sales_date`, `sales_status`, `customer_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `sales_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `pos`, `status`, `return_bit`, `remarks`) VALUES (8, 'SL0008', '14968', '2021-11-20', 'Final', 20, NULL, NULL, NULL, NULL, NULL, 'in_percentage', NULL, '0.000', NULL, '0.000', '', 'Paid', '0.000', '2021-11-20', '06:04:49 pm', 'admin', '37.34.206.9', '37.34.206.9', NULL, NULL, 1, NULL, 'delivered to Ahmed');
INSERT INTO `db_sales` (`id`, `sales_code`, `reference_no`, `sales_date`, `sales_status`, `customer_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `sales_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `pos`, `status`, `return_bit`, `remarks`) VALUES (9, 'SL0009', '15006', '2021-11-29', 'Final', 12, NULL, NULL, NULL, NULL, NULL, 'in_percentage', NULL, '250.000', NULL, '250.000', '', 'Unpaid', '0.000', '2021-11-29', '05:21:33 pm', 'admin', '37.34.206.9', '37.34.206.9', NULL, NULL, 1, NULL, '');
INSERT INTO `db_sales` (`id`, `sales_code`, `reference_no`, `sales_date`, `sales_status`, `customer_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `sales_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `pos`, `status`, `return_bit`, `remarks`) VALUES (10, 'SL0010', '', '2021-11-30', 'Quotation', 10, NULL, NULL, NULL, NULL, NULL, 'in_percentage', NULL, '20.000', NULL, '20.000', '', 'Unpaid', '0.000', '2021-11-30', '04:49:09 pm', 'admin', '37.34.206.9', '37.34.206.9', NULL, NULL, 1, NULL, 'cvbcvbc');
INSERT INTO `db_sales` (`id`, `sales_code`, `reference_no`, `sales_date`, `sales_status`, `customer_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `sales_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `pos`, `status`, `return_bit`, `remarks`) VALUES (11, 'SL0011', '15017', '2021-12-05', 'Final', 32, NULL, NULL, NULL, NULL, NULL, 'in_percentage', NULL, '264.150', NULL, '264.150', '', 'Unpaid', '0.000', '2021-12-05', '08:51:34 pm', 'admin', '37.34.206.9', '37.34.206.9', NULL, NULL, 1, NULL, '');
INSERT INTO `db_sales` (`id`, `sales_code`, `reference_no`, `sales_date`, `sales_status`, `customer_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `sales_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `pos`, `status`, `return_bit`, `remarks`) VALUES (12, 'SL0012', '15059', '2021-12-20', 'Final', 34, NULL, NULL, 1, NULL, '5.000', 'in_fixed', '5.000', '65.000', NULL, '60.000', '', 'Unpaid', '0.000', '2021-12-20', '01:18:51 pm', 'admin', '37.34.206.9', '37.34.206.9', NULL, NULL, 1, NULL, '');
INSERT INTO `db_sales` (`id`, `sales_code`, `reference_no`, `sales_date`, `sales_status`, `customer_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `sales_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `pos`, `status`, `return_bit`, `remarks`) VALUES (13, 'SL0013', '15070', '2021-12-22', 'Final', 20, NULL, NULL, NULL, NULL, NULL, 'in_percentage', NULL, '28.500', NULL, '28.500', '', 'Unpaid', '0.000', '2021-12-22', '02:32:22 pm', 'admin', '37.34.206.9', '37.34.206.9', NULL, NULL, 1, NULL, '');
INSERT INTO `db_sales` (`id`, `sales_code`, `reference_no`, `sales_date`, `sales_status`, `customer_id`, `warehouse_id`, `other_charges_input`, `other_charges_tax_id`, `other_charges_amt`, `discount_to_all_input`, `discount_to_all_type`, `tot_discount_to_all_amt`, `subtotal`, `round_off`, `grand_total`, `sales_note`, `payment_status`, `paid_amount`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `pos`, `status`, `return_bit`, `remarks`) VALUES (14, 'SL0014', '15089', '2021-12-28', 'Final', 12, NULL, NULL, NULL, NULL, NULL, 'in_percentage', NULL, '250.000', NULL, '250.000', '', 'Unpaid', '0.000', '2021-12-28', '10:18:08 am', 'admin', '37.34.206.9', '37.34.206.9', NULL, NULL, 1, NULL, '');


#
# TABLE STRUCTURE FOR: db_salesitems
#

DROP TABLE IF EXISTS `db_salesitems`;

CREATE TABLE `db_salesitems` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `sales_id` int(5) DEFAULT NULL,
  `sales_status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `item_id` int(5) DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sales_qty` double(20,3) DEFAULT NULL,
  `price_per_unit` double(20,3) DEFAULT NULL,
  `tax_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax_id` int(5) DEFAULT NULL,
  `tax_amt` double(20,3) DEFAULT NULL,
  `discount_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `discount_input` double(20,3) DEFAULT NULL,
  `discount_amt` double(20,3) DEFAULT NULL,
  `unit_total_cost` double(20,3) DEFAULT NULL,
  `total_cost` double(20,3) DEFAULT NULL,
  `status` int(5) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=577 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`) VALUES (276, 0, 'Final', 1, '', '1.000', '220.000', 'Exclusive', 1, NULL, 'Percentage', NULL, '0.000', '220.000', '220.000', 1);
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`) VALUES (457, 2, 'Final', 30, '', '1.000', '250.000', 'Exclusive', 1, NULL, 'Percentage', NULL, '0.000', '250.000', '250.000', 1);
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`) VALUES (480, 3, 'Final', 45, '', '1.000', '1.250', 'Exclusive', 1, NULL, 'Percentage', NULL, '0.000', '1.250', '1.250', 1);
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`) VALUES (481, 4, 'Final', 59, '', '1.000', '250.000', 'Exclusive', 1, NULL, 'Percentage', NULL, '0.000', '250.000', '250.000', 1);
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`) VALUES (487, 6, 'Final', 82, '', '1.000', '14.000', 'Exclusive', 1, NULL, 'Percentage', NULL, '0.000', '14.000', '14.000', 1);
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`) VALUES (488, 7, 'Final', 26, '', '1.000', '72.000', 'Exclusive', 1, NULL, 'Percentage', NULL, '0.000', '72.000', '72.000', 1);
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`) VALUES (531, 8, 'Final', 191, '', '1.000', '360.000', 'Exclusive', 1, NULL, 'Percentage', NULL, '0.000', '360.000', '360.000', 1);
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`) VALUES (532, 8, 'Final', 192, '', '1.000', '0.000', 'Exclusive', 1, NULL, 'Percentage', NULL, '0.000', '0.000', NULL, 1);
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`) VALUES (533, 8, 'Final', 51, '', '1.000', '0.000', 'Exclusive', 1, NULL, 'Percentage', NULL, '0.000', '0.000', NULL, 1);
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`) VALUES (534, 8, 'Final', 70, '', '1.000', '0.000', 'Exclusive', 1, NULL, 'Percentage', NULL, '0.000', '0.000', NULL, 1);
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`) VALUES (535, 8, 'Final', 129, '', '1.000', '0.000', 'Exclusive', 1, NULL, 'Percentage', NULL, '0.000', '0.000', NULL, 1);
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`) VALUES (536, 1, 'Final', 3, '', '1.000', '0.000', 'Exclusive', 1, NULL, 'Percentage', NULL, '0.000', '0.000', NULL, 1);
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`) VALUES (537, 1, 'Final', 4, '', '1.000', '0.000', 'Exclusive', 1, NULL, 'Percentage', NULL, '0.000', '0.000', NULL, 1);
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`) VALUES (538, 1, 'Final', 5, '', '1.000', '15.000', 'Exclusive', 1, NULL, 'Percentage', NULL, '0.000', '15.000', '15.000', 1);
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`) VALUES (539, 1, 'Final', 6, '', '1.000', '8.000', 'Exclusive', 1, NULL, 'Percentage', NULL, '0.000', '8.000', '8.000', 1);
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`) VALUES (540, 1, 'Final', 7, '', '1.000', '0.000', 'Exclusive', 1, NULL, 'Percentage', NULL, '0.000', '0.000', NULL, 1);
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`) VALUES (541, 1, 'Final', 8, '', '1.000', '0.000', 'Exclusive', 1, NULL, 'Percentage', NULL, '0.000', '0.000', NULL, 1);
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`) VALUES (542, 1, 'Final', 9, '', '1.000', '3.000', 'Exclusive', 1, NULL, 'Percentage', NULL, '0.000', '3.000', '3.000', 1);
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`) VALUES (543, 1, 'Final', 29, '', '2.000', '128.000', 'Exclusive', 1, NULL, 'Percentage', NULL, '0.000', '128.000', '256.000', 1);
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`) VALUES (544, 1, 'Final', 1, '', '1.000', '8.000', 'Exclusive', 1, NULL, 'Percentage', NULL, '0.000', '8.000', '8.000', 1);
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`) VALUES (545, 1, 'Final', 2, '', '1.000', '10.000', 'Exclusive', 1, NULL, 'Percentage', NULL, '0.000', '10.000', '10.000', 1);
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`) VALUES (546, 1, 'Final', 133, '', '1.000', '16.000', 'Exclusive', 1, NULL, 'Percentage', NULL, '0.000', '16.000', '16.000', 1);
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`) VALUES (547, 1, 'Final', 15, '', '1.000', '35.000', 'Exclusive', 1, NULL, 'Percentage', NULL, '0.000', '35.000', '35.000', 1);
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`) VALUES (548, 1, 'Final', 17, '', '1.000', '25.000', 'Exclusive', 1, NULL, 'Percentage', NULL, '0.000', '25.000', '25.000', 1);
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`) VALUES (549, 1, 'Final', 66, '', '1.000', '7.000', 'Exclusive', 1, NULL, 'Percentage', NULL, '0.000', '7.000', '7.000', 1);
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`) VALUES (550, 1, 'Final', 102, '', '1.000', '1.500', 'Exclusive', 1, NULL, 'Percentage', NULL, '0.000', '1.500', '1.500', 1);
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`) VALUES (551, 1, 'Final', 103, '', '1.000', '1.500', 'Exclusive', 1, NULL, 'Percentage', NULL, '0.000', '1.500', '1.500', 1);
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`) VALUES (552, 1, 'Final', 159, '', '1.000', '6.500', 'Exclusive', 1, NULL, 'Percentage', NULL, '0.000', '6.500', '6.500', 1);
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`) VALUES (553, 9, 'Final', 211, '', '1.000', '250.000', 'Exclusive', 1, NULL, 'Percentage', NULL, '0.000', '250.000', '250.000', 1);
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`) VALUES (554, 10, 'Quotation', 2, '', '1.000', '10.000', 'Exclusive', 1, NULL, 'Percentage', NULL, '0.000', '10.000', '10.000', 1);
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`) VALUES (555, 10, 'Quotation', 2, '', '1.000', '10.000', 'Exclusive', 1, NULL, 'Percentage', NULL, '0.000', '10.000', '10.000', 1);
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`) VALUES (556, 11, 'Final', 18, '', '4.000', '24.000', 'Exclusive', 1, NULL, 'Percentage', NULL, '0.000', '24.000', '96.000', 1);
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`) VALUES (557, 11, 'Final', 92, '', '1.000', '76.000', 'Exclusive', 1, NULL, 'Percentage', NULL, '0.000', '76.000', '76.000', 1);
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`) VALUES (558, 11, 'Final', 147, '', '1.000', '32.000', 'Exclusive', 1, NULL, 'Percentage', NULL, '0.000', '32.000', '32.000', 1);
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`) VALUES (559, 11, 'Final', 77, '', '20.000', '0.110', 'Exclusive', 1, NULL, 'Percentage', NULL, '0.000', '0.110', '2.200', 1);
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`) VALUES (560, 11, 'Final', 71, '', '610.000', '0.095', 'Exclusive', 1, NULL, 'Percentage', NULL, '0.000', '0.095', '57.950', 1);
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`) VALUES (562, 12, 'Final', 284, '', '1.000', '65.000', 'Exclusive', 1, NULL, 'Percentage', NULL, '0.000', '65.000', '65.000', 1);
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`) VALUES (566, 13, 'Final', 291, '', '2.000', '19.250', 'Exclusive', 1, NULL, 'Fixed', '10.000', '10.000', '14.250', '28.500', 1);
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`) VALUES (572, 14, 'Final', 293, '', '1.000', '250.000', 'Exclusive', 1, NULL, 'Percentage', NULL, '0.000', '250.000', '250.000', 1);
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`) VALUES (573, 5, 'Final', 68, '3080  Dell Optiplex  Desktop   Computer . Core i5-10500/ 8GB  /1 TB  / 256 SSD    NVME    with  Windows 10 Professional   . SNO  C7rh8f3 .', '1.000', '153.000', 'Exclusive', 1, NULL, 'Percentage', NULL, '0.000', '153.000', '153.000', 1);
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`) VALUES (574, 5, 'Final', 69, '', '1.000', '0.000', 'Exclusive', 1, NULL, 'Percentage', NULL, '0.000', '0.000', NULL, 1);
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`) VALUES (575, 5, 'Final', 60, '', '1.000', '0.000', 'Exclusive', 1, NULL, 'Percentage', NULL, '0.000', '0.000', NULL, 1);
INSERT INTO `db_salesitems` (`id`, `sales_id`, `sales_status`, `item_id`, `description`, `sales_qty`, `price_per_unit`, `tax_type`, `tax_id`, `tax_amt`, `discount_type`, `discount_input`, `discount_amt`, `unit_total_cost`, `total_cost`, `status`) VALUES (576, 5, 'Final', 70, '', '1.000', '0.000', 'Exclusive', 1, NULL, 'Percentage', NULL, '0.000', '0.000', NULL, 1);


#
# TABLE STRUCTURE FOR: db_salesitemsreturn
#

DROP TABLE IF EXISTS `db_salesitemsreturn`;

CREATE TABLE `db_salesitemsreturn` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `sales_id` int(5) DEFAULT NULL,
  `return_id` int(5) DEFAULT NULL,
  `return_status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `item_id` int(5) DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `return_qty` double(20,3) DEFAULT NULL,
  `price_per_unit` double(20,3) DEFAULT NULL,
  `tax_id` int(5) DEFAULT NULL,
  `tax_amt` double(20,3) DEFAULT NULL,
  `tax_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `discount_input` double(20,3) DEFAULT NULL,
  `discount_amt` double(20,3) DEFAULT NULL,
  `discount_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unit_total_cost` double(20,3) DEFAULT NULL,
  `total_cost` double(20,3) DEFAULT NULL,
  `status` int(5) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: db_salespayments
#

DROP TABLE IF EXISTS `db_salespayments`;

CREATE TABLE `db_salespayments` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `sales_id` int(5) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `payment_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment` double(20,3) DEFAULT NULL,
  `payment_note` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `change_return` double(20,3) DEFAULT NULL COMMENT 'Refunding the greater amount',
  `system_ip` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_time` time DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_salespayments` (`id`, `sales_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `change_return`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (10, 0, '1970-01-01', 'Cash', '200.000', '', NULL, '::1', 'DESKTOP-CMMNJOB', '05:03:14', '2021-05-01', 'admin', 1);
INSERT INTO `db_salespayments` (`id`, `sales_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `change_return`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (11, 0, '1970-01-01', 'Cash', '378.000', '', NULL, '::1', 'DESKTOP-CMMNJOB', '05:06:39', '2021-05-01', 'admin', 1);
INSERT INTO `db_salespayments` (`id`, `sales_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `change_return`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (52, 1, '2021-09-21', 'Cash', '17.000', '', NULL, '37.34.206.9', '37.34.206.9', '04:09:38', '2021-09-21', 'admin', 1);
INSERT INTO `db_salespayments` (`id`, `sales_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `change_return`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (53, 4, '2021-12-16', 'Cash', '250.000', '', NULL, '37.34.206.9', '37.34.206.9', '06:26:09', '2021-12-16', 'admin', 1);
INSERT INTO `db_salespayments` (`id`, `sales_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `change_return`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (54, 3, '2021-12-16', 'Cash', '1.250', '', NULL, '37.34.206.9', '37.34.206.9', '06:26:26', '2021-12-16', 'admin', 1);


#
# TABLE STRUCTURE FOR: db_salespaymentsreturn
#

DROP TABLE IF EXISTS `db_salespaymentsreturn`;

CREATE TABLE `db_salespaymentsreturn` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `sales_id` int(5) DEFAULT NULL,
  `return_id` int(5) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `payment_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment` double(20,3) DEFAULT NULL,
  `payment_note` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `change_return` double(20,3) DEFAULT NULL COMMENT 'Refunding the greater amount',
  `system_ip` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_time` time DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: db_salesreturn
#

DROP TABLE IF EXISTS `db_salesreturn`;

CREATE TABLE `db_salesreturn` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `sales_id` int(5) DEFAULT NULL,
  `return_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_no` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `return_date` date DEFAULT NULL,
  `return_status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_id` int(5) DEFAULT NULL,
  `warehouse_id` int(5) DEFAULT NULL,
  `other_charges_input` double(20,3) DEFAULT NULL,
  `other_charges_tax_id` int(5) DEFAULT NULL,
  `other_charges_amt` double(20,3) DEFAULT NULL,
  `discount_to_all_input` double(20,3) DEFAULT NULL,
  `discount_to_all_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tot_discount_to_all_amt` double(20,3) DEFAULT NULL,
  `subtotal` double(20,3) DEFAULT NULL,
  `round_off` double(20,3) DEFAULT NULL,
  `grand_total` double(20,3) DEFAULT NULL,
  `return_note` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paid_amount` double(20,3) DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_time` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_ip` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_id` int(5) DEFAULT NULL,
  `pos` int(1) DEFAULT NULL COMMENT '1=yes 0=no',
  `status` int(1) DEFAULT NULL,
  `return_bit` int(1) DEFAULT NULL COMMENT 'Return raised or not 1 or null',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: db_services
#

DROP TABLE IF EXISTS `db_services`;

CREATE TABLE `db_services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `services_date` date DEFAULT NULL,
  `services_no` varchar(50) DEFAULT NULL,
  `services_customer_name` varchar(20) DEFAULT NULL,
  `services_details` text DEFAULT NULL,
  `services_technician_id` int(11) DEFAULT NULL,
  `services_status` varchar(10) DEFAULT NULL,
  `services_stock_used` double(20,3) DEFAULT NULL,
  `services_invoice_no` varchar(50) DEFAULT NULL,
  `services_invoice_id` int(11) NOT NULL,
  `services_remarks` text DEFAULT NULL,
  `services_returns` text DEFAULT NULL,
  `services_expences` double(20,3) DEFAULT NULL,
  `system_ip` varchar(50) DEFAULT NULL,
  `system_name` varchar(50) DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_time` varchar(30) DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4;

INSERT INTO `db_services` (`id`, `services_date`, `services_no`, `services_customer_name`, `services_details`, `services_technician_id`, `services_status`, `services_stock_used`, `services_invoice_no`, `services_invoice_id`, `services_remarks`, `services_returns`, `services_expences`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`) VALUES (3, '2021-05-02', 'SV0001', '3', 'details', 3, 'Processing', '1.000', 'SL0010', 10, 'Remarks', 'Returns', '40.000', '::1', 'DESKTOP-CMMNJOB', '2021-05-02', '03:08:14 pm', 'admin');
INSERT INTO `db_services` (`id`, `services_date`, `services_no`, `services_customer_name`, `services_details`, `services_technician_id`, `services_status`, `services_stock_used`, `services_invoice_no`, `services_invoice_id`, `services_remarks`, `services_returns`, `services_expences`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`) VALUES (4, '2021-05-02', 'SV0004', '4', 'details dd', 3, 'Hold', '5.000', 'SL0011', 11, 'Remarks', 'Returns', '500.120', '::1', 'DESKTOP-CMMNJOB', '2021-05-02', '08:37:24 pm', 'admin');
INSERT INTO `db_services` (`id`, `services_date`, `services_no`, `services_customer_name`, `services_details`, `services_technician_id`, `services_status`, `services_stock_used`, `services_invoice_no`, `services_invoice_id`, `services_remarks`, `services_returns`, `services_expences`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`) VALUES (5, '2021-05-02', 'SV0006', '1', 'details', 2, 'Completed', '2.000', 'SL0013', 13, 'Remarks', 'Returns', '33.000', '::1', 'DESKTOP-CMMNJOB', '2021-05-02', '09:26:04 pm', 'admin');
INSERT INTO `db_services` (`id`, `services_date`, `services_no`, `services_customer_name`, `services_details`, `services_technician_id`, `services_status`, `services_stock_used`, `services_invoice_no`, `services_invoice_id`, `services_remarks`, `services_returns`, `services_expences`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`) VALUES (6, '2021-05-26', 'SV0006', '1', 'details', 5, 'Completed', '1.000', 'SL0014', 14, 'Remarks', 'Returns', '400.000', '::1', 'DESKTOP-CMMNJOB', '2021-05-04', '08:34:46 pm', 'admin');
INSERT INTO `db_services` (`id`, `services_date`, `services_no`, `services_customer_name`, `services_details`, `services_technician_id`, `services_status`, `services_stock_used`, `services_invoice_no`, `services_invoice_id`, `services_remarks`, `services_returns`, `services_expences`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`) VALUES (7, '2021-05-08', 'SV0007', '2', 'Job details', 5, 'Processing', '1.000', 'SL0019', 19, 'Remarks 2\r\n', 'Returns', '40.000', '::1', 'DESKTOP-CMMNJOB', '2021-05-08', '06:56:23 am', 'admin');
INSERT INTO `db_services` (`id`, `services_date`, `services_no`, `services_customer_name`, `services_details`, `services_technician_id`, `services_status`, `services_stock_used`, `services_invoice_no`, `services_invoice_id`, `services_remarks`, `services_returns`, `services_expences`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`) VALUES (8, '2021-05-09', 'SV0008', '1', 'details', 4, 'Hold', '1.000', 'SL0020', 20, 'Remarks', 'Returns', '40.126', '::1', 'DESKTOP-CMMNJOB', '2021-05-09', '08:54:49 pm', 'admin');
INSERT INTO `db_services` (`id`, `services_date`, `services_no`, `services_customer_name`, `services_details`, `services_technician_id`, `services_status`, `services_stock_used`, `services_invoice_no`, `services_invoice_id`, `services_remarks`, `services_returns`, `services_expences`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`) VALUES (9, '2021-06-17', 'SV0009', '10', 'Monthly Maintenance  Charges for 2021 ', 2, 'Processing', '0.000', '', 0, '', '', '0.000', '37.34.206.9', '37.34.206.9', '2021-06-17', '07:42:59 pm', 'admin');
INSERT INTO `db_services` (`id`, `services_date`, `services_no`, `services_customer_name`, `services_details`, `services_technician_id`, `services_status`, `services_stock_used`, `services_invoice_no`, `services_invoice_id`, `services_remarks`, `services_returns`, `services_expences`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`) VALUES (10, '2021-07-03', 'SV0010', '13', 'ThinkPad E15,Core i7-10510U, 8GB DDR4, 256GB SSD M.2 Nvme + 1TB 5400rpm Sata hd, AMD RX640 2GB Graphics, 15.6&quot; FHD TN, Intel AX201 2x2 + BT,Y-FPR,FW-TPM 2.0,720p HD Camera, 3 Cell 45Whr,65W USB-C UK,KYB Local Arabized) w/Num Pad, Windows 10 Pro, One Years Carry-in, BLACK + Lenovo Case', 2, 'Processing', '0.000', '', 0, '', '', '0.000', '37.34.206.9', '37.34.206.9', '2021-07-03', '06:54:28 pm', 'admin');
INSERT INTO `db_services` (`id`, `services_date`, `services_no`, `services_customer_name`, `services_details`, `services_technician_id`, `services_status`, `services_stock_used`, `services_invoice_no`, `services_invoice_id`, `services_remarks`, `services_returns`, `services_expences`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`) VALUES (11, '2021-07-07', 'SV0011', '1', ' Desktop  Computer  Opr system with Softwares ', 2, 'Processing', '0.000', '', 0, '', '', '0.000', '37.34.206.9', '37.34.206.9', '2021-07-07', '04:09:38 pm', 'admin');
INSERT INTO `db_services` (`id`, `services_date`, `services_no`, `services_customer_name`, `services_details`, `services_technician_id`, `services_status`, `services_stock_used`, `services_invoice_no`, `services_invoice_id`, `services_remarks`, `services_returns`, `services_expences`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`) VALUES (12, '2021-07-19', 'SV0012', '1', 'Pc    OPr System', 2, 'Completed', '0.000', 'SL0038', 38, '', '', '0.000', '37.34.206.9', '37.34.206.9', '2021-07-19', '06:32:14 pm', 'admin');


#
# TABLE STRUCTURE FOR: db_sitesettings
#

DROP TABLE IF EXISTS `db_sitesettings`;

CREATE TABLE `db_sitesettings` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `version` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `site_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'path',
  `language_id` int(5) DEFAULT NULL,
  `currency_id` int(5) DEFAULT NULL,
  `currency_placement` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `timezone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_format` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `time_format` int(5) DEFAULT NULL,
  `sales_discount` double(20,3) DEFAULT NULL,
  `site_url` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `site_title` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_title` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_desc` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_keywords` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currencysymbol_id` int(5) DEFAULT NULL,
  `regno_key` varchar(6) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `copyright` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `facebook_url` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter_url` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `youtube_url` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `analytic_code` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fav_icon` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'path',
  `footer_logo` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'path',
  `company_id` int(1) DEFAULT NULL,
  `purchase_code` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `change_return` int(1) DEFAULT NULL COMMENT 'show in pos',
  `sales_invoice_format_id` int(5) DEFAULT NULL,
  `sales_invoice_footer_text` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `round_off` int(1) DEFAULT NULL COMMENT '1=Enble, 0=Disable',
  `machine_id` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `domain` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `show_upi_code` int(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `currencysymbol_id` (`currencysymbol_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_sitesettings` (`id`, `version`, `site_name`, `logo`, `language_id`, `currency_id`, `currency_placement`, `timezone`, `date_format`, `time_format`, `sales_discount`, `site_url`, `site_title`, `meta_title`, `meta_desc`, `meta_keywords`, `currencysymbol_id`, `regno_key`, `copyright`, `facebook_url`, `twitter_url`, `youtube_url`, `analytic_code`, `fav_icon`, `footer_logo`, `company_id`, `purchase_code`, `change_return`, `sales_invoice_format_id`, `sales_invoice_footer_text`, `round_off`, `machine_id`, `domain`, `show_upi_code`) VALUES (1, '1.7.7', 'Softline Technolgy', 'company_logo-small.png', 1, 56, 'Left', 'Asia/Kuwait\r\n', 'dd-mm-yyyy', 12, '0.000', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 4, ' Note: if cheque kindly prepares the cheque name of softline electrical and electronic supplier. * Goods once sold will not be taken back or Exchanged', 0, '74be16979710d4c4e7c6647856088456', 'localhost', 1);


#
# TABLE STRUCTURE FOR: db_smsapi
#

DROP TABLE IF EXISTS `db_smsapi`;

CREATE TABLE `db_smsapi` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `info` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `key` varchar(600) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `key_value` varchar(600) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `delete_bit` int(5) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=150 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_smsapi` (`id`, `info`, `key`, `key_value`, `delete_bit`) VALUES (144, 'url', 'weblink', 'http://www.example.in/api/sendhttp.php', NULL);
INSERT INTO `db_smsapi` (`id`, `info`, `key`, `key_value`, `delete_bit`) VALUES (145, 'mobile', 'mobiles', '', NULL);
INSERT INTO `db_smsapi` (`id`, `info`, `key`, `key_value`, `delete_bit`) VALUES (146, 'message', 'message', '', NULL);
INSERT INTO `db_smsapi` (`id`, `info`, `key`, `key_value`, `delete_bit`) VALUES (147, '', 'authkey', 'xxxxxxxxxxxxxxxxxxxx', NULL);
INSERT INTO `db_smsapi` (`id`, `info`, `key`, `key_value`, `delete_bit`) VALUES (148, '', 'sender', 'ULTPOS', NULL);
INSERT INTO `db_smsapi` (`id`, `info`, `key`, `key_value`, `delete_bit`) VALUES (149, '', 'route', '1', NULL);


#
# TABLE STRUCTURE FOR: db_smstemplates
#

DROP TABLE IF EXISTS `db_smstemplates`;

CREATE TABLE `db_smstemplates` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `template_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `variables` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_id` int(5) DEFAULT NULL,
  `status` int(5) DEFAULT NULL,
  `undelete_bit` int(5) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_smstemplates` (`id`, `template_name`, `content`, `variables`, `company_id`, `status`, `undelete_bit`) VALUES (1, 'GREETING TO CUSTOMER ON SALES', 'Hi {{customer_name}},\r\nYour sales Id is {{sales_id}},\r\nSales Date {{sales_date}},\r\nTotal amount  {{sales_amount}},\r\nYou have paid  {{paid_amt}},\r\nand due amount is  {{due_amt}}\r\nThank you Visit Again', '{{customer_name}}<br>                          \r\n{{sales_id}}<br>\r\n{{sales_date}}<br>\r\n{{sales_amount}}<br>\r\n{{paid_amt}}<br>\r\n{{due_amt}}<br>\r\n{{company_name}}<br>\r\n{{company_mobile}}<br>\r\n{{company_address}}<br>\r\n{{company_website}}<br>\r\n{{company_email}}<br>', NULL, 1, 1);
INSERT INTO `db_smstemplates` (`id`, `template_name`, `content`, `variables`, `company_id`, `status`, `undelete_bit`) VALUES (2, 'GREETING TO CUSTOMER ON SALES RETURN', 'Hi {{customer_name}},\r\nYour sales return Id is {{return_id}},\r\nReturn Date {{return_date}},\r\nTotal amount  {{return_amount}},\r\nWe paid  {{paid_amt}},\r\nand due amount is  {{due_amt}}\r\nThank you Visit Again', '{{customer_name}}<br>                          \r\n{{return_id}}<br>\r\n{{return_date}}<br>\r\n{{return_amount}}<br>\r\n{{paid_amt}}<br>\r\n{{due_amt}}<br>\r\n{{company_name}}<br>\r\n{{company_mobile}}<br>\r\n{{company_address}}<br>\r\n{{company_website}}<br>\r\n{{company_email}}<br>', NULL, 1, 1);


#
# TABLE STRUCTURE FOR: db_sobpayments
#

DROP TABLE IF EXISTS `db_sobpayments`;

CREATE TABLE `db_sobpayments` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `supplier_id` int(5) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `payment_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment` double(20,3) DEFAULT NULL,
  `payment_note` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_ip` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_time` time DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: db_states
#

DROP TABLE IF EXISTS `db_states`;

CREATE TABLE `db_states` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `state_code` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(4050) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country_code` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country_id` int(5) DEFAULT NULL,
  `country` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `added_on` date DEFAULT NULL,
  `company_id` int(5) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_states` (`id`, `state_code`, `state`, `country_code`, `country_id`, `country`, `added_on`, `company_id`, `status`) VALUES (54, NULL, 'Kuwait city', NULL, NULL, 'Kuwait', NULL, NULL, 1);


#
# TABLE STRUCTURE FOR: db_stockentry
#

DROP TABLE IF EXISTS `db_stockentry`;

CREATE TABLE `db_stockentry` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `entry_date` date DEFAULT NULL,
  `item_id` int(11) DEFAULT NULL,
  `qty` int(5) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=414 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (63, '2021-09-13', 1, 7, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (64, '2021-09-13', 1, 3, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (65, '2021-09-13', 2, 3, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (73, '2021-09-20', 10, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (77, '2021-09-20', 15, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (78, '2021-09-20', 16, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (79, '2021-09-20', 17, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (80, '2021-09-20', 18, 9, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (82, '2021-09-20', 20, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (83, '2021-09-20', 21, 4, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (84, '2021-09-20', 22, 2, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (87, '2021-09-21', 26, 3, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (88, '2021-09-21', 27, 6, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (89, '2021-09-21', 28, 4, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (90, '2021-09-21', 29, 11, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (91, '2021-09-29', 30, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (92, '2021-10-04', 31, 0, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (97, '2021-10-04', 35, 0, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (102, '2021-10-04', 39, 0, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (111, '2021-10-18', 47, 8, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (112, '2021-10-18', 48, 6, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (113, '2021-10-18', 49, 8, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (114, '2021-10-18', 50, 2, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (116, '2021-10-18', 52, 10, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (117, '2021-10-18', 53, 5, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (118, '2021-10-20', 56, 8, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (119, '2021-10-20', 57, 3, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (120, '2021-10-20', 58, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (121, '2021-10-25', 59, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (122, '2021-10-25', 59, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (123, '2021-10-25', 60, 4, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (124, '2021-10-25', 61, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (125, '2021-10-25', 62, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (126, '2021-10-25', 63, 2, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (128, '2021-10-25', 65, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (129, '2021-10-25', 66, 2, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (130, '2021-10-26', 67, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (131, '2021-10-27', 69, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (132, '2021-10-27', 70, 12, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (133, '2021-10-27', 71, 1220, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (134, '2021-10-27', 72, 1250, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (135, '2021-10-27', 73, 140, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (136, '2021-10-27', 74, 11, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (137, '2021-10-27', 75, 8, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (138, '2021-10-27', 76, 100, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (139, '2021-10-27', 77, 100, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (140, '2021-10-27', 78, 50, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (141, '2021-10-27', 79, 32, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (142, '2021-10-27', 80, 16, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (143, '2021-10-27', 81, 9, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (144, '2021-11-02', 82, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (145, '2021-11-09', 19, 11, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (146, '2021-11-09', 44, 15, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (148, '2021-11-09', 45, 35, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (149, '2021-11-09', 45, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (150, '2021-11-09', 47, 6, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (151, '2021-11-09', 51, 5, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (152, '2021-11-09', 83, 3, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (153, '2021-11-09', 84, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (154, '2021-11-09', 85, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (155, '2021-11-09', 86, 3, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (156, '2021-11-09', 87, 5, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (157, '2021-11-09', 88, 5, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (158, '2021-11-09', 89, 2, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (159, '2021-11-09', 90, 8, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (160, '2021-11-09', 91, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (161, '2021-11-09', 92, 8, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (162, '2021-11-09', 70, -1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (163, '2021-11-09', 73, -100, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (164, '2021-11-09', 75, 49, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (165, '2021-11-09', 93, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (166, '2021-11-09', 94, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (167, '2021-11-09', 95, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (168, '2021-11-09', 96, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (169, '2021-11-09', 97, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (170, '2021-11-11', 51, -1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (171, '2021-11-11', 98, 950, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (172, '2021-11-11', 99, 150, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (173, '2021-11-11', 100, 150, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (174, '2021-11-11', 101, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (175, '2021-11-11', 102, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (176, '2021-11-11', 102, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (177, '2021-11-11', 103, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (178, '2021-11-11', 104, 100, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (179, '2021-11-11', 21, -1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (180, '2021-11-11', 105, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (181, '2021-11-11', 106, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (182, '2021-11-11', 107, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (183, '2021-11-11', 108, 2, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (184, '2021-11-11', 109, 4, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (185, '2021-11-11', 110, 9, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (186, '2021-11-11', 111, 23, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (187, '2021-11-11', 112, 2, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (188, '2021-11-11', 113, 6, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (189, '2021-11-11', 114, 14, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (190, '2021-11-11', 115, 32, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (191, '2021-11-11', 116, 7, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (192, '2021-11-11', 117, 11, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (193, '2021-11-11', 117, 2, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (194, '2021-11-11', 118, 8, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (195, '2021-11-11', 119, 9, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (196, '2021-11-11', 120, 4, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (197, '2021-11-11', 120, 3, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (198, '2021-11-15', 71, -15, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (199, '2021-11-15', 121, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (200, '2021-11-15', 122, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (201, '2021-11-15', 123, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (202, '2021-11-15', 124, 4, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (203, '2021-11-15', 125, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (204, '2021-11-15', 126, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (205, '2021-11-15', 127, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (206, '2021-11-15', 128, 3, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (207, '2021-11-15', 129, 2, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (208, '2021-11-15', 130, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (209, '2021-11-15', 131, 5, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (210, '2021-11-15', 132, 2, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (211, '2021-11-15', 133, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (212, '2021-11-15', 134, 10, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (213, '2021-11-15', 135, 10, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (214, '2021-11-15', 136, 3, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (215, '2021-11-15', 137, 4, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (216, '2021-11-15', 29, -10, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (217, '2021-11-15', 76, 81, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (218, '2021-11-15', 77, 180, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (219, '2021-11-15', 78, 50, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (220, '2021-11-16', 143, 4, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (221, '2021-11-16', 144, 2, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (222, '2021-11-16', 145, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (223, '2021-11-16', 146, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (224, '2021-11-16', 147, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (225, '2021-11-16', 148, 2, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (226, '2021-11-16', 149, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (227, '2021-11-16', 150, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (228, '2021-11-16', 151, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (229, '2021-11-16', 152, 2, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (230, '2021-11-16', 153, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (231, '2021-11-16', 154, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (232, '2021-11-16', 155, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (233, '2021-11-16', 156, 3, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (234, '2021-11-16', 157, 7, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (235, '2021-11-16', 158, 10, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (236, '2021-11-16', 159, 5, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (237, '2021-11-16', 160, 2, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (238, '2021-11-16', 161, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (239, '2021-11-16', 162, 2, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (240, '2021-11-17', 73, 3, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (241, '2021-11-17', 163, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (242, '2021-11-17', 164, 2, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (243, '2021-11-17', 165, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (244, '2021-11-17', 166, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (245, '2021-11-17', 167, 5, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (246, '2021-11-17', 168, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (247, '2021-11-17', 169, 5, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (248, '2021-11-17', 170, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (249, '2021-11-17', 171, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (250, '2021-11-17', 172, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (251, '2021-11-17', 173, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (252, '2021-11-17', 174, 3, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (253, '2021-11-17', 175, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (254, '2021-11-17', 176, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (255, '2021-11-17', 83, -2, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (256, '2021-11-18', 177, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (257, '2021-11-18', 178, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (258, '2021-11-18', 179, 11, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (259, '2021-11-18', 180, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (260, '2021-11-18', 182, 3, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (261, '2021-11-18', 183, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (262, '2021-11-18', 184, 25, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (263, '2021-11-18', 185, 3, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (264, '2021-11-18', 186, 6, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (265, '2021-11-18', 57, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (266, '2021-11-18', 187, 64, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (267, '2021-11-21', 66, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (268, '2021-11-21', 70, 23, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (269, '2021-11-21', 70, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (270, '2021-11-21', 156, 7, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (271, '2021-11-21', 193, 3, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (272, '2021-11-21', 156, -3, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (273, '2021-11-21', 194, 35, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (274, '2021-11-21', 198, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (275, '2021-11-21', 156, 2, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (276, '2021-11-21', 101, 29, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (277, '2021-11-21', 199, 3, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (278, '2021-11-22', 157, -5, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (280, '2021-11-22', 70, -1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (281, '2021-11-22', 63, -2, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (282, '2021-11-22', 128, -1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (283, '2021-11-22', 169, -1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (284, '2021-11-22', 57, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (285, '2021-11-22', 57, -1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (286, '2021-11-22', 200, 10, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (287, '2021-11-22', 201, 4, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (288, '2021-11-22', 202, 5, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (289, '2021-11-25', 169, -3, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (290, '2021-11-25', 190, -4, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (291, '2021-11-25', 83, -1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (292, '2021-11-25', 70, -1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (293, '2021-11-25', 62, -1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (294, '2021-11-25', 203, 3, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (295, '2021-11-25', 91, -1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (296, '2021-11-25', 92, -1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (297, '2021-11-27', 205, -1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (298, '2021-11-27', 204, -1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (299, '2021-11-28', 207, 72, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (300, '2021-11-28', 208, 17, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (301, '2021-11-28', 209, 14, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (302, '2021-11-28', 210, 14, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (303, '2021-11-28', 26, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (304, '2021-11-29', 211, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (305, '2021-11-30', 212, 7, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (306, '2021-11-30', 214, 20, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (307, '2021-11-30', 215, 2, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (308, '2021-11-30', 216, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (309, '2021-11-30', 217, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (310, '2021-11-30', 88, -1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (311, '2021-12-04', 219, -4, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (312, '2021-12-04', 218, -38, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (313, '2021-12-05', 212, -1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (314, '2021-12-05', 220, 4, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (315, '2021-12-07', 221, 63, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (316, '2021-12-07', 222, 71, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (317, '2021-12-07', 223, 4, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (318, '2021-12-07', 224, 4, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (319, '2021-12-07', 225, 2, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (320, '2021-12-07', 226, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (321, '2021-12-07', 227, 4, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (322, '2021-12-07', 228, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (323, '2021-12-07', 229, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (324, '2021-12-07', 230, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (326, '2021-12-07', 232, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (327, '2021-12-07', 233, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (328, '2021-12-07', 234, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (329, '2021-12-07', 235, 23, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (330, '2021-12-07', 236, 3, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (331, '2021-12-07', 237, 4, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (332, '2021-12-07', 237, -2, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (333, '2021-12-07', 238, 4, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (334, '2021-12-07', 239, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (335, '2021-12-07', 240, 19, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (336, '2021-12-07', 241, 13, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (337, '2021-12-07', 242, 3, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (338, '2021-12-07', 243, 3, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (339, '2021-12-07', 244, 2, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (340, '2021-12-07', 245, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (341, '2021-12-07', 246, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (342, '2021-12-07', 247, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (343, '2021-12-07', 248, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (344, '2021-12-07', 249, 2, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (345, '2021-12-07', 250, 7, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (346, '2021-12-07', 251, 2, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (347, '2021-12-07', 252, 4, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (348, '2021-12-07', 250, 2, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (349, '2021-12-07', 250, 2, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (350, '2021-12-07', 253, 2, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (351, '2021-12-07', 254, 2, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (352, '2021-12-07', 255, 2, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (353, '2021-12-07', 250, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (354, '2021-12-07', 256, 5, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (355, '2021-12-07', 257, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (356, '2021-12-07', 258, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (357, '2021-12-07', 255, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (358, '2021-12-07', 253, 3, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (359, '2021-12-07', 253, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (360, '2021-12-07', 259, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (361, '2021-12-07', 144, -2, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (362, '2021-12-07', 260, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (363, '2021-12-07', 261, 2, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (364, '2021-12-07', 262, 4, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (365, '2021-12-07', 250, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (366, '2021-12-08', 265, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (367, '2021-12-09', 268, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (368, '2021-12-11', 269, 40, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (369, '2021-12-11', 218, 5, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (370, '2021-12-11', 50, -1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (371, '2021-12-11', 51, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (372, '2021-12-11', 69, 4, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (373, '2021-12-12', 273, -20, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (374, '2021-12-14', 215, 2, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (375, '2021-12-14', 215, -2, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (376, '2021-12-14', 216, -1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (377, '2021-12-14', 216, 4, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (378, '2021-12-14', 274, 2, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (379, '2021-12-14', 275, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (380, '2021-12-14', 276, 5, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (381, '2021-12-15', 147, 2, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (382, '2021-12-15', 1, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (383, '2021-12-16', 277, 500, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (384, '2021-12-20', 284, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (385, '2021-12-20', 285, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (386, '2021-12-21', 284, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (387, '2021-12-21', 288, 6, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (388, '2021-12-21', 287, 4, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (389, '2021-12-22', 29, -10, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (390, '2021-12-22', 29, 4, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (391, '2021-12-22', 291, 2, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (392, '2021-12-25', 272, -25, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (393, '2021-12-27', 292, 12, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (394, '2021-12-27', 293, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (395, '2021-12-29', 196, -1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (396, '2021-12-30', 294, 2, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (397, '2021-12-30', 295, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (398, '2021-12-30', 296, 6, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (399, '2021-12-30', 297, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (400, '2021-12-30', 298, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (401, '2021-12-30', 299, 1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (402, '2021-12-30', 300, 7, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (403, '2021-12-30', 301, 2, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (404, '2021-12-30', 302, 4, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (405, '2021-12-30', 303, 3, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (406, '2021-12-30', 304, 22, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (407, '2021-12-30', 305, 34, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (408, '2021-12-30', 306, 94, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (409, '2022-01-10', 308, 9, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (410, '2022-01-10', 309, 11, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (411, '2022-01-10', 29, -1, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (412, '2022-01-10', 196, -2, 1);
INSERT INTO `db_stockentry` (`id`, `entry_date`, `item_id`, `qty`, `status`) VALUES (413, '2022-01-10', 147, 3, 1);


#
# TABLE STRUCTURE FOR: db_supplier_payments
#

DROP TABLE IF EXISTS `db_supplier_payments`;

CREATE TABLE `db_supplier_payments` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `purchasepayment_id` int(5) DEFAULT NULL,
  `supplier_id` int(5) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `payment_type` varchar(50) DEFAULT NULL,
  `payment` double(20,3) DEFAULT NULL,
  `payment_note` text DEFAULT NULL,
  `system_ip` varchar(50) DEFAULT NULL,
  `system_name` varchar(50) DEFAULT NULL,
  `created_time` varchar(50) DEFAULT NULL,
  `created_date` varchar(50) DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `purchasepayment_id` (`purchasepayment_id`),
  CONSTRAINT `db_supplier_payments_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `db_suppliers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `db_supplier_payments_ibfk_2` FOREIGN KEY (`purchasepayment_id`) REFERENCES `db_purchasepayments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=341 DEFAULT CHARSET=utf8mb4;

INSERT INTO `db_supplier_payments` (`id`, `purchasepayment_id`, `supplier_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (309, 15, 14, '2021-11-27', 'Cash', '12.000', '', '37.34.206.9', '37.34.206.9', '08:29:40', '2021-11-27', 'admin', 1);
INSERT INTO `db_supplier_payments` (`id`, `purchasepayment_id`, `supplier_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (327, 20, 36, '2021-12-12', 'Online', '557.000', '', '37.34.206.9', '37.34.206.9', '03:01:17', '2021-12-12', 'admin', 1);
INSERT INTO `db_supplier_payments` (`id`, `purchasepayment_id`, `supplier_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (328, 21, 36, '2021-12-18', 'Online', '847.500', '', '37.34.206.9', '37.34.206.9', '02:57:14', '2021-12-18', 'admin', 1);
INSERT INTO `db_supplier_payments` (`id`, `purchasepayment_id`, `supplier_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (329, 22, 36, '2021-12-21', 'Online', '341.400', '', '37.34.206.9', '37.34.206.9', '03:13:54', '2021-12-21', 'admin', 1);
INSERT INTO `db_supplier_payments` (`id`, `purchasepayment_id`, `supplier_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (334, 16, 31, '2021-11-21', 'Online', '23.000', '', '37.34.206.9', '37.34.206.9', '08:34:36', '2021-11-27', 'admin', 1);
INSERT INTO `db_supplier_payments` (`id`, `purchasepayment_id`, `supplier_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (335, 17, 31, '2021-11-21', 'Online', '15.000', '', '37.34.206.9', '37.34.206.9', '08:35:51', '2021-11-27', 'admin', 1);
INSERT INTO `db_supplier_payments` (`id`, `purchasepayment_id`, `supplier_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (336, 18, 31, '2021-11-21', 'Online', '915.000', '', '37.34.206.9', '37.34.206.9', '08:36:33', '2021-11-27', 'admin', 1);
INSERT INTO `db_supplier_payments` (`id`, `purchasepayment_id`, `supplier_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (337, 23, 31, '2021-12-22', 'Online', '1035.000', '', '37.34.206.9', '37.34.206.9', '12:58:09', '2021-12-22', 'admin', 1);
INSERT INTO `db_supplier_payments` (`id`, `purchasepayment_id`, `supplier_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (338, 24, 31, '2021-12-27', 'Online', '446.000', '', '37.34.206.9', '37.34.206.9', '09:17:13', '2021-12-27', 'admin', 1);
INSERT INTO `db_supplier_payments` (`id`, `purchasepayment_id`, `supplier_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (339, 19, 9, '2021-12-09', 'Cheque', '330.000', '', '37.34.206.9', '37.34.206.9', '01:05:32', '2021-12-09', 'admin', 1);
INSERT INTO `db_supplier_payments` (`id`, `purchasepayment_id`, `supplier_id`, `payment_date`, `payment_type`, `payment`, `payment_note`, `system_ip`, `system_name`, `created_time`, `created_date`, `created_by`, `status`) VALUES (340, 25, 9, '2021-12-26', 'Cheque', '185.000', '', '37.34.206.9', '37.34.206.9', '10:21:58', '2022-01-05', 'admin', 1);


#
# TABLE STRUCTURE FOR: db_suppliers
#

DROP TABLE IF EXISTS `db_suppliers`;

CREATE TABLE `db_suppliers` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `supplier_code` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `supplier_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gstin` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax_number` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vatin` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `opening_balance` double(20,3) DEFAULT NULL,
  `purchase_due` double(20,3) DEFAULT NULL,
  `purchase_return_due` double(20,3) DEFAULT NULL,
  `country_id` int(5) DEFAULT NULL,
  `state_id` int(5) DEFAULT NULL,
  `city` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postcode` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_ip` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_time` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_id` int(5) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_suppliers` (`id`, `supplier_code`, `supplier_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `purchase_due`, `purchase_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (1, 'SP0001', 'Compu Kuwait', '66175229', '22622226', 'q8@pioneerscomputer.com', '', '', NULL, '0.000', '0.000', '0.000', 3, NULL, 'Hawally', '', '', '31.214.81.188', '31.214.81.188', '2021-04-01', '11:28:22 am', 'manager', NULL, 1);
INSERT INTO `db_suppliers` (`id`, `supplier_code`, `supplier_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `purchase_due`, `purchase_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (2, 'SP0002', 'Burhan Technology  Computer   Co', '94760724', '22498922', 'info@burhantec.com', '', '', NULL, '0.000', '150.000', NULL, 3, NULL, '', '', '', '31.214.81.188', '31.214.81.188', '2021-04-01', '11:36:53 am', 'manager', NULL, 1);
INSERT INTO `db_suppliers` (`id`, `supplier_code`, `supplier_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `purchase_due`, `purchase_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (3, 'SP0003', 'Sun Moon Trading Co.', '55220990', '22668794', 'sales@sunmoontrading.com', '', '', NULL, '0.000', '132.500', NULL, 3, NULL, '', '', '', '31.214.81.188', '31.214.81.188', '2021-04-01', '11:40:31 am', 'manager', NULL, 1);
INSERT INTO `db_suppliers` (`id`, `supplier_code`, `supplier_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `purchase_due`, `purchase_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (4, 'SP0004', 'Dubai International Computers', '', '22636573', 'dubailnt@gmail.com', '', '', NULL, '0.000', '85.250', '0.000', 3, NULL, '', '', '', '31.214.81.188', '31.214.81.188', '2021-04-01', '11:46:18 am', 'manager', NULL, 1);
INSERT INTO `db_suppliers` (`id`, `supplier_code`, `supplier_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `purchase_due`, `purchase_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (5, 'SP0005', 'Anwar Al - Mohammediya Computers', '', '22650782', 'juzer@anwarmohd.com', '', '', NULL, '0.000', '0.000', NULL, 3, NULL, '', '', '', '31.214.81.188', '31.214.81.188', '2021-04-01', '11:48:00 am', 'manager', NULL, 1);
INSERT INTO `db_suppliers` (`id`, `supplier_code`, `supplier_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `purchase_due`, `purchase_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (6, 'SP0006', 'Key Tech', '60016135', '22616788', 'keytechnetwork@gmail.com', '', '', NULL, '0.000', NULL, NULL, 3, NULL, '', '', '', '31.214.81.188', '31.214.81.188', '2021-04-01', '11:49:16 am', 'manager', NULL, 1);
INSERT INTO `db_suppliers` (`id`, `supplier_code`, `supplier_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `purchase_due`, `purchase_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (7, 'SP0007', 'You Tech Computer Solution', '60038880', '22659961', 'yourtechkw@yahoo.com', '', '', NULL, '0.000', NULL, NULL, 3, NULL, '', '', '', '31.214.81.188', '31.214.81.188', '2021-04-01', '11:50:45 am', 'manager', NULL, 1);
INSERT INTO `db_suppliers` (`id`, `supplier_code`, `supplier_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `purchase_due`, `purchase_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (8, 'SP0008', 'Alf Solutions and Services', '', '22050651', 'sales@alfsolutions.net', '', '', NULL, '0.000', NULL, NULL, 3, NULL, '', '', '', '31.214.81.188', '31.214.81.188', '2021-04-01', '11:51:52 am', 'manager', NULL, 1);
INSERT INTO `db_suppliers` (`id`, `supplier_code`, `supplier_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `purchase_due`, `purchase_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (9, 'SP0009', 'First Trading &amp; Contracting Group', '', '22425595', 'mail@ftgkuwait.com', '', '', NULL, '0.000', '0.000', NULL, 3, NULL, '', '', '', '31.214.81.188', '31.214.81.188', '2021-04-01', '11:53:42 am', 'manager', NULL, 1);
INSERT INTO `db_suppliers` (`id`, `supplier_code`, `supplier_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `purchase_due`, `purchase_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (10, 'SP0010', 'Al Bareeq International for Computers Est', '50537722', '22625838', 'sales@nexgentechno.com', '', '', NULL, '0.000', '0.000', NULL, 3, NULL, '', '', '', '31.214.81.188', '31.214.81.188', '2021-04-01', '11:55:01 am', 'manager', NULL, 1);
INSERT INTO `db_suppliers` (`id`, `supplier_code`, `supplier_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `purchase_due`, `purchase_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (11, 'SP0011', 'Icon For Computer Co.', '', '22613437', 'Emad@q8icon.com', '', '', NULL, '0.000', NULL, NULL, 3, NULL, '', '', '', '31.214.81.188', '31.214.81.188', '2021-04-01', '11:56:25 am', 'manager', NULL, 1);
INSERT INTO `db_suppliers` (`id`, `supplier_code`, `supplier_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `purchase_due`, `purchase_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (12, 'SP0012', 'United Falcon W.L.L Electrical Cont.co', '', '24751206', 'ufec.kuwait@gmail.com', '', '', NULL, '0.000', NULL, NULL, 3, NULL, '', '', '', '31.214.81.188', '31.214.81.188', '2021-04-01', '11:57:54 am', 'manager', NULL, 1);
INSERT INTO `db_suppliers` (`id`, `supplier_code`, `supplier_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `purchase_due`, `purchase_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (13, 'SP0013', 'Smar Tek Computer Est', '', '22667457', 'rajvir@stckwt.com', '', '', NULL, '0.000', '368.000', NULL, 3, NULL, '', '', '', '31.214.81.188', '31.214.81.188', '2021-04-01', '11:59:26 am', 'manager', NULL, 1);
INSERT INTO `db_suppliers` (`id`, `supplier_code`, `supplier_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `purchase_due`, `purchase_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (14, 'SP0014', 'Star Light Supplies', '', '22639615', 'info@starlight-kw.com', '', '', NULL, '0.000', '0.000', NULL, 3, NULL, '', '', '', '31.214.81.188', '31.214.81.188', '2021-04-01', '12:01:54 pm', 'manager', NULL, 1);
INSERT INTO `db_suppliers` (`id`, `supplier_code`, `supplier_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `purchase_due`, `purchase_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (15, 'SP0015', 'Ideal Information', '', '22432132', 'info@ideal-sys.com', '', '', NULL, '0.000', NULL, NULL, 3, NULL, '', '', '', '31.214.81.188', '31.214.81.188', '2021-04-01', '12:02:54 pm', 'manager', NULL, 1);
INSERT INTO `db_suppliers` (`id`, `supplier_code`, `supplier_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `purchase_due`, `purchase_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (16, 'SP0016', 'Janah Electrical', '', '', '', '', '', NULL, '0.000', '0.000', NULL, 3, NULL, '', '', '', '37.34.206.9', '37.34.206.9', '2021-06-19', '08:33:21 pm', 'admin', NULL, 1);
INSERT INTO `db_suppliers` (`id`, `supplier_code`, `supplier_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `purchase_due`, `purchase_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (17, 'SP0017', 'Al-Faltah Gen Trading  and Contracting', '', '226640722264820', '', '', '', NULL, '0.000', '0.000', NULL, 3, 54, '', '', 'Al-Zaina Complex  No 2   Shop no 10 \r\nBin Khaldoon St', '37.34.206.9', '37.34.206.9', '2021-06-27', '07:20:49 pm', 'admin', NULL, 1);
INSERT INTO `db_suppliers` (`id`, `supplier_code`, `supplier_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `purchase_due`, `purchase_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (18, 'SP0018', 'al-Faid  International  For Computer', '', '22647227', 'alfaidcomp@hotmail.com', '', '', NULL, '0.000', '0.000', NULL, 3, 54, '', '', '', '37.34.206.9', '37.34.206.9', '2021-07-01', '04:15:08 pm', 'admin', NULL, 1);
INSERT INTO `db_suppliers` (`id`, `supplier_code`, `supplier_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `purchase_due`, `purchase_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (19, 'SP0019', 'PC MATE   Computer . ', '22651622', '', 'info@pcmatekwt.com', '', '', NULL, '0.000', NULL, NULL, 3, 54, '', '', '', '37.34.206.9', '37.34.206.9', '2021-07-01', '04:54:01 pm', 'admin', NULL, 1);
INSERT INTO `db_suppliers` (`id`, `supplier_code`, `supplier_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `purchase_due`, `purchase_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (20, 'SP0020', 'Printech  Gen. Trading', '66398090', '22413471', '', '', '', NULL, '0.000', '0.000', NULL, 3, NULL, '', '', '', '37.34.206.9', '37.34.206.9', '2021-07-07', '05:14:19 pm', 'admin', NULL, 1);
INSERT INTO `db_suppliers` (`id`, `supplier_code`, `supplier_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `purchase_due`, `purchase_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (21, 'SP0021', 'Oscar  International  Group Co Ltd', '', '', '', '', '', NULL, '0.000', '0.000', NULL, 3, NULL, '', '', '', '37.34.206.9', '37.34.206.9', '2021-07-26', '07:25:30 pm', 'admin', NULL, 1);
INSERT INTO `db_suppliers` (`id`, `supplier_code`, `supplier_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `purchase_due`, `purchase_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (22, 'SP0022', 'Auto Teco  Co Ltd', '', '', '', '', '', NULL, '0.000', '0.000', NULL, 3, NULL, '', '', 'China', '37.34.206.9', '37.34.206.9', '2021-07-26', '07:29:16 pm', 'admin', NULL, 1);
INSERT INTO `db_suppliers` (`id`, `supplier_code`, `supplier_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `purchase_due`, `purchase_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (23, 'SP0023', 'Nama  ', '', '', '', '', '', NULL, '0.000', '0.000', NULL, 3, NULL, '', '', '', '37.34.206.9', '37.34.206.9', '2021-07-27', '04:15:49 pm', 'admin', NULL, 1);
INSERT INTO `db_suppliers` (`id`, `supplier_code`, `supplier_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `purchase_due`, `purchase_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (24, 'SP0024', 'Limra Computer', '', '', '', '', '', NULL, '0.000', '0.000', NULL, 3, NULL, '', '', '', '37.34.206.9', '37.34.206.9', '2021-07-28', '04:28:30 pm', 'admin', NULL, 1);
INSERT INTO `db_suppliers` (`id`, `supplier_code`, `supplier_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `purchase_due`, `purchase_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (25, 'SP0025', 'Mr. Kutbuddin  ', '99902260', '', '', '', '', NULL, '0.000', '0.000', NULL, 3, NULL, '', '', '', '37.34.206.9', '37.34.206.9', '2021-07-28', '06:19:55 pm', 'admin', NULL, 1);
INSERT INTO `db_suppliers` (`id`, `supplier_code`, `supplier_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `purchase_due`, `purchase_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (26, 'SP0026', 'Al Nahar ', '66198026', '24735000', '', '', '', NULL, '0.000', '0.000', NULL, 3, NULL, '', '', '', '37.34.206.9', '37.34.206.9', '2021-07-28', '06:29:42 pm', 'admin', NULL, 1);
INSERT INTO `db_suppliers` (`id`, `supplier_code`, `supplier_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `purchase_due`, `purchase_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (27, 'SP0027', 'Babji Al-Saif', '', '', '', '', '', NULL, '0.000', '0.000', NULL, 3, NULL, '', '', '', '37.34.206.9', '37.34.206.9', '2021-08-07', '11:58:46 am', 'admin', NULL, 1);
INSERT INTO `db_suppliers` (`id`, `supplier_code`, `supplier_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `purchase_due`, `purchase_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (28, 'SP0028', '7  Star ', '', '', '', '', '', NULL, '0.000', '0.000', NULL, 3, NULL, '', '', '', '37.34.206.9', '37.34.206.9', '2021-08-07', '04:49:37 pm', 'admin', NULL, 1);
INSERT INTO `db_suppliers` (`id`, `supplier_code`, `supplier_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `purchase_due`, `purchase_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (29, 'SP0029', 'CHANGZHOU  SEARCH E-COMMERCE  CO.LTD .', '', '', '', '', '', NULL, '0.000', '0.000', NULL, 3, NULL, '', '', '', '37.34.206.9', '37.34.206.9', '2021-08-15', '03:30:12 pm', 'admin', NULL, 1);
INSERT INTO `db_suppliers` (`id`, `supplier_code`, `supplier_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `purchase_due`, `purchase_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (30, 'SP0030', 'Micro-Tech   Computer .', '', '2647776', '', '', '', NULL, '0.000', '0.000', NULL, 3, NULL, 'Hawally', '', 'Shoaa -Basement  -Shop No-2', '37.34.206.9', '37.34.206.9', '2021-11-20', '05:33:27 pm', 'admin', NULL, 1);
INSERT INTO `db_suppliers` (`id`, `supplier_code`, `supplier_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `purchase_due`, `purchase_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (31, 'SP0031', 'Granding  Technology    Co. ', '', '', '', '', '', NULL, '0.000', '0.000', NULL, 3, NULL, '', '', '', '37.34.206.9', '37.34.206.9', '2021-11-21', '12:23:09 pm', 'admin', NULL, 1);
INSERT INTO `db_suppliers` (`id`, `supplier_code`, `supplier_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `purchase_due`, `purchase_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (32, 'SP0032', 'Star Light  Supplies ', '', '', '', '', '', NULL, '0.000', NULL, NULL, 3, NULL, '', '', '', '37.34.206.9', '37.34.206.9', '2021-11-27', '08:26:16 pm', 'admin', NULL, 1);
INSERT INTO `db_suppliers` (`id`, `supplier_code`, `supplier_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `purchase_due`, `purchase_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (33, 'SP0033', 'Salem M.AL-Nisf  General Building Contracting   Co', '1822233', '24845660', 'snec-sales@alnisfgroup.com.kw', '', '', NULL, '0.000', '115.000', NULL, 3, NULL, '', '', 'Shuwaikh     store -24922752', '37.34.206.9', '37.34.206.9', '2021-11-27', '08:43:51 pm', 'admin', NULL, 1);
INSERT INTO `db_suppliers` (`id`, `supplier_code`, `supplier_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `purchase_due`, `purchase_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (34, 'SP0034', 'KND', '22619524', '', '', '', '', NULL, '0.000', '13.334', NULL, 3, NULL, '', '', '', '37.34.206.9', '37.34.206.9', '2021-12-04', '01:07:54 pm', 'admin', NULL, 1);
INSERT INTO `db_suppliers` (`id`, `supplier_code`, `supplier_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `purchase_due`, `purchase_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (35, 'SP0035', 'Sky  Link   Salmiya', '', '', '', '', '', NULL, '0.000', NULL, NULL, 3, NULL, '', '', '', '37.34.206.9', '37.34.206.9', '2021-12-09', '01:22:51 pm', 'admin', NULL, 1);
INSERT INTO `db_suppliers` (`id`, `supplier_code`, `supplier_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `purchase_due`, `purchase_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`) VALUES (36, 'SP0036', 'Ximi  Technilogy', '', '', '', '', '', NULL, '0.000', '672.000', NULL, 3, NULL, '', '', '', '37.34.206.9', '37.34.206.9', '2021-12-12', '02:58:47 pm', 'admin', NULL, 1);


#
# TABLE STRUCTURE FOR: db_tax
#

DROP TABLE IF EXISTS `db_tax`;

CREATE TABLE `db_tax` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `tax_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax` double(20,3) DEFAULT NULL,
  `group_bit` int(1) DEFAULT NULL COMMENT '1=Yes, 0=No',
  `subtax_ids` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Tax groups IDs',
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_tax` (`id`, `tax_name`, `tax`, `group_bit`, `subtax_ids`, `status`) VALUES (1, 'No tax', '0.000', NULL, NULL, 1);
INSERT INTO `db_tax` (`id`, `tax_name`, `tax`, `group_bit`, `subtax_ids`, `status`) VALUES (2, '8', '7.000', NULL, NULL, 1);


#
# TABLE STRUCTURE FOR: db_timezone
#

DROP TABLE IF EXISTS `db_timezone`;

CREATE TABLE `db_timezone` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `timezone` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=549 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (1, 'Africa/Abidjan\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (2, 'Africa/Accra\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (3, 'Africa/Addis_Ababa\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (4, 'Africa/Algiers\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (5, 'Africa/Asmara\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (6, 'Africa/Asmera\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (7, 'Africa/Bamako\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (8, 'Africa/Bangui\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (9, 'Africa/Banjul\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (10, 'Africa/Bissau\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (11, 'Africa/Blantyre\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (12, 'Africa/Brazzaville\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (13, 'Africa/Bujumbura\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (14, 'Africa/Cairo\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (15, 'Africa/Casablanca\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (16, 'Africa/Ceuta\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (17, 'Africa/Conakry\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (18, 'Africa/Dakar\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (19, 'Africa/Dar_es_Salaam\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (20, 'Africa/Djibouti\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (21, 'Africa/Douala\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (22, 'Africa/El_Aaiun\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (23, 'Africa/Freetown\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (24, 'Africa/Gaborone\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (25, 'Africa/Harare\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (26, 'Africa/Johannesburg\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (27, 'Africa/Juba\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (28, 'Africa/Kampala\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (29, 'Africa/Khartoum\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (30, 'Africa/Kigali\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (31, 'Africa/Kinshasa\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (32, 'Africa/Lagos\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (33, 'Africa/Libreville\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (34, 'Africa/Lome\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (35, 'Africa/Luanda\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (36, 'Africa/Lubumbashi\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (37, 'Africa/Lusaka\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (38, 'Africa/Malabo\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (39, 'Africa/Maputo\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (40, 'Africa/Maseru\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (41, 'Africa/Mbabane\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (42, 'Africa/Mogadishu\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (43, 'Africa/Monrovia\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (44, 'Africa/Nairobi\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (45, 'Africa/Ndjamena\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (46, 'Africa/Niamey\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (47, 'Africa/Nouakchott\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (48, 'Africa/Ouagadougou\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (49, 'Africa/Porto-Novo\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (50, 'Africa/Sao_Tome\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (51, 'Africa/Timbuktu\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (52, 'Africa/Tripoli\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (53, 'Africa/Tunis\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (54, 'Africa/Windhoek\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (55, 'AKST9AKDT\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (56, 'America/Adak\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (57, 'America/Anchorage\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (58, 'America/Anguilla\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (59, 'America/Antigua\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (60, 'America/Araguaina\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (61, 'America/Argentina/Buenos_Aires\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (62, 'America/Argentina/Catamarca\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (63, 'America/Argentina/ComodRivadavia\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (64, 'America/Argentina/Cordoba\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (65, 'America/Argentina/Jujuy\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (66, 'America/Argentina/La_Rioja\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (67, 'America/Argentina/Mendoza\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (68, 'America/Argentina/Rio_Gallegos\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (69, 'America/Argentina/Salta\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (70, 'America/Argentina/San_Juan\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (71, 'America/Argentina/San_Luis\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (72, 'America/Argentina/Tucuman\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (73, 'America/Argentina/Ushuaia\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (74, 'America/Aruba\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (75, 'America/Asuncion\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (76, 'America/Atikokan\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (77, 'America/Atka\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (78, 'America/Bahia\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (79, 'America/Bahia_Banderas\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (80, 'America/Barbados\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (81, 'America/Belem\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (82, 'America/Belize\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (83, 'America/Blanc-Sablon\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (84, 'America/Boa_Vista\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (85, 'America/Bogota\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (86, 'America/Boise\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (87, 'America/Buenos_Aires\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (88, 'America/Cambridge_Bay\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (89, 'America/Campo_Grande\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (90, 'America/Cancun\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (91, 'America/Caracas\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (92, 'America/Catamarca\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (93, 'America/Cayenne\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (94, 'America/Cayman\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (95, 'America/Chicago\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (96, 'America/Chihuahua\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (97, 'America/Coral_Harbour\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (98, 'America/Cordoba\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (99, 'America/Costa_Rica\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (100, 'America/Creston\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (101, 'America/Cuiaba\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (102, 'America/Curacao\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (103, 'America/Danmarkshavn\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (104, 'America/Dawson\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (105, 'America/Dawson_Creek\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (106, 'America/Denver\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (107, 'America/Detroit\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (108, 'America/Dominica\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (109, 'America/Edmonton\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (110, 'America/Eirunepe\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (111, 'America/El_Salvador\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (112, 'America/Ensenada\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (113, 'America/Fort_Wayne\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (114, 'America/Fortaleza\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (115, 'America/Glace_Bay\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (116, 'America/Godthab\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (117, 'America/Goose_Bay\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (118, 'America/Grand_Turk\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (119, 'America/Grenada\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (120, 'America/Guadeloupe\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (121, 'America/Guatemala\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (122, 'America/Guayaquil\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (123, 'America/Guyana\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (124, 'America/Halifax\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (125, 'America/Havana\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (126, 'America/Hermosillo\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (127, 'America/Indiana/Indianapolis\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (128, 'America/Indiana/Knox\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (129, 'America/Indiana/Marengo\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (130, 'America/Indiana/Petersburg\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (131, 'America/Indiana/Tell_City\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (132, 'America/Indiana/Vevay\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (133, 'America/Indiana/Vincennes\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (134, 'America/Indiana/Winamac\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (135, 'America/Indianapolis\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (136, 'America/Inuvik\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (137, 'America/Iqaluit\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (138, 'America/Jamaica\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (139, 'America/Jujuy\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (140, 'America/Juneau\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (141, 'America/Kentucky/Louisville\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (142, 'America/Kentucky/Monticello\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (143, 'America/Knox_IN\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (144, 'America/Kralendijk\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (145, 'America/La_Paz\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (146, 'America/Lima\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (147, 'America/Los_Angeles\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (148, 'America/Louisville\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (149, 'America/Lower_Princes\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (150, 'America/Maceio\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (151, 'America/Managua\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (152, 'America/Manaus\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (153, 'America/Marigot\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (154, 'America/Martinique\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (155, 'America/Matamoros\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (156, 'America/Mazatlan\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (157, 'America/Mendoza\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (158, 'America/Menominee\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (159, 'America/Merida\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (160, 'America/Metlakatla\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (161, 'America/Mexico_City\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (162, 'America/Miquelon\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (163, 'America/Moncton\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (164, 'America/Monterrey\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (165, 'America/Montevideo\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (166, 'America/Montreal\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (167, 'America/Montserrat\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (168, 'America/Nassau\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (169, 'America/New_York\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (170, 'America/Nipigon\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (171, 'America/Nome\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (172, 'America/Noronha\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (173, 'America/North_Dakota/Beulah\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (174, 'America/North_Dakota/Center\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (175, 'America/North_Dakota/New_Salem\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (176, 'America/Ojinaga\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (177, 'America/Panama\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (178, 'America/Pangnirtung\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (179, 'America/Paramaribo\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (180, 'America/Phoenix\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (181, 'America/Port_of_Spain\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (182, 'America/Port-au-Prince\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (183, 'America/Porto_Acre\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (184, 'America/Porto_Velho\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (185, 'America/Puerto_Rico\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (186, 'America/Rainy_River\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (187, 'America/Rankin_Inlet\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (188, 'America/Recife\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (189, 'America/Regina\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (190, 'America/Resolute\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (191, 'America/Rio_Branco\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (192, 'America/Rosario\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (193, 'America/Santa_Isabel\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (194, 'America/Santarem\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (195, 'America/Santiago\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (196, 'America/Santo_Domingo\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (197, 'America/Sao_Paulo\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (198, 'America/Scoresbysund\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (199, 'America/Shiprock\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (200, 'America/Sitka\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (201, 'America/St_Barthelemy\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (202, 'America/St_Johns\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (203, 'America/St_Kitts\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (204, 'America/St_Lucia\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (205, 'America/St_Thomas\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (206, 'America/St_Vincent\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (207, 'America/Swift_Current\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (208, 'America/Tegucigalpa\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (209, 'America/Thule\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (210, 'America/Thunder_Bay\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (211, 'America/Tijuana\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (212, 'America/Toronto\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (213, 'America/Tortola\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (214, 'America/Vancouver\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (215, 'America/Virgin\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (216, 'America/Whitehorse\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (217, 'America/Winnipeg\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (218, 'America/Yakutat\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (219, 'America/Yellowknife\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (220, 'Antarctica/Casey\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (221, 'Antarctica/Davis\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (222, 'Antarctica/DumontDUrville\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (223, 'Antarctica/Macquarie\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (224, 'Antarctica/Mawson\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (225, 'Antarctica/McMurdo\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (226, 'Antarctica/Palmer\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (227, 'Antarctica/Rothera\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (228, 'Antarctica/South_Pole\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (229, 'Antarctica/Syowa\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (230, 'Antarctica/Vostok\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (231, 'Arctic/Longyearbyen\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (232, 'Asia/Aden\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (233, 'Asia/Almaty\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (234, 'Asia/Amman\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (235, 'Asia/Anadyr\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (236, 'Asia/Aqtau\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (237, 'Asia/Aqtobe\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (238, 'Asia/Ashgabat\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (239, 'Asia/Ashkhabad\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (240, 'Asia/Baghdad\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (241, 'Asia/Bahrain\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (242, 'Asia/Baku\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (243, 'Asia/Bangkok\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (244, 'Asia/Beirut\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (245, 'Asia/Bishkek\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (246, 'Asia/Brunei\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (247, 'Asia/Calcutta\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (248, 'Asia/Choibalsan\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (249, 'Asia/Chongqing\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (250, 'Asia/Chungking\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (251, 'Asia/Colombo\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (252, 'Asia/Dacca\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (253, 'Asia/Damascus\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (254, 'Asia/Dhaka\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (255, 'Asia/Dili\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (256, 'Asia/Dubai\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (257, 'Asia/Dushanbe\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (258, 'Asia/Gaza\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (259, 'Asia/Harbin\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (260, 'Asia/Hebron\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (261, 'Asia/Ho_Chi_Minh\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (262, 'Asia/Hong_Kong\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (263, 'Asia/Hovd\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (264, 'Asia/Irkutsk\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (265, 'Asia/Istanbul\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (266, 'Asia/Jakarta\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (267, 'Asia/Jayapura\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (268, 'Asia/Jerusalem\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (269, 'Asia/Kabul\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (270, 'Asia/Kamchatka\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (271, 'Asia/Karachi\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (272, 'Asia/Kashgar\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (273, 'Asia/Kathmandu\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (274, 'Asia/Katmandu\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (275, 'Asia/Kolkata\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (276, 'Asia/Krasnoyarsk\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (277, 'Asia/Kuala_Lumpur\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (278, 'Asia/Kuching\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (279, 'Asia/Kuwait\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (280, 'Asia/Macao\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (281, 'Asia/Macau\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (282, 'Asia/Magadan\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (283, 'Asia/Makassar\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (284, 'Asia/Manila\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (285, 'Asia/Muscat\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (286, 'Asia/Nicosia\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (287, 'Asia/Novokuznetsk\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (288, 'Asia/Novosibirsk\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (289, 'Asia/Omsk\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (290, 'Asia/Oral\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (291, 'Asia/Phnom_Penh\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (292, 'Asia/Pontianak\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (293, 'Asia/Pyongyang\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (294, 'Asia/Qatar\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (295, 'Asia/Qyzylorda\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (296, 'Asia/Rangoon\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (297, 'Asia/Riyadh\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (298, 'Asia/Saigon\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (299, 'Asia/Sakhalin\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (300, 'Asia/Samarkand\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (301, 'Asia/Seoul\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (302, 'Asia/Shanghai\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (303, 'Asia/Singapore\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (304, 'Asia/Taipei\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (305, 'Asia/Tashkent\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (306, 'Asia/Tbilisi\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (307, 'Asia/Tehran\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (308, 'Asia/Tel_Aviv\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (309, 'Asia/Thimbu\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (310, 'Asia/Thimphu\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (311, 'Asia/Tokyo\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (312, 'Asia/Ujung_Pandang\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (313, 'Asia/Ulaanbaatar\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (314, 'Asia/Ulan_Bator\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (315, 'Asia/Urumqi\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (316, 'Asia/Vientiane\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (317, 'Asia/Vladivostok\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (318, 'Asia/Yakutsk\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (319, 'Asia/Yekaterinburg\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (320, 'Asia/Yerevan\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (321, 'Atlantic/Azores\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (322, 'Atlantic/Bermuda\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (323, 'Atlantic/Canary\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (324, 'Atlantic/Cape_Verde\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (325, 'Atlantic/Faeroe\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (326, 'Atlantic/Faroe\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (327, 'Atlantic/Jan_Mayen\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (328, 'Atlantic/Madeira\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (329, 'Atlantic/Reykjavik\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (330, 'Atlantic/South_Georgia\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (331, 'Atlantic/St_Helena\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (332, 'Atlantic/Stanley\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (333, 'Australia/ACT\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (334, 'Australia/Adelaide\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (335, 'Australia/Brisbane\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (336, 'Australia/Broken_Hill\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (337, 'Australia/Canberra\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (338, 'Australia/Currie\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (339, 'Australia/Darwin\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (340, 'Australia/Eucla\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (341, 'Australia/Hobart\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (342, 'Australia/LHI\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (343, 'Australia/Lindeman\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (344, 'Australia/Lord_Howe\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (345, 'Australia/Melbourne\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (346, 'Australia/North\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (347, 'Australia/NSW\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (348, 'Australia/Perth\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (349, 'Australia/Queensland\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (350, 'Australia/South\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (351, 'Australia/Sydney\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (352, 'Australia/Tasmania\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (353, 'Australia/Victoria\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (354, 'Australia/West\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (355, 'Australia/Yancowinna\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (356, 'Brazil/Acre\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (357, 'Brazil/DeNoronha\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (358, 'Brazil/East\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (359, 'Brazil/West\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (360, 'Canada/Atlantic\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (361, 'Canada/Central\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (362, 'Canada/Eastern\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (363, 'Canada/East-Saskatchewan\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (364, 'Canada/Mountain\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (365, 'Canada/Newfoundland\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (366, 'Canada/Pacific\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (367, 'Canada/Saskatchewan\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (368, 'Canada/Yukon\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (369, 'CET\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (370, 'Chile/Continental\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (371, 'Chile/EasterIsland\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (372, 'CST6CDT\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (373, 'Cuba\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (374, 'EET\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (375, 'Egypt\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (376, 'Eire\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (377, 'EST\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (378, 'EST5EDT\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (379, 'Etc./GMT\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (380, 'Etc./GMT+0\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (381, 'Etc./UCT\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (382, 'Etc./Universal\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (383, 'Etc./UTC\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (384, 'Etc./Zulu\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (385, 'Europe/Amsterdam\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (386, 'Europe/Andorra\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (387, 'Europe/Athens\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (388, 'Europe/Belfast\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (389, 'Europe/Belgrade\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (390, 'Europe/Berlin\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (391, 'Europe/Bratislava\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (392, 'Europe/Brussels\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (393, 'Europe/Bucharest\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (394, 'Europe/Budapest\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (395, 'Europe/Chisinau\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (396, 'Europe/Copenhagen\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (397, 'Europe/Dublin\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (398, 'Europe/Gibraltar\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (399, 'Europe/Guernsey\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (400, 'Europe/Helsinki\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (401, 'Europe/Isle_of_Man\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (402, 'Europe/Istanbul\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (403, 'Europe/Jersey\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (404, 'Europe/Kaliningrad\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (405, 'Europe/Kiev\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (406, 'Europe/Lisbon\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (407, 'Europe/Ljubljana\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (408, 'Europe/London\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (409, 'Europe/Luxembourg\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (410, 'Europe/Madrid\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (411, 'Europe/Malta\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (412, 'Europe/Mariehamn\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (413, 'Europe/Minsk\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (414, 'Europe/Monaco\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (415, 'Europe/Moscow\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (416, 'Europe/Nicosia\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (417, 'Europe/Oslo\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (418, 'Europe/Paris\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (419, 'Europe/Podgorica\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (420, 'Europe/Prague\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (421, 'Europe/Riga\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (422, 'Europe/Rome\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (423, 'Europe/Samara\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (424, 'Europe/San_Marino\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (425, 'Europe/Sarajevo\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (426, 'Europe/Simferopol\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (427, 'Europe/Skopje\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (428, 'Europe/Sofia\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (429, 'Europe/Stockholm\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (430, 'Europe/Tallinn\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (431, 'Europe/Tirane\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (432, 'Europe/Tiraspol\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (433, 'Europe/Uzhgorod\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (434, 'Europe/Vaduz\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (435, 'Europe/Vatican\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (436, 'Europe/Vienna\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (437, 'Europe/Vilnius\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (438, 'Europe/Volgograd\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (439, 'Europe/Warsaw\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (440, 'Europe/Zagreb\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (441, 'Europe/Zaporozhye\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (442, 'Europe/Zurich\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (443, 'GB\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (444, 'GB-Eire\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (445, 'GMT\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (446, 'GMT+0\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (447, 'GMT0\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (448, 'GMT-0\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (449, 'Greenwich\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (450, 'Hong Kong\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (451, 'HST\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (452, 'Iceland\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (453, 'Indian/Antananarivo\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (454, 'Indian/Chagos\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (455, 'Indian/Christmas\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (456, 'Indian/Cocos\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (457, 'Indian/Comoro\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (458, 'Indian/Kerguelen\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (459, 'Indian/Mahe\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (460, 'Indian/Maldives\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (461, 'Indian/Mauritius\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (462, 'Indian/Mayotte\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (463, 'Indian/Reunion\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (464, 'Iran\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (465, 'Israel\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (466, 'Jamaica\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (467, 'Japan\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (468, 'JST-9\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (469, 'Kwajalein\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (470, 'Libya\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (471, 'MET\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (472, 'Mexico/BajaNorte\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (473, 'Mexico/BajaSur\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (474, 'Mexico/General\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (475, 'MST\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (476, 'MST7MDT\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (477, 'Navajo\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (478, 'NZ\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (479, 'NZ-CHAT\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (480, 'Pacific/Apia\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (481, 'Pacific/Auckland\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (482, 'Pacific/Chatham\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (483, 'Pacific/Chuuk\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (484, 'Pacific/Easter\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (485, 'Pacific/Efate\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (486, 'Pacific/Enderbury\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (487, 'Pacific/Fakaofo\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (488, 'Pacific/Fiji\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (489, 'Pacific/Funafuti\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (490, 'Pacific/Galapagos\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (491, 'Pacific/Gambier\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (492, 'Pacific/Guadalcanal\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (493, 'Pacific/Guam\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (494, 'Pacific/Honolulu\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (495, 'Pacific/Johnston\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (496, 'Pacific/Kiritimati\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (497, 'Pacific/Kosrae\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (498, 'Pacific/Kwajalein\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (499, 'Pacific/Majuro\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (500, 'Pacific/Marquesas\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (501, 'Pacific/Midway\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (502, 'Pacific/Nauru\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (503, 'Pacific/Niue\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (504, 'Pacific/Norfolk\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (505, 'Pacific/Noumea\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (506, 'Pacific/Pago_Pago\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (507, 'Pacific/Palau\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (508, 'Pacific/Pitcairn\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (509, 'Pacific/Pohnpei\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (510, 'Pacific/Ponape\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (511, 'Pacific/Port_Moresby\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (512, 'Pacific/Rarotonga\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (513, 'Pacific/Saipan\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (514, 'Pacific/Samoa\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (515, 'Pacific/Tahiti\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (516, 'Pacific/Tarawa\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (517, 'Pacific/Tongatapu\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (518, 'Pacific/Truk\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (519, 'Pacific/Wake\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (520, 'Pacific/Wallis\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (521, 'Pacific/Yap\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (522, 'Poland\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (523, 'Portugal\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (524, 'PRC\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (525, 'PST8PDT\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (526, 'ROC\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (527, 'ROK\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (528, 'Singapore\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (529, 'Turkey\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (530, 'UCT\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (531, 'Universal\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (532, 'US/Alaska\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (533, 'US/Aleutian\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (534, 'US/Arizona\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (535, 'US/Central\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (536, 'US/Eastern\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (537, 'US/East-Indiana\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (538, 'US/Hawaii\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (539, 'US/Indiana-Starke\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (540, 'US/Michigan\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (541, 'US/Mountain\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (542, 'US/Pacific\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (543, 'US/Pacific-New\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (544, 'US/Samoa\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (545, 'UTC\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (546, 'WET\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (547, 'W-SU\r', 1);
INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES (548, 'Zulu\r', 1);


#
# TABLE STRUCTURE FOR: db_units
#

DROP TABLE IF EXISTS `db_units`;

CREATE TABLE `db_units` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `unit_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_id` int(5) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_units` (`id`, `unit_name`, `description`, `company_id`, `status`) VALUES (7, 'Box', 'Box Information', NULL, 1);
INSERT INTO `db_units` (`id`, `unit_name`, `description`, `company_id`, `status`) VALUES (8, 'Drums', 'Drums Information', NULL, 1);
INSERT INTO `db_units` (`id`, `unit_name`, `description`, `company_id`, `status`) VALUES (9, 'Pieces', 'Pieces Information', NULL, 1);
INSERT INTO `db_units` (`id`, `unit_name`, `description`, `company_id`, `status`) VALUES (10, 'Grams', 'Grams Description', NULL, 1);
INSERT INTO `db_units` (`id`, `unit_name`, `description`, `company_id`, `status`) VALUES (11, 'Packets', 'Packets information', NULL, 1);
INSERT INTO `db_units` (`id`, `unit_name`, `description`, `company_id`, `status`) VALUES (12, 'Unit', 'Unit Description', NULL, 1);
INSERT INTO `db_units` (`id`, `unit_name`, `description`, `company_id`, `status`) VALUES (13, 'Mtr', '', NULL, 1);
INSERT INTO `db_units` (`id`, `unit_name`, `description`, `company_id`, `status`) VALUES (14, 'Roll', '', NULL, 1);
INSERT INTO `db_units` (`id`, `unit_name`, `description`, `company_id`, `status`) VALUES (15, 'Qty', '', NULL, 1);


#
# TABLE STRUCTURE FOR: db_users
#

DROP TABLE IF EXISTS `db_users`;

CREATE TABLE `db_users` (
  `id` double NOT NULL AUTO_INCREMENT,
  `username` varchar(1350) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` blob DEFAULT NULL,
  `member_of` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `firstname` varchar(1350) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastname` varchar(1350) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile` varchar(405) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(1350) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` blob DEFAULT NULL,
  `gender` varchar(1350) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `country` varchar(1620) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(1350) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(1620) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` blob DEFAULT NULL,
  `postcode` varchar(270) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role_name` varchar(1350) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role_id` int(5) DEFAULT NULL,
  `profile_picture` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_time` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_ip` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_id` int(5) DEFAULT NULL,
  `status` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `db_users` (`id`, `username`, `password`, `member_of`, `firstname`, `lastname`, `mobile`, `email`, `photo`, `gender`, `dob`, `country`, `state`, `city`, `address`, `postcode`, `role_name`, `role_id`, `profile_picture`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `status`) VALUES ('1', 'admin', '1d40a87ce11f2f1cba457a2372180416', '', 'Admin', NULL, '9845454454', 'mgubendran@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, '2018-11-27', '::1', NULL, NULL, NULL, 1, '1');
INSERT INTO `db_users` (`id`, `username`, `password`, `member_of`, `firstname`, `lastname`, `mobile`, `email`, `photo`, `gender`, `dob`, `country`, `state`, `city`, `address`, `postcode`, `role_name`, `role_id`, `profile_picture`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `status`) VALUES ('2', 'manager', 'e10adc3949ba59abbe56e057f20f883e', NULL, 'Manager', NULL, '12345678', 'gubi@softlinekw.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 'uploads/users/logonew.png', '2021-03-16', '01:18:21 am', 'admin', '188.71.253.144', '188.71.253.144', NULL, '1');
INSERT INTO `db_users` (`id`, `username`, `password`, `member_of`, `firstname`, `lastname`, `mobile`, `email`, `photo`, `gender`, `dob`, `country`, `state`, `city`, `address`, `postcode`, `role_name`, `role_id`, `profile_picture`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `company_id`, `status`) VALUES ('3', 'test tech', '827ccb0eea8a706c4c34a16891f84e7b', NULL, NULL, NULL, '456464564', 'tuhin@technoexponent.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 10, '', '2021-05-02', '07:21:18 am', 'admin', '::1', 'DESKTOP-CMMNJOB', NULL, '1');


#
# TABLE STRUCTURE FOR: db_warehouse
#

DROP TABLE IF EXISTS `db_warehouse`;

CREATE TABLE `db_warehouse` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `warehouse_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET foreign_key_checks = 1;
